-- Custom Buttons Migration
-- Adds support for customizable call-to-action buttons for children

-- Create custom_buttons table
-- Each child can have custom buttons in addition to the default pee/poop
CREATE TABLE IF NOT EXISTS custom_buttons (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  child_id UUID NOT NULL REFERENCES children(id) ON DELETE CASCADE,
  name TEXT NOT NULL, -- Display name shown on the button
  tts_message TEXT NOT NULL, -- Text-to-speech message when pressed
  color TEXT NOT NULL DEFAULT '#9333ea', -- Button color (hex)
  icon_url TEXT, -- Optional custom image/icon URL
  display_order INTEGER DEFAULT 0, -- Order in which buttons appear
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_custom_buttons_child ON custom_buttons(child_id);
CREATE INDEX IF NOT EXISTS idx_custom_buttons_active ON custom_buttons(child_id, is_active);

-- Enable RLS on custom_buttons table
ALTER TABLE custom_buttons ENABLE ROW LEVEL SECURITY;

-- RLS Policies for custom_buttons
CREATE POLICY "Users can view custom buttons for their children" ON custom_buttons FOR SELECT 
  USING (
    EXISTS (
      SELECT 1 FROM children 
      WHERE children.id = custom_buttons.child_id 
      AND children.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can insert custom buttons for their children" ON custom_buttons FOR INSERT 
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM children 
      WHERE children.id = custom_buttons.child_id 
      AND children.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update custom buttons for their children" ON custom_buttons FOR UPDATE 
  USING (
    EXISTS (
      SELECT 1 FROM children 
      WHERE children.id = custom_buttons.child_id 
      AND children.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can delete custom buttons for their children" ON custom_buttons FOR DELETE 
  USING (
    EXISTS (
      SELECT 1 FROM children 
      WHERE children.id = custom_buttons.child_id 
      AND children.user_id = auth.uid()
    )
  );

-- Modify bathroom_requests to support custom button types
-- Add a custom_button_id column for custom requests
ALTER TABLE bathroom_requests 
  ADD COLUMN IF NOT EXISTS custom_button_id UUID REFERENCES custom_buttons(id) ON DELETE SET NULL;

-- Update request_type to allow 'custom' as a type
-- Note: We'll store 'custom' as the type and reference the custom_button_id for details
