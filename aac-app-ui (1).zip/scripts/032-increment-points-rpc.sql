-- Create RPC function to increment child points atomically
CREATE OR REPLACE FUNCTION increment_child_points(child_id_param UUID, points_param INTEGER)
RETURNS void AS $$
BEGIN
  UPDATE children 
  SET total_points = total_points + points_param
  WHERE id = child_id_param;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION increment_child_points(UUID, INTEGER) TO authenticated;
