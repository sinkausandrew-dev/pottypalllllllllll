-- Comprehensive cleanup script
-- This script safely drops all existing tables and policies before recreating them

-- First, drop tables with CASCADE (this removes associated policies automatically)
DROP TABLE IF EXISTS caregiver_pings CASCADE;
DROP TABLE IF EXISTS vocabulary_words CASCADE;
DROP TABLE IF EXISTS vocabulary_categories CASCADE;
DROP TABLE IF EXISTS push_subscriptions CASCADE;

-- Now recreate vocabulary_categories
CREATE TABLE vocabulary_categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  caregiver_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  child_id UUID REFERENCES children(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  icon TEXT DEFAULT 'folder',
  color TEXT DEFAULT '#6366f1',
  display_order INTEGER DEFAULT 0,
  is_system BOOLEAN DEFAULT FALSE,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Recreate vocabulary_words
CREATE TABLE vocabulary_words (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  caregiver_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  child_id UUID REFERENCES children(id) ON DELETE CASCADE,
  category_id UUID REFERENCES vocabulary_categories(id) ON DELETE SET NULL,
  word TEXT NOT NULL,
  phrase TEXT,
  display_text TEXT,
  icon TEXT DEFAULT 'message-circle',
  color TEXT,
  image_url TEXT,
  is_ping_enabled BOOLEAN DEFAULT FALSE,
  ping_priority TEXT DEFAULT 'normal' CHECK (ping_priority IN ('low', 'normal', 'high', 'urgent')),
  display_order INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT TRUE,
  is_favorite BOOLEAN DEFAULT FALSE,
  times_used INTEGER DEFAULT 0,
  last_used_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Recreate caregiver_pings
CREATE TABLE caregiver_pings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  child_id UUID NOT NULL REFERENCES children(id) ON DELETE CASCADE,
  caregiver_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  word_id UUID REFERENCES vocabulary_words(id) ON DELETE SET NULL,
  message TEXT NOT NULL,
  priority TEXT DEFAULT 'normal' CHECK (priority IN ('low', 'normal', 'high', 'urgent')),
  is_read BOOLEAN DEFAULT FALSE,
  read_at TIMESTAMPTZ,
  responded_at TIMESTAMPTZ,
  response_note TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Recreate push_subscriptions
CREATE TABLE push_subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  endpoint TEXT NOT NULL,
  p256dh TEXT NOT NULL,
  auth TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(profile_id, endpoint)
);

-- Enable RLS on all tables
ALTER TABLE vocabulary_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE vocabulary_words ENABLE ROW LEVEL SECURITY;
ALTER TABLE caregiver_pings ENABLE ROW LEVEL SECURITY;
ALTER TABLE push_subscriptions ENABLE ROW LEVEL SECURITY;

-- RLS Policies for vocabulary_categories
CREATE POLICY "vocab_cat_select" ON vocabulary_categories
  FOR SELECT USING (auth.uid() = caregiver_id);

CREATE POLICY "vocab_cat_insert" ON vocabulary_categories
  FOR INSERT WITH CHECK (auth.uid() = caregiver_id);

CREATE POLICY "vocab_cat_update" ON vocabulary_categories
  FOR UPDATE USING (auth.uid() = caregiver_id);

CREATE POLICY "vocab_cat_delete" ON vocabulary_categories
  FOR DELETE USING (auth.uid() = caregiver_id);

-- RLS Policies for vocabulary_words
CREATE POLICY "vocab_words_select" ON vocabulary_words
  FOR SELECT USING (auth.uid() = caregiver_id);

CREATE POLICY "vocab_words_insert" ON vocabulary_words
  FOR INSERT WITH CHECK (auth.uid() = caregiver_id);

CREATE POLICY "vocab_words_update" ON vocabulary_words
  FOR UPDATE USING (auth.uid() = caregiver_id);

CREATE POLICY "vocab_words_delete" ON vocabulary_words
  FOR DELETE USING (auth.uid() = caregiver_id);

-- RLS Policies for caregiver_pings
CREATE POLICY "pings_select" ON caregiver_pings
  FOR SELECT USING (auth.uid() = caregiver_id);

CREATE POLICY "pings_insert" ON caregiver_pings
  FOR INSERT WITH CHECK (true);

CREATE POLICY "pings_update" ON caregiver_pings
  FOR UPDATE USING (auth.uid() = caregiver_id);

-- RLS Policies for push_subscriptions
CREATE POLICY "push_sub_select" ON push_subscriptions
  FOR SELECT USING (auth.uid() = profile_id);

CREATE POLICY "push_sub_insert" ON push_subscriptions
  FOR INSERT WITH CHECK (auth.uid() = profile_id);

CREATE POLICY "push_sub_update" ON push_subscriptions
  FOR UPDATE USING (auth.uid() = profile_id);

CREATE POLICY "push_sub_delete" ON push_subscriptions
  FOR DELETE USING (auth.uid() = profile_id);

-- Indexes for performance
CREATE INDEX idx_vocab_cat_caregiver ON vocabulary_categories(caregiver_id);
CREATE INDEX idx_vocab_cat_child ON vocabulary_categories(child_id);
CREATE INDEX idx_vocab_words_caregiver ON vocabulary_words(caregiver_id);
CREATE INDEX idx_vocab_words_child ON vocabulary_words(child_id);
CREATE INDEX idx_vocab_words_category ON vocabulary_words(category_id);
CREATE INDEX idx_pings_caregiver ON caregiver_pings(caregiver_id);
CREATE INDEX idx_pings_child ON caregiver_pings(child_id);
CREATE INDEX idx_pings_unread ON caregiver_pings(caregiver_id) WHERE is_read = FALSE;
CREATE INDEX idx_push_sub_profile ON push_subscriptions(profile_id);
