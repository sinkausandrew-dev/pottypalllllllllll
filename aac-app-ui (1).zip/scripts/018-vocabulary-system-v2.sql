-- Add vocabulary system and caregiver ping functionality (v2 - robust version)
-- This supports both Practice Mode (TTS playback) and Communication Mode (caregiver alerts)

-- First, ensure children table has user_id column (add if missing from older schema)
DO $$ 
BEGIN
  -- Add user_id column if it doesn't exist
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                 WHERE table_name = 'children' AND column_name = 'user_id') THEN
    ALTER TABLE children ADD COLUMN user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE;
  END IF;
END $$;

-- Vocabulary categories
CREATE TABLE IF NOT EXISTS vocabulary_categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  child_id UUID,
  name TEXT NOT NULL,
  icon TEXT DEFAULT 'folder',
  color TEXT DEFAULT '#6366f1',
  display_order INTEGER DEFAULT 0,
  is_system BOOLEAN DEFAULT FALSE,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Vocabulary words/phrases
CREATE TABLE IF NOT EXISTS vocabulary_words (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  child_id UUID,
  category_id UUID,
  word TEXT NOT NULL,
  display_text TEXT,
  icon TEXT DEFAULT 'message-circle',
  icon_url TEXT,
  color TEXT DEFAULT '#6366f1',
  is_ping_enabled BOOLEAN DEFAULT FALSE,
  ping_priority TEXT DEFAULT 'normal',
  display_order INTEGER DEFAULT 0,
  is_system BOOLEAN DEFAULT FALSE,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Child favorites for quick access
CREATE TABLE IF NOT EXISTS vocabulary_favorites (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  child_id UUID NOT NULL,
  word_id UUID NOT NULL,
  display_order INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Caregiver ping/alert history
CREATE TABLE IF NOT EXISTS caregiver_pings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  child_id UUID NOT NULL,
  word_id UUID,
  phrase TEXT NOT NULL,
  priority TEXT DEFAULT 'normal',
  status TEXT DEFAULT 'sent',
  acknowledged_by UUID,
  acknowledged_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Push notification subscriptions for caregivers
CREATE TABLE IF NOT EXISTS push_subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  endpoint TEXT NOT NULL,
  keys_p256dh TEXT NOT NULL,
  keys_auth TEXT NOT NULL,
  device_name TEXT,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_vocabulary_categories_user ON vocabulary_categories(user_id);
CREATE INDEX IF NOT EXISTS idx_vocabulary_categories_child ON vocabulary_categories(child_id);
CREATE INDEX IF NOT EXISTS idx_vocabulary_words_user ON vocabulary_words(user_id);
CREATE INDEX IF NOT EXISTS idx_vocabulary_words_child ON vocabulary_words(child_id);
CREATE INDEX IF NOT EXISTS idx_vocabulary_words_category ON vocabulary_words(category_id);
CREATE INDEX IF NOT EXISTS idx_vocabulary_favorites_child ON vocabulary_favorites(child_id);
CREATE INDEX IF NOT EXISTS idx_caregiver_pings_child ON caregiver_pings(child_id);
CREATE INDEX IF NOT EXISTS idx_caregiver_pings_status ON caregiver_pings(status);
CREATE INDEX IF NOT EXISTS idx_push_subscriptions_user ON push_subscriptions(user_id);

-- Enable RLS
ALTER TABLE vocabulary_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE vocabulary_words ENABLE ROW LEVEL SECURITY;
ALTER TABLE vocabulary_favorites ENABLE ROW LEVEL SECURITY;
ALTER TABLE caregiver_pings ENABLE ROW LEVEL SECURITY;
ALTER TABLE push_subscriptions ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist (to avoid conflicts)
DROP POLICY IF EXISTS "Users can view own vocabulary categories" ON vocabulary_categories;
DROP POLICY IF EXISTS "Users can create own vocabulary categories" ON vocabulary_categories;
DROP POLICY IF EXISTS "Users can update own vocabulary categories" ON vocabulary_categories;
DROP POLICY IF EXISTS "Users can delete own vocabulary categories" ON vocabulary_categories;

DROP POLICY IF EXISTS "Users can view own vocabulary words" ON vocabulary_words;
DROP POLICY IF EXISTS "Users can create own vocabulary words" ON vocabulary_words;
DROP POLICY IF EXISTS "Users can update own vocabulary words" ON vocabulary_words;
DROP POLICY IF EXISTS "Users can delete own vocabulary words" ON vocabulary_words;

DROP POLICY IF EXISTS "Users can view favorites for their children" ON vocabulary_favorites;
DROP POLICY IF EXISTS "Users can manage favorites for their children" ON vocabulary_favorites;

DROP POLICY IF EXISTS "Users can view pings for their children" ON caregiver_pings;
DROP POLICY IF EXISTS "Users can create pings for their children" ON caregiver_pings;
DROP POLICY IF EXISTS "Users can update pings for their children" ON caregiver_pings;

DROP POLICY IF EXISTS "Users can view own push subscriptions" ON push_subscriptions;
DROP POLICY IF EXISTS "Users can manage own push subscriptions" ON push_subscriptions;

-- RLS Policies for vocabulary_categories
CREATE POLICY "Users can view own vocabulary categories" ON vocabulary_categories
  FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can create own vocabulary categories" ON vocabulary_categories
  FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own vocabulary categories" ON vocabulary_categories
  FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own vocabulary categories" ON vocabulary_categories
  FOR DELETE USING (auth.uid() = user_id AND is_system = FALSE);

-- RLS Policies for vocabulary_words
CREATE POLICY "Users can view own vocabulary words" ON vocabulary_words
  FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can create own vocabulary words" ON vocabulary_words
  FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own vocabulary words" ON vocabulary_words
  FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own vocabulary words" ON vocabulary_words
  FOR DELETE USING (auth.uid() = user_id AND is_system = FALSE);

-- RLS Policies for vocabulary_favorites (simple - anyone authenticated)
CREATE POLICY "Users can view favorites for their children" ON vocabulary_favorites
  FOR SELECT USING (auth.uid() IS NOT NULL);
CREATE POLICY "Users can manage favorites for their children" ON vocabulary_favorites
  FOR ALL USING (auth.uid() IS NOT NULL);

-- RLS Policies for caregiver_pings (simple - anyone authenticated)
CREATE POLICY "Users can view pings for their children" ON caregiver_pings
  FOR SELECT USING (auth.uid() IS NOT NULL);
CREATE POLICY "Users can create pings for their children" ON caregiver_pings
  FOR INSERT WITH CHECK (auth.uid() IS NOT NULL);
CREATE POLICY "Users can update pings for their children" ON caregiver_pings
  FOR UPDATE USING (auth.uid() IS NOT NULL);

-- RLS Policies for push_subscriptions
CREATE POLICY "Users can view own push subscriptions" ON push_subscriptions
  FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can manage own push subscriptions" ON push_subscriptions
  FOR ALL USING (auth.uid() = user_id);
