-- Add vocabulary system and caregiver ping functionality
-- This supports both Practice Mode (TTS playback) and Communication Mode (caregiver alerts)

-- Ensure children table exists (may have been created by earlier migration)
CREATE TABLE IF NOT EXISTS children (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  child_name TEXT NOT NULL,
  child_age INTEGER,
  total_points INTEGER DEFAULT 0,
  avatar_url TEXT,
  voice_preference TEXT DEFAULT 'female' CHECK (voice_preference IN ('male', 'female', 'child')),
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Vocabulary categories
CREATE TABLE IF NOT EXISTS vocabulary_categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  child_id UUID REFERENCES children(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  icon TEXT DEFAULT 'folder',
  color TEXT DEFAULT '#6366f1',
  display_order INTEGER DEFAULT 0,
  is_system BOOLEAN DEFAULT FALSE,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Vocabulary words/phrases
CREATE TABLE IF NOT EXISTS vocabulary_words (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  child_id UUID REFERENCES children(id) ON DELETE CASCADE,
  category_id UUID REFERENCES vocabulary_categories(id) ON DELETE SET NULL,
  word TEXT NOT NULL,
  display_text TEXT, -- Optional different display text (e.g., "I want" displays as "I Want")
  icon TEXT DEFAULT 'message-circle',
  icon_url TEXT, -- Custom image URL
  color TEXT DEFAULT '#6366f1',
  is_ping_enabled BOOLEAN DEFAULT FALSE, -- If true, tapping sends alert to caregiver
  ping_priority TEXT DEFAULT 'normal' CHECK (ping_priority IN ('low', 'normal', 'high', 'urgent')),
  display_order INTEGER DEFAULT 0,
  is_system BOOLEAN DEFAULT FALSE, -- System words can be hidden but not deleted
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Child favorites for quick access
CREATE TABLE IF NOT EXISTS vocabulary_favorites (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  child_id UUID NOT NULL REFERENCES children(id) ON DELETE CASCADE,
  word_id UUID NOT NULL REFERENCES vocabulary_words(id) ON DELETE CASCADE,
  display_order INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(child_id, word_id)
);

-- Caregiver ping/alert history
CREATE TABLE IF NOT EXISTS caregiver_pings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  child_id UUID NOT NULL REFERENCES children(id) ON DELETE CASCADE,
  word_id UUID REFERENCES vocabulary_words(id) ON DELETE SET NULL,
  phrase TEXT NOT NULL, -- The actual phrase sent (stored in case word is deleted)
  priority TEXT DEFAULT 'normal' CHECK (priority IN ('low', 'normal', 'high', 'urgent')),
  status TEXT DEFAULT 'sent' CHECK (status IN ('sent', 'delivered', 'seen', 'acknowledged')),
  acknowledged_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  acknowledged_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Push notification subscriptions for caregivers
CREATE TABLE IF NOT EXISTS push_subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  endpoint TEXT NOT NULL,
  keys_p256dh TEXT NOT NULL,
  keys_auth TEXT NOT NULL,
  device_name TEXT,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id, endpoint)
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_vocabulary_categories_user ON vocabulary_categories(user_id);
CREATE INDEX IF NOT EXISTS idx_vocabulary_categories_child ON vocabulary_categories(child_id);
CREATE INDEX IF NOT EXISTS idx_vocabulary_words_user ON vocabulary_words(user_id);
CREATE INDEX IF NOT EXISTS idx_vocabulary_words_child ON vocabulary_words(child_id);
CREATE INDEX IF NOT EXISTS idx_vocabulary_words_category ON vocabulary_words(category_id);
CREATE INDEX IF NOT EXISTS idx_vocabulary_favorites_child ON vocabulary_favorites(child_id);
CREATE INDEX IF NOT EXISTS idx_caregiver_pings_child ON caregiver_pings(child_id);
CREATE INDEX IF NOT EXISTS idx_caregiver_pings_status ON caregiver_pings(status);
CREATE INDEX IF NOT EXISTS idx_push_subscriptions_user ON push_subscriptions(user_id);

-- Enable RLS
ALTER TABLE vocabulary_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE vocabulary_words ENABLE ROW LEVEL SECURITY;
ALTER TABLE vocabulary_favorites ENABLE ROW LEVEL SECURITY;
ALTER TABLE caregiver_pings ENABLE ROW LEVEL SECURITY;
ALTER TABLE push_subscriptions ENABLE ROW LEVEL SECURITY;

-- RLS Policies for vocabulary_categories
CREATE POLICY "Users can view own vocabulary categories" ON vocabulary_categories
  FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can create own vocabulary categories" ON vocabulary_categories
  FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own vocabulary categories" ON vocabulary_categories
  FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own vocabulary categories" ON vocabulary_categories
  FOR DELETE USING (auth.uid() = user_id AND is_system = FALSE);

-- RLS Policies for vocabulary_words
CREATE POLICY "Users can view own vocabulary words" ON vocabulary_words
  FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can create own vocabulary words" ON vocabulary_words
  FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own vocabulary words" ON vocabulary_words
  FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own vocabulary words" ON vocabulary_words
  FOR DELETE USING (auth.uid() = user_id AND is_system = FALSE);

-- RLS Policies for vocabulary_favorites
CREATE POLICY "Users can view favorites for their children" ON vocabulary_favorites
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM children WHERE children.id = vocabulary_favorites.child_id AND children.user_id = auth.uid())
  );
CREATE POLICY "Users can manage favorites for their children" ON vocabulary_favorites
  FOR ALL USING (
    EXISTS (SELECT 1 FROM children WHERE children.id = vocabulary_favorites.child_id AND children.user_id = auth.uid())
  );

-- RLS Policies for caregiver_pings
CREATE POLICY "Users can view pings for their children" ON caregiver_pings
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM children WHERE children.id = caregiver_pings.child_id AND children.user_id = auth.uid())
  );
CREATE POLICY "Users can create pings for their children" ON caregiver_pings
  FOR INSERT WITH CHECK (
    EXISTS (SELECT 1 FROM children WHERE children.id = caregiver_pings.child_id AND children.user_id = auth.uid())
  );
CREATE POLICY "Users can update pings for their children" ON caregiver_pings
  FOR UPDATE USING (
    EXISTS (SELECT 1 FROM children WHERE children.id = caregiver_pings.child_id AND children.user_id = auth.uid())
  );

-- RLS Policies for push_subscriptions
CREATE POLICY "Users can view own push subscriptions" ON push_subscriptions
  FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can manage own push subscriptions" ON push_subscriptions
  FOR ALL USING (auth.uid() = user_id);
