-- Account Branching Model Migration
-- Implements: Admin -> Caregivers -> Children with proper isolation

-- =====================================================
-- 1. Add child_pin for protected actions
-- =====================================================
ALTER TABLE children ADD COLUMN IF NOT EXISTS child_pin VARCHAR(6) DEFAULT NULL;
ALTER TABLE children ADD COLUMN IF NOT EXISTS pin_required_for_rewards BOOLEAN DEFAULT true;
ALTER TABLE children ADD COLUMN IF NOT EXISTS pin_required_for_exit BOOLEAN DEFAULT true;

-- =====================================================
-- 2. Create caregiver-child assignments junction table
-- This allows caregivers to be assigned to specific children
-- =====================================================
CREATE TABLE IF NOT EXISTS caregiver_child_assignments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  caregiver_id UUID NOT NULL REFERENCES caregivers(id) ON DELETE CASCADE,
  child_id UUID NOT NULL REFERENCES children(id) ON DELETE CASCADE,
  can_edit_settings BOOLEAN DEFAULT false,
  can_manage_rewards BOOLEAN DEFAULT true,
  can_view_reports BOOLEAN DEFAULT true,
  assigned_at TIMESTAMPTZ DEFAULT NOW(),
  assigned_by UUID REFERENCES auth.users(id),
  UNIQUE(caregiver_id, child_id)
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_cca_caregiver ON caregiver_child_assignments(caregiver_id);
CREATE INDEX IF NOT EXISTS idx_cca_child ON caregiver_child_assignments(child_id);

-- =====================================================
-- 3. Update caregiver_invites to support email and child assignments
-- =====================================================
ALTER TABLE caregiver_invites ADD COLUMN IF NOT EXISTS email VARCHAR(255);
ALTER TABLE caregiver_invites ADD COLUMN IF NOT EXISTS child_ids UUID[] DEFAULT '{}';
ALTER TABLE caregiver_invites ADD COLUMN IF NOT EXISTS caregiver_name VARCHAR(255);

-- =====================================================
-- 4. Add admin_user_id to profiles to track account owner
-- =====================================================
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS display_name VARCHAR(255);
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT true;

-- =====================================================
-- 5. Update caregivers table
-- =====================================================
-- Ensure is_admin column exists and add account owner tracking
ALTER TABLE caregivers ADD COLUMN IF NOT EXISTS is_admin BOOLEAN DEFAULT false;

-- =====================================================
-- 6. Enable RLS on new table
-- =====================================================
ALTER TABLE caregiver_child_assignments ENABLE ROW LEVEL SECURITY;

-- =====================================================
-- 7. RLS Policies for caregiver_child_assignments
-- =====================================================

-- Admins can manage all assignments for their account
CREATE POLICY "Admins can view child assignments" 
  ON caregiver_child_assignments FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM caregivers c
      WHERE c.id = caregiver_child_assignments.caregiver_id
      AND c.profile_id IN (SELECT id FROM profiles WHERE id = auth.uid())
    )
    OR
    EXISTS (
      SELECT 1 FROM caregivers c
      WHERE c.user_id = auth.uid() AND c.is_admin = true
      AND c.profile_id IN (
        SELECT c2.profile_id FROM caregivers c2 
        WHERE c2.id = caregiver_child_assignments.caregiver_id
      )
    )
    OR
    caregiver_id IN (SELECT id FROM caregivers WHERE user_id = auth.uid())
  );

CREATE POLICY "Admins can create child assignments"
  ON caregiver_child_assignments FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM caregivers c
      WHERE c.user_id = auth.uid() AND c.is_admin = true
    )
    OR auth.uid() IN (SELECT id FROM profiles)
  );

CREATE POLICY "Admins can update child assignments"
  ON caregiver_child_assignments FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM caregivers c
      WHERE c.user_id = auth.uid() AND c.is_admin = true
    )
    OR auth.uid() IN (SELECT id FROM profiles)
  );

CREATE POLICY "Admins can delete child assignments"
  ON caregiver_child_assignments FOR DELETE
  USING (
    EXISTS (
      SELECT 1 FROM caregivers c
      WHERE c.user_id = auth.uid() AND c.is_admin = true
    )
    OR auth.uid() IN (SELECT id FROM profiles)
  );

-- =====================================================
-- 8. Update children RLS to support caregiver assignments
-- =====================================================

-- Drop existing policies (will recreate with assignment support)
DROP POLICY IF EXISTS "Users can view their children" ON children;
DROP POLICY IF EXISTS "Users can insert their children" ON children;
DROP POLICY IF EXISTS "Users can update their children" ON children;
DROP POLICY IF EXISTS "Users can delete their children" ON children;

-- New policies that support both admin ownership and caregiver assignments
CREATE POLICY "Users can view children they own or are assigned to"
  ON children FOR SELECT
  USING (
    -- Admin/owner can see all their children
    user_id = auth.uid()
    OR
    -- Caregivers can see children they are assigned to
    id IN (
      SELECT child_id FROM caregiver_child_assignments cca
      JOIN caregivers c ON c.id = cca.caregiver_id
      WHERE c.user_id = auth.uid()
    )
  );

CREATE POLICY "Only admins can insert children"
  ON children FOR INSERT
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Admins and assigned caregivers can update children"
  ON children FOR UPDATE
  USING (
    user_id = auth.uid()
    OR
    id IN (
      SELECT child_id FROM caregiver_child_assignments cca
      JOIN caregivers c ON c.id = cca.caregiver_id
      WHERE c.user_id = auth.uid() AND cca.can_edit_settings = true
    )
  );

CREATE POLICY "Only admins can delete children"
  ON children FOR DELETE
  USING (user_id = auth.uid());

-- =====================================================
-- 9. Update other tables to respect caregiver assignments
-- =====================================================

-- bathroom_requests: Caregivers can see/manage requests for assigned children
DROP POLICY IF EXISTS "Users can view requests for their children" ON bathroom_requests;
DROP POLICY IF EXISTS "Users can insert requests for their children" ON bathroom_requests;
DROP POLICY IF EXISTS "Users can update requests for their children" ON bathroom_requests;

CREATE POLICY "Users can view requests for accessible children"
  ON bathroom_requests FOR SELECT
  USING (
    child_id IN (
      SELECT id FROM children WHERE user_id = auth.uid()
    )
    OR
    child_id IN (
      SELECT child_id FROM caregiver_child_assignments cca
      JOIN caregivers c ON c.id = cca.caregiver_id
      WHERE c.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can insert requests for accessible children"
  ON bathroom_requests FOR INSERT
  WITH CHECK (
    child_id IN (
      SELECT id FROM children WHERE user_id = auth.uid()
    )
    OR
    child_id IN (
      SELECT child_id FROM caregiver_child_assignments cca
      JOIN caregivers c ON c.id = cca.caregiver_id
      WHERE c.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update requests for accessible children"
  ON bathroom_requests FOR UPDATE
  USING (
    child_id IN (
      SELECT id FROM children WHERE user_id = auth.uid()
    )
    OR
    child_id IN (
      SELECT child_id FROM caregiver_child_assignments cca
      JOIN caregivers c ON c.id = cca.caregiver_id
      WHERE c.user_id = auth.uid()
    )
  );

-- rewards: Similar pattern
DROP POLICY IF EXISTS "Users can view rewards for their children" ON rewards;
DROP POLICY IF EXISTS "Users can insert rewards for their children" ON rewards;
DROP POLICY IF EXISTS "Users can update rewards for their children" ON rewards;
DROP POLICY IF EXISTS "Users can delete rewards for their children" ON rewards;

CREATE POLICY "Users can view rewards for accessible children"
  ON rewards FOR SELECT
  USING (
    child_id IN (SELECT id FROM children WHERE user_id = auth.uid())
    OR
    child_id IN (
      SELECT child_id FROM caregiver_child_assignments cca
      JOIN caregivers c ON c.id = cca.caregiver_id
      WHERE c.user_id = auth.uid()
    )
  );

CREATE POLICY "Admins and authorized caregivers can insert rewards"
  ON rewards FOR INSERT
  WITH CHECK (
    child_id IN (SELECT id FROM children WHERE user_id = auth.uid())
    OR
    child_id IN (
      SELECT child_id FROM caregiver_child_assignments cca
      JOIN caregivers c ON c.id = cca.caregiver_id
      WHERE c.user_id = auth.uid() AND cca.can_manage_rewards = true
    )
  );

CREATE POLICY "Admins and authorized caregivers can update rewards"
  ON rewards FOR UPDATE
  USING (
    child_id IN (SELECT id FROM children WHERE user_id = auth.uid())
    OR
    child_id IN (
      SELECT child_id FROM caregiver_child_assignments cca
      JOIN caregivers c ON c.id = cca.caregiver_id
      WHERE c.user_id = auth.uid() AND cca.can_manage_rewards = true
    )
  );

CREATE POLICY "Only admins can delete rewards"
  ON rewards FOR DELETE
  USING (child_id IN (SELECT id FROM children WHERE user_id = auth.uid()));

-- =====================================================
-- 10. Function to verify child PIN
-- =====================================================
CREATE OR REPLACE FUNCTION verify_child_pin(p_child_id UUID, p_pin VARCHAR)
RETURNS BOOLEAN AS $$
DECLARE
  stored_pin VARCHAR;
BEGIN
  SELECT child_pin INTO stored_pin FROM children WHERE id = p_child_id;
  
  -- If no PIN is set, always return true
  IF stored_pin IS NULL THEN
    RETURN true;
  END IF;
  
  -- Compare PINs
  RETURN stored_pin = p_pin;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- =====================================================
-- 11. Function to auto-assign caregivers to children on invite acceptance
-- =====================================================
CREATE OR REPLACE FUNCTION process_caregiver_invite_acceptance(
  p_invite_id UUID,
  p_user_id UUID,
  p_caregiver_name VARCHAR
)
RETURNS UUID AS $$
DECLARE
  v_invite RECORD;
  v_caregiver_id UUID;
  v_child_id UUID;
BEGIN
  -- Get invite details
  SELECT * INTO v_invite FROM caregiver_invites WHERE id = p_invite_id;
  
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Invite not found';
  END IF;
  
  IF v_invite.status != 'pending' THEN
    RAISE EXCEPTION 'Invite is not pending';
  END IF;
  
  IF v_invite.expires_at < NOW() THEN
    RAISE EXCEPTION 'Invite has expired';
  END IF;
  
  -- Create caregiver record
  INSERT INTO caregivers (
    profile_id, 
    name, 
    email, 
    phone, 
    user_id, 
    is_admin, 
    invite_id, 
    receive_notifications
  )
  VALUES (
    v_invite.profile_id,
    COALESCE(p_caregiver_name, v_invite.caregiver_name, 'Caregiver'),
    v_invite.email,
    v_invite.phone,
    p_user_id,
    false,
    p_invite_id,
    true
  )
  RETURNING id INTO v_caregiver_id;
  
  -- Create child assignments from invite
  IF v_invite.child_ids IS NOT NULL AND array_length(v_invite.child_ids, 1) > 0 THEN
    FOREACH v_child_id IN ARRAY v_invite.child_ids
    LOOP
      INSERT INTO caregiver_child_assignments (caregiver_id, child_id, assigned_by)
      VALUES (v_caregiver_id, v_child_id, v_invite.invited_by)
      ON CONFLICT (caregiver_id, child_id) DO NOTHING;
    END LOOP;
  END IF;
  
  -- Update invite status
  UPDATE caregiver_invites 
  SET status = 'accepted', accepted_by = p_user_id, accepted_at = NOW()
  WHERE id = p_invite_id;
  
  RETURN v_caregiver_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- =====================================================
-- 12. Migration: Auto-assign existing caregivers to all children
-- =====================================================
DO $$
DECLARE
  v_caregiver RECORD;
  v_child RECORD;
BEGIN
  -- For each caregiver, assign to all children under same profile
  FOR v_caregiver IN SELECT * FROM caregivers LOOP
    FOR v_child IN 
      SELECT c.* FROM children c
      JOIN profiles p ON c.user_id = p.id
      WHERE p.id = v_caregiver.profile_id
    LOOP
      INSERT INTO caregiver_child_assignments (caregiver_id, child_id, can_edit_settings)
      VALUES (v_caregiver.id, v_child.id, v_caregiver.is_admin)
      ON CONFLICT (caregiver_id, child_id) DO NOTHING;
    END LOOP;
  END LOOP;
END $$;
