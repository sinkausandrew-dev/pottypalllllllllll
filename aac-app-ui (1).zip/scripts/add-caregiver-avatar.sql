-- Add avatar_url column to caregivers table
ALTER TABLE caregivers ADD COLUMN IF NOT EXISTS avatar_url TEXT;

-- Add comment for documentation
COMMENT ON COLUMN caregivers.avatar_url IS 'URL to the caregiver profile picture stored in Vercel Blob';
