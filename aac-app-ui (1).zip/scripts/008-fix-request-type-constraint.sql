-- Fix the request_type constraint to include 'custom' type
-- The original constraint only allowed 'pee' and 'poop'

-- Drop the old constraint
ALTER TABLE bathroom_requests 
  DROP CONSTRAINT IF EXISTS bathroom_requests_request_type_check;

-- Add the new constraint that includes 'custom'
ALTER TABLE bathroom_requests 
  ADD CONSTRAINT bathroom_requests_request_type_check 
  CHECK (request_type IN ('pee', 'poop', 'custom'));
