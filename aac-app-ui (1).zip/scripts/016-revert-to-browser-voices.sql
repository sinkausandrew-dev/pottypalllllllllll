-- Revert voice preferences back to browser TTS values (female, male, child)
-- This migration converts any OpenAI voice names back to simple browser voice types

-- First, drop the existing constraint that only allows OpenAI voice names
ALTER TABLE children DROP CONSTRAINT IF EXISTS children_voice_preference_check;

-- Map OpenAI voices back to browser voices
UPDATE children SET voice_preference = 'female' WHERE voice_preference IN ('nova', 'shimmer', 'alloy', 'echo', 'fable');
UPDATE children SET voice_preference = 'male' WHERE voice_preference = 'onyx';

-- Ensure any NULL or unexpected values default to female
UPDATE children SET voice_preference = 'female' WHERE voice_preference IS NULL OR voice_preference NOT IN ('male', 'female', 'child');

-- Add the new constraint to only allow browser voice options
ALTER TABLE children ADD CONSTRAINT children_voice_preference_check 
  CHECK (voice_preference IN ('male', 'female', 'child'));
