-- Migration: Simplify AAC tiers - remove grade band comparisons
-- Focus on personal progress, not peer comparison

-- Update tier names and descriptions to be encouraging, not grade-based
UPDATE aac_tiers SET 
  name = 'Getting Started',
  grade_band = NULL,
  description = 'Learning to communicate with single words and pictures'
WHERE tier_key = 'T0';

UPDATE aac_tiers SET 
  name = 'Building Words',
  grade_band = NULL,
  description = 'Using core words to express needs and wants'
WHERE tier_key = 'T1';

UPDATE aac_tiers SET 
  name = 'Making Sentences',
  grade_band = NULL,
  description = 'Combining words to make short sentences'
WHERE tier_key = 'T2';

UPDATE aac_tiers SET 
  name = 'Telling Stories',
  grade_band = NULL,
  description = 'Building longer messages with more detail'
WHERE tier_key = 'T3';

UPDATE aac_tiers SET 
  name = 'Expressing Ideas',
  grade_band = NULL,
  description = 'Sharing thoughts and having conversations'
WHERE tier_key = 'T4';

UPDATE aac_tiers SET 
  name = 'Full Communication',
  grade_band = NULL,
  description = 'Rich, detailed communication with full vocabulary'
WHERE tier_key = 'T5';

-- Remove benchmark data that compares to "typical" ranges
-- We'll track personal progress only
DELETE FROM aac_benchmarks;

-- Add personal milestones table instead (optional feature for later)
-- These celebrate achievements, not compare to peers
