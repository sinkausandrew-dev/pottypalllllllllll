-- AAC LAMP-Style + Tiered Learning (K-6) System
-- Migration: 026-aac-lamp-tiered-learning.sql
-- Description: Adds tables for motor-stable AAC layouts, utterance telemetry, and K-6 tier framework

-- ===========================================
-- 1) aac_tiers - Tier definitions (T0-T5)
-- ===========================================
CREATE TABLE IF NOT EXISTS aac_tiers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tier_key TEXT UNIQUE NOT NULL, -- e.g., 'T0', 'T1', 'T2', 'T3', 'T4', 'T5'
  name TEXT NOT NULL, -- e.g., 'Tier 2 — Early Sentences'
  grade_band TEXT, -- e.g., 'K', '1-2', '3-4', '5-6'
  description TEXT,
  unlocked_slots_count INT DEFAULT 20, -- number of home grid slots enabled
  grammar_features JSONB DEFAULT '[]'::jsonb, -- array of enabled grammar helpers
  unlock_rules JSONB DEFAULT '{}'::jsonb, -- thresholds for tier advancement
  display_order INT DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE aac_tiers ENABLE ROW LEVEL SECURITY;

-- Public read access for tiers (system data)
DROP POLICY IF EXISTS "Anyone can read aac_tiers" ON aac_tiers;
CREATE POLICY "Anyone can read aac_tiers" ON aac_tiers
  FOR SELECT USING (true);

-- ===========================================
-- 2) child_aac_settings - Per-child AAC config
-- ===========================================
CREATE TABLE IF NOT EXISTS child_aac_settings (
  child_id UUID PRIMARY KEY REFERENCES children(id) ON DELETE CASCADE,
  active_tier_id UUID REFERENCES aac_tiers(id),
  tier_locked BOOLEAN DEFAULT false, -- caregiver override lock
  layout_mode TEXT DEFAULT 'category_tabs' CHECK (layout_mode IN ('category_tabs', 'lamp_grid')),
  grid_size INT DEFAULT 20 CHECK (grid_size IN (20, 28, 40, 60)),
  sound_enabled_default BOOLEAN DEFAULT true,
  show_grammar_helpers BOOLEAN DEFAULT false,
  academic_packs_enabled JSONB DEFAULT '[]'::jsonb, -- array of enabled pack IDs
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE child_aac_settings ENABLE ROW LEVEL SECURITY;

-- Users can manage their own children's settings
DROP POLICY IF EXISTS "Users can manage own child aac settings" ON child_aac_settings;
CREATE POLICY "Users can manage own child aac settings" ON child_aac_settings
  FOR ALL USING (
    child_id IN (SELECT id FROM children WHERE user_id = auth.uid())
  );

-- ===========================================
-- 3) aac_layout_slots - Motor-stable grid mapping
-- ===========================================
CREATE TABLE IF NOT EXISTS aac_layout_slots (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  child_id UUID REFERENCES children(id) ON DELETE CASCADE, -- NULL for system defaults
  tier_id UUID REFERENCES aac_tiers(id) ON DELETE CASCADE, -- NULL for defaults
  slot_key TEXT NOT NULL, -- e.g., 'HOME_01', 'HOME_60', 'CAT_CORE_01'
  word_id UUID REFERENCES vocabulary_words(id) ON DELETE SET NULL,
  locked_position BOOLEAN DEFAULT true, -- motor stability
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(child_id, tier_id, slot_key) -- each slot unique per child+tier combo
);

-- Enable RLS
ALTER TABLE aac_layout_slots ENABLE ROW LEVEL SECURITY;

-- Users can manage their own children's slots
DROP POLICY IF EXISTS "Users can manage own child layout slots" ON aac_layout_slots;
CREATE POLICY "Users can manage own child layout slots" ON aac_layout_slots
  FOR ALL USING (
    child_id IS NULL OR child_id IN (SELECT id FROM children WHERE user_id = auth.uid())
  );

-- ===========================================
-- 4) aac_utterance_sessions - Session tracking
-- ===========================================
CREATE TABLE IF NOT EXISTS aac_utterance_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  child_id UUID NOT NULL REFERENCES children(id) ON DELETE CASCADE,
  mode TEXT NOT NULL CHECK (mode IN ('practice', 'communicate')),
  context_tag TEXT, -- e.g., 'bathroom', 'school', 'home', 'classroom'
  started_at TIMESTAMPTZ DEFAULT NOW(),
  ended_at TIMESTAMPTZ
);

-- Enable RLS
ALTER TABLE aac_utterance_sessions ENABLE ROW LEVEL SECURITY;

-- Users can access their own children's sessions
DROP POLICY IF EXISTS "Users can manage own child sessions" ON aac_utterance_sessions;
CREATE POLICY "Users can manage own child sessions" ON aac_utterance_sessions
  FOR ALL USING (
    child_id IN (SELECT id FROM children WHERE user_id = auth.uid())
  );

-- ===========================================
-- 5) aac_utterance_events - Telemetry
-- ===========================================
CREATE TABLE IF NOT EXISTS aac_utterance_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id UUID REFERENCES aac_utterance_sessions(id) ON DELETE CASCADE,
  child_id UUID NOT NULL REFERENCES children(id) ON DELETE CASCADE,
  event_type TEXT NOT NULL CHECK (event_type IN (
    'tap_word', 'add_to_utterance', 'remove_from_utterance',
    'speak_utterance', 'send_ping', 'prompted', 'independent',
    'grammar_helper_used', 'category_opened', 'backspace', 'clear_utterance'
  )),
  word_id UUID REFERENCES vocabulary_words(id) ON DELETE SET NULL,
  utterance_text TEXT, -- the full utterance at time of event
  utterance_word_ids UUID[], -- array of word IDs in utterance
  grammar_helper_key TEXT, -- e.g., 'past_tense', 'plural', 'because'
  latency_ms INT, -- time since last event or session start
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE aac_utterance_events ENABLE ROW LEVEL SECURITY;

-- Users can access their own children's events
DROP POLICY IF EXISTS "Users can manage own child events" ON aac_utterance_events;
CREATE POLICY "Users can manage own child events" ON aac_utterance_events
  FOR ALL USING (
    child_id IN (SELECT id FROM children WHERE user_id = auth.uid())
  );

-- ===========================================
-- 6) aac_benchmarks - K-6 peer expectations
-- ===========================================
CREATE TABLE IF NOT EXISTS aac_benchmarks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tier_id UUID NOT NULL REFERENCES aac_tiers(id) ON DELETE CASCADE,
  metric_key TEXT NOT NULL, -- e.g., 'avg_utterance_len', 'unique_words_7d', 'grammar_feature_use'
  expected_range JSONB NOT NULL, -- e.g., { "p25": 2, "p50": 4, "p75": 6 }
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(tier_id, metric_key)
);

-- Enable RLS
ALTER TABLE aac_benchmarks ENABLE ROW LEVEL SECURITY;

-- Public read access for benchmarks (system data)
DROP POLICY IF EXISTS "Anyone can read aac_benchmarks" ON aac_benchmarks;
CREATE POLICY "Anyone can read aac_benchmarks" ON aac_benchmarks
  FOR SELECT USING (true);

-- ===========================================
-- 7) aac_grammar_helpers - Available grammar helpers by tier
-- ===========================================
CREATE TABLE IF NOT EXISTS aac_grammar_helpers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  helper_key TEXT UNIQUE NOT NULL, -- e.g., 'past_tense', 'plural', 'because'
  display_name TEXT NOT NULL, -- e.g., '-ed (past)', '+s (plural)', 'because'
  helper_type TEXT NOT NULL CHECK (helper_type IN ('suffix', 'prefix', 'connector', 'frame')),
  text_to_append TEXT, -- what gets added to utterance
  min_tier_key TEXT NOT NULL DEFAULT 'T0', -- minimum tier to unlock
  display_order INT DEFAULT 0,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE aac_grammar_helpers ENABLE ROW LEVEL SECURITY;

-- Public read access
DROP POLICY IF EXISTS "Anyone can read aac_grammar_helpers" ON aac_grammar_helpers;
CREATE POLICY "Anyone can read aac_grammar_helpers" ON aac_grammar_helpers
  FOR SELECT USING (true);

-- ===========================================
-- 8) Add is_system flag to vocabulary_categories if not exists
-- ===========================================
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'vocabulary_categories' AND column_name = 'is_academic_pack'
  ) THEN
    ALTER TABLE vocabulary_categories ADD COLUMN is_academic_pack BOOLEAN DEFAULT false;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'vocabulary_categories' AND column_name = 'min_tier_key'
  ) THEN
    ALTER TABLE vocabulary_categories ADD COLUMN min_tier_key TEXT DEFAULT 'T0';
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'vocabulary_categories' AND column_name = 'pack_subject'
  ) THEN
    ALTER TABLE vocabulary_categories ADD COLUMN pack_subject TEXT; -- 'ela', 'math', 'science', 'social'
  END IF;
END $$;

-- ===========================================
-- 9) Add is_core_word flag to vocabulary_words if not exists
-- ===========================================
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'vocabulary_words' AND column_name = 'is_core_word'
  ) THEN
    ALTER TABLE vocabulary_words ADD COLUMN is_core_word BOOLEAN DEFAULT false;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'vocabulary_words' AND column_name = 'word_type'
  ) THEN
    ALTER TABLE vocabulary_words ADD COLUMN word_type TEXT DEFAULT 'noun' 
      CHECK (word_type IN ('noun', 'verb', 'adjective', 'pronoun', 'preposition', 'connector', 'social', 'question', 'descriptor'));
  END IF;
END $$;

-- ===========================================
-- INDEXES for performance
-- ===========================================
CREATE INDEX IF NOT EXISTS idx_aac_utterance_events_child_created 
  ON aac_utterance_events(child_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_aac_utterance_events_session 
  ON aac_utterance_events(session_id);

CREATE INDEX IF NOT EXISTS idx_aac_utterance_events_type 
  ON aac_utterance_events(event_type);

CREATE INDEX IF NOT EXISTS idx_aac_utterance_sessions_child 
  ON aac_utterance_sessions(child_id, started_at DESC);

CREATE INDEX IF NOT EXISTS idx_aac_layout_slots_child_tier 
  ON aac_layout_slots(child_id, tier_id);

CREATE INDEX IF NOT EXISTS idx_child_aac_settings_tier 
  ON child_aac_settings(active_tier_id);

-- ===========================================
-- SEED DATA: Tiers (T0-T5)
-- ===========================================
INSERT INTO aac_tiers (tier_key, name, grade_band, description, unlocked_slots_count, grammar_features, unlock_rules, display_order)
VALUES
  ('T0', 'Tier 0 — Emerging', 'Pre-K', 'Basic requests, single words, core nouns and verbs', 12, 
   '[]'::jsonb,
   '{"next_tier": "T1", "multi_word_utterances_per_week": 5}'::jsonb, 0),
  
  ('T1', 'Tier 1 — Early Words', 'K', 'I want, help, more, all done, basic verbs', 20,
   '["i_want", "help", "more", "all_done"]'::jsonb,
   '{"next_tier": "T2", "unique_words_7d": 15, "avg_utterance_len": 1.5}'::jsonb, 1),
  
  ('T2', 'Tier 2 — Early Sentences', '1-2', 'Descriptors, locations, simple I feel statements', 28,
   '["i_want", "help", "more", "all_done", "i_feel", "i_see", "i_like"]'::jsonb,
   '{"next_tier": "T3", "unique_words_7d": 30, "avg_utterance_len": 2.5, "grammar_helper_uses": 10}'::jsonb, 2),
  
  ('T3', 'Tier 3 — Building Sentences', '2-3', 'Tense options, pronouns, simple connectors', 40,
   '["i_want", "help", "more", "all_done", "i_feel", "i_see", "i_like", "past_tense", "plural", "because", "and", "then"]'::jsonb,
   '{"next_tier": "T4", "unique_words_7d": 50, "avg_utterance_len": 3.5, "connector_uses": 15}'::jsonb, 3),
  
  ('T4', 'Tier 4 — Complex Communication', '3-4', 'Social scripts, perspective taking, problem solving', 60,
   '["i_want", "help", "more", "all_done", "i_feel", "i_see", "i_like", "past_tense", "plural", "because", "and", "then", "but", "first", "next", "last", "i_think", "maybe"]'::jsonb,
   '{"next_tier": "T5", "unique_words_7d": 75, "avg_utterance_len": 4.5, "social_script_uses": 10}'::jsonb, 4),
  
  ('T5', 'Tier 5 — Academic Language', '5-6', 'Academic vocabulary, abstract concepts, complex sentences', 60,
   '["i_want", "help", "more", "all_done", "i_feel", "i_see", "i_like", "past_tense", "plural", "because", "and", "then", "but", "first", "next", "last", "i_think", "maybe", "however", "therefore", "compare", "contrast"]'::jsonb,
   '{}'::jsonb, 5)
ON CONFLICT (tier_key) DO UPDATE SET
  name = EXCLUDED.name,
  grade_band = EXCLUDED.grade_band,
  description = EXCLUDED.description,
  unlocked_slots_count = EXCLUDED.unlocked_slots_count,
  grammar_features = EXCLUDED.grammar_features,
  unlock_rules = EXCLUDED.unlock_rules,
  display_order = EXCLUDED.display_order;

-- ===========================================
-- SEED DATA: Grammar Helpers
-- ===========================================
INSERT INTO aac_grammar_helpers (helper_key, display_name, helper_type, text_to_append, min_tier_key, display_order)
VALUES
  -- Tier 1 frames
  ('i_want', 'I want', 'frame', 'I want', 'T1', 1),
  ('help', 'help', 'frame', 'help', 'T1', 2),
  ('more', 'more', 'frame', 'more', 'T1', 3),
  ('all_done', 'all done', 'frame', 'all done', 'T1', 4),
  
  -- Tier 2 frames
  ('i_feel', 'I feel', 'frame', 'I feel', 'T2', 10),
  ('i_see', 'I see', 'frame', 'I see', 'T2', 11),
  ('i_like', 'I like', 'frame', 'I like', 'T2', 12),
  
  -- Tier 3 grammar
  ('past_tense', '-ed (past)', 'suffix', 'ed', 'T3', 20),
  ('plural', '+s (plural)', 'suffix', 's', 'T3', 21),
  ('because', 'because', 'connector', 'because', 'T3', 22),
  ('and', 'and', 'connector', 'and', 'T3', 23),
  ('then', 'then', 'connector', 'then', 'T3', 24),
  
  -- Tier 4 advanced
  ('but', 'but', 'connector', 'but', 'T4', 30),
  ('first', 'first', 'connector', 'first', 'T4', 31),
  ('next', 'next', 'connector', 'next', 'T4', 32),
  ('last', 'last', 'connector', 'last', 'T4', 33),
  ('i_think', 'I think', 'frame', 'I think', 'T4', 34),
  ('maybe', 'maybe', 'frame', 'maybe', 'T4', 35),
  
  -- Tier 5 academic
  ('however', 'however', 'connector', 'however', 'T5', 40),
  ('therefore', 'therefore', 'connector', 'therefore', 'T5', 41),
  ('compare', 'compare', 'frame', 'compare', 'T5', 42),
  ('contrast', 'contrast', 'frame', 'contrast', 'T5', 43)
ON CONFLICT (helper_key) DO UPDATE SET
  display_name = EXCLUDED.display_name,
  helper_type = EXCLUDED.helper_type,
  text_to_append = EXCLUDED.text_to_append,
  min_tier_key = EXCLUDED.min_tier_key,
  display_order = EXCLUDED.display_order;

-- ===========================================
-- SEED DATA: Benchmarks for each tier
-- ===========================================
INSERT INTO aac_benchmarks (tier_id, metric_key, expected_range, notes)
SELECT t.id, m.metric_key, m.expected_range, m.notes
FROM aac_tiers t
CROSS JOIN (
  VALUES
    ('T0', 'avg_utterance_len', '{"p25": 1, "p50": 1, "p75": 1.2}'::jsonb, 'Single words expected'),
    ('T0', 'unique_words_7d', '{"p25": 5, "p50": 8, "p75": 12}'::jsonb, 'Limited vocabulary'),
    ('T1', 'avg_utterance_len', '{"p25": 1, "p50": 1.5, "p75": 2}'::jsonb, 'Beginning multi-word'),
    ('T1', 'unique_words_7d', '{"p25": 10, "p50": 15, "p75": 22}'::jsonb, 'Expanding vocabulary'),
    ('T1', 'grammar_feature_use', '{"p25": 0, "p50": 2, "p75": 5}'::jsonb, 'Basic frames'),
    ('T2', 'avg_utterance_len', '{"p25": 2, "p50": 2.5, "p75": 3}'::jsonb, '2-3 word phrases'),
    ('T2', 'unique_words_7d', '{"p25": 20, "p50": 30, "p75": 40}'::jsonb, 'Growing vocabulary'),
    ('T2', 'grammar_feature_use', '{"p25": 5, "p50": 10, "p75": 18}'::jsonb, 'Using I feel/see/like'),
    ('T3', 'avg_utterance_len', '{"p25": 3, "p50": 3.5, "p75": 4.5}'::jsonb, '3-4 word sentences'),
    ('T3', 'unique_words_7d', '{"p25": 35, "p50": 50, "p75": 65}'::jsonb, 'Varied vocabulary'),
    ('T3', 'grammar_feature_use', '{"p25": 12, "p50": 20, "p75": 30}'::jsonb, 'Connectors emerging'),
    ('T4', 'avg_utterance_len', '{"p25": 4, "p50": 5, "p75": 6}'::jsonb, '4-6 word sentences'),
    ('T4', 'unique_words_7d', '{"p25": 50, "p50": 75, "p75": 100}'::jsonb, 'Rich vocabulary'),
    ('T4', 'grammar_feature_use', '{"p25": 25, "p50": 40, "p75": 55}'::jsonb, 'Complex structures'),
    ('T5', 'avg_utterance_len', '{"p25": 5, "p50": 6, "p75": 8}'::jsonb, '5+ word sentences'),
    ('T5', 'unique_words_7d', '{"p25": 70, "p50": 100, "p75": 150}'::jsonb, 'Academic vocabulary'),
    ('T5', 'grammar_feature_use', '{"p25": 40, "p50": 60, "p75": 80}'::jsonb, 'Academic language')
) AS m(tier_key, metric_key, expected_range, notes)
WHERE t.tier_key = m.tier_key
ON CONFLICT (tier_id, metric_key) DO UPDATE SET
  expected_range = EXCLUDED.expected_range,
  notes = EXCLUDED.notes;
