-- Seed Grammar Helpers for AAC System
-- These provide morphological endings, connectors, and sentence frames

-- Insert Grammar Helpers
INSERT INTO aac_grammar_helpers (helper_key, display_name, helper_type, text_to_append, min_tier_key, display_order, is_active)
VALUES
  -- Suffixes (T1+)
  ('suffix_s', '+s', 'suffix', 's', 'T1', 1, true),
  ('suffix_ing', '+ing', 'suffix', 'ing', 'T1', 2, true),
  ('suffix_ed', '+ed', 'suffix', 'ed', 'T2', 3, true),
  ('suffix_er', '+er', 'suffix', 'er', 'T2', 4, true),
  ('suffix_est', '+est', 'suffix', 'est', 'T3', 5, true),
  ('suffix_ly', '+ly', 'suffix', 'ly', 'T3', 6, true),
  ('suffix_tion', '+tion', 'suffix', 'tion', 'T4', 7, true),
  
  -- Connectors (T2+)
  ('conn_and', 'and', 'connector', 'and', 'T2', 10, true),
  ('conn_but', 'but', 'connector', 'but', 'T2', 11, true),
  ('conn_or', 'or', 'connector', 'or', 'T2', 12, true),
  ('conn_because', 'because', 'connector', 'because', 'T3', 13, true),
  ('conn_so', 'so', 'connector', 'so', 'T3', 14, true),
  ('conn_then', 'then', 'connector', 'then', 'T3', 15, true),
  ('conn_if', 'if', 'connector', 'if', 'T4', 16, true),
  ('conn_when', 'when', 'connector', 'when', 'T4', 17, true),
  ('conn_while', 'while', 'connector', 'while', 'T5', 18, true),
  ('conn_although', 'although', 'connector', 'although', 'T5', 19, true),
  
  -- Sentence Frames (T3+)
  ('frame_i_want', 'I want...', 'frame', 'I want', 'T1', 20, true),
  ('frame_i_need', 'I need...', 'frame', 'I need', 'T1', 21, true),
  ('frame_i_see', 'I see...', 'frame', 'I see', 'T1', 22, true),
  ('frame_i_like', 'I like...', 'frame', 'I like', 'T2', 23, true),
  ('frame_i_dont_like', 'I don''t like...', 'frame', 'I don''t like', 'T2', 24, true),
  ('frame_can_i', 'Can I...', 'frame', 'Can I', 'T2', 25, true),
  ('frame_i_feel', 'I feel...', 'frame', 'I feel', 'T3', 26, true),
  ('frame_i_think', 'I think...', 'frame', 'I think', 'T3', 27, true),
  ('frame_do_you', 'Do you...', 'frame', 'Do you', 'T3', 28, true),
  ('frame_what_is', 'What is...', 'frame', 'What is', 'T3', 29, true),
  ('frame_where_is', 'Where is...', 'frame', 'Where is', 'T3', 30, true),
  ('frame_i_wonder', 'I wonder...', 'frame', 'I wonder', 'T4', 31, true),
  ('frame_would_you', 'Would you...', 'frame', 'Would you', 'T4', 32, true),
  ('frame_could_you', 'Could you...', 'frame', 'Could you', 'T4', 33, true)
ON CONFLICT (helper_key) DO UPDATE SET
  display_name = EXCLUDED.display_name,
  helper_type = EXCLUDED.helper_type,
  text_to_append = EXCLUDED.text_to_append,
  min_tier_key = EXCLUDED.min_tier_key,
  display_order = EXCLUDED.display_order,
  is_active = EXCLUDED.is_active;

-- Insert Benchmarks for each tier
-- These define expected ranges for various metrics at each tier level

-- Get tier IDs for reference
DO $$
DECLARE
  t0_id UUID;
  t1_id UUID;
  t2_id UUID;
  t3_id UUID;
  t4_id UUID;
  t5_id UUID;
BEGIN
  SELECT id INTO t0_id FROM aac_tiers WHERE tier_key = 'T0';
  SELECT id INTO t1_id FROM aac_tiers WHERE tier_key = 'T1';
  SELECT id INTO t2_id FROM aac_tiers WHERE tier_key = 'T2';
  SELECT id INTO t3_id FROM aac_tiers WHERE tier_key = 'T3';
  SELECT id INTO t4_id FROM aac_tiers WHERE tier_key = 'T4';
  SELECT id INTO t5_id FROM aac_tiers WHERE tier_key = 'T5';

  -- T0 Benchmarks (1-word utterances)
  INSERT INTO aac_benchmarks (tier_id, metric_key, expected_range, notes)
  VALUES
    (t0_id, 'avg_utterance_len', '{"p25": 1.0, "p50": 1.0, "p75": 1.2}', 'Single word utterances expected'),
    (t0_id, 'unique_words_7d', '{"p25": 5, "p50": 10, "p75": 20}', 'Building initial vocabulary'),
    (t0_id, 'multi_word_pct', '{"p25": 0, "p50": 0, "p75": 10}', 'Primarily single words')
  ON CONFLICT DO NOTHING;

  -- T1 Benchmarks (2-word combinations)
  INSERT INTO aac_benchmarks (tier_id, metric_key, expected_range, notes)
  VALUES
    (t1_id, 'avg_utterance_len', '{"p25": 1.5, "p50": 2.0, "p75": 2.5}', 'Two-word combinations emerging'),
    (t1_id, 'unique_words_7d', '{"p25": 15, "p50": 25, "p75": 40}', 'Expanding vocabulary'),
    (t1_id, 'multi_word_pct', '{"p25": 20, "p50": 40, "p75": 60}', 'Increasing multi-word use'),
    (t1_id, 'grammar_helper_use', '{"p25": 0, "p50": 5, "p75": 15}', 'Beginning suffix use')
  ON CONFLICT DO NOTHING;

  -- T2 Benchmarks (3-4 word phrases)
  INSERT INTO aac_benchmarks (tier_id, metric_key, expected_range, notes)
  VALUES
    (t2_id, 'avg_utterance_len', '{"p25": 2.5, "p50": 3.5, "p75": 4.0}', 'Multi-word phrases common'),
    (t2_id, 'unique_words_7d', '{"p25": 30, "p50": 50, "p75": 75}', 'Solid vocabulary base'),
    (t2_id, 'multi_word_pct', '{"p25": 50, "p50": 70, "p75": 85}', 'Majority multi-word'),
    (t2_id, 'grammar_helper_use', '{"p25": 10, "p50": 25, "p75": 50}', 'Regular suffix/connector use'),
    (t2_id, 'connector_use', '{"p25": 5, "p50": 15, "p75": 30}', 'Using and/but/or')
  ON CONFLICT DO NOTHING;

  -- T3 Benchmarks (simple sentences)
  INSERT INTO aac_benchmarks (tier_id, metric_key, expected_range, notes)
  VALUES
    (t3_id, 'avg_utterance_len', '{"p25": 4.0, "p50": 5.0, "p75": 6.0}', 'Full simple sentences'),
    (t3_id, 'unique_words_7d', '{"p25": 50, "p50": 80, "p75": 120}', 'Large active vocabulary'),
    (t3_id, 'multi_word_pct', '{"p25": 70, "p50": 85, "p75": 95}', 'Almost all multi-word'),
    (t3_id, 'grammar_helper_use', '{"p25": 30, "p50": 60, "p75": 100}', 'Frequent grammar use'),
    (t3_id, 'connector_use', '{"p25": 15, "p50": 35, "p75": 60}', 'Using because/so/then'),
    (t3_id, 'question_use', '{"p25": 5, "p50": 15, "p75": 30}', 'Asking questions')
  ON CONFLICT DO NOTHING;

  -- T4 Benchmarks (complex sentences)
  INSERT INTO aac_benchmarks (tier_id, metric_key, expected_range, notes)
  VALUES
    (t4_id, 'avg_utterance_len', '{"p25": 5.5, "p50": 7.0, "p75": 9.0}', 'Complex sentences'),
    (t4_id, 'unique_words_7d', '{"p25": 80, "p50": 120, "p75": 180}', 'Extensive vocabulary'),
    (t4_id, 'multi_word_pct', '{"p25": 85, "p50": 95, "p75": 100}', 'Consistent multi-word'),
    (t4_id, 'grammar_helper_use', '{"p25": 60, "p50": 100, "p75": 160}', 'Advanced grammar'),
    (t4_id, 'connector_use', '{"p25": 30, "p50": 60, "p75": 100}', 'Using if/when conditionals'),
    (t4_id, 'compound_sentence_pct', '{"p25": 10, "p50": 25, "p75": 45}', 'Joining clauses')
  ON CONFLICT DO NOTHING;

  -- T5 Benchmarks (academic/fluent)
  INSERT INTO aac_benchmarks (tier_id, metric_key, expected_range, notes)
  VALUES
    (t5_id, 'avg_utterance_len', '{"p25": 7.0, "p50": 10.0, "p75": 15.0}', 'Extended discourse'),
    (t5_id, 'unique_words_7d', '{"p25": 120, "p50": 200, "p75": 300}', 'Academic vocabulary'),
    (t5_id, 'multi_word_pct', '{"p25": 95, "p50": 100, "p75": 100}', 'Full sentences always'),
    (t5_id, 'grammar_helper_use', '{"p25": 100, "p50": 180, "p75": 300}', 'Sophisticated grammar'),
    (t5_id, 'connector_use', '{"p25": 60, "p50": 120, "p75": 200}', 'Complex connectors'),
    (t5_id, 'academic_vocab_pct', '{"p25": 10, "p50": 20, "p75": 35}', 'Using academic words')
  ON CONFLICT DO NOTHING;
END $$;
