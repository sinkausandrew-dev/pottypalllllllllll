-- Update voice_preference column to support new AI voice characters
-- New options: nova, shimmer, echo, fable, alloy, onyx (OpenAI voices with character names)

-- First, update any existing preferences to map to new values
UPDATE children SET voice_preference = 'nova' WHERE voice_preference = 'female';
UPDATE children SET voice_preference = 'onyx' WHERE voice_preference = 'male';
UPDATE children SET voice_preference = 'shimmer' WHERE voice_preference = 'child';

-- The column type stays as text to support any voice preference string
