-- Add notes field to children table for caregivers to add notes about each child
ALTER TABLE children ADD COLUMN IF NOT EXISTS notes TEXT DEFAULT NULL;

-- Add a comment explaining the field
COMMENT ON COLUMN children.notes IS 'Caregiver notes about the child (progress, preferences, etc.)';
