-- Clean vocabulary system migration
-- Drops and recreates tables to ensure correct schema

-- Drop existing tables if they exist (in correct order for foreign keys)
DROP TABLE IF EXISTS caregiver_pings CASCADE;
DROP TABLE IF EXISTS vocabulary_words CASCADE;
DROP TABLE IF EXISTS vocabulary_categories CASCADE;

-- Vocabulary categories (per-child customizable)
CREATE TABLE vocabulary_categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  caregiver_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  child_id UUID REFERENCES children(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  icon TEXT DEFAULT 'folder',
  color TEXT DEFAULT '#6366f1',
  display_order INTEGER DEFAULT 0,
  is_system BOOLEAN DEFAULT FALSE,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Vocabulary words/phrases
CREATE TABLE vocabulary_words (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  caregiver_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  child_id UUID REFERENCES children(id) ON DELETE CASCADE,
  category_id UUID REFERENCES vocabulary_categories(id) ON DELETE SET NULL,
  word TEXT NOT NULL,
  phrase TEXT,
  display_text TEXT,
  icon TEXT DEFAULT 'message-circle',
  color TEXT,
  image_url TEXT,
  is_ping_enabled BOOLEAN DEFAULT FALSE,
  ping_priority TEXT DEFAULT 'normal' CHECK (ping_priority IN ('low', 'normal', 'high', 'urgent')),
  display_order INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT TRUE,
  is_favorite BOOLEAN DEFAULT FALSE,
  times_used INTEGER DEFAULT 0,
  last_used_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Caregiver pings (alerts sent from child to caregiver)
CREATE TABLE caregiver_pings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  child_id UUID NOT NULL REFERENCES children(id) ON DELETE CASCADE,
  caregiver_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  word_id UUID REFERENCES vocabulary_words(id) ON DELETE SET NULL,
  message TEXT NOT NULL,
  priority TEXT DEFAULT 'normal' CHECK (priority IN ('low', 'normal', 'high', 'urgent')),
  is_read BOOLEAN DEFAULT FALSE,
  read_at TIMESTAMPTZ,
  responded_at TIMESTAMPTZ,
  response_note TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE vocabulary_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE vocabulary_words ENABLE ROW LEVEL SECURITY;
ALTER TABLE caregiver_pings ENABLE ROW LEVEL SECURITY;

-- RLS Policies for vocabulary_categories
CREATE POLICY "Users can view own vocabulary categories" ON vocabulary_categories
  FOR SELECT USING (auth.uid() = caregiver_id);

CREATE POLICY "Users can insert own vocabulary categories" ON vocabulary_categories
  FOR INSERT WITH CHECK (auth.uid() = caregiver_id);

CREATE POLICY "Users can update own vocabulary categories" ON vocabulary_categories
  FOR UPDATE USING (auth.uid() = caregiver_id);

CREATE POLICY "Users can delete own vocabulary categories" ON vocabulary_categories
  FOR DELETE USING (auth.uid() = caregiver_id);

-- RLS Policies for vocabulary_words
CREATE POLICY "Users can view own vocabulary words" ON vocabulary_words
  FOR SELECT USING (auth.uid() = caregiver_id);

CREATE POLICY "Users can insert own vocabulary words" ON vocabulary_words
  FOR INSERT WITH CHECK (auth.uid() = caregiver_id);

CREATE POLICY "Users can update own vocabulary words" ON vocabulary_words
  FOR UPDATE USING (auth.uid() = caregiver_id);

CREATE POLICY "Users can delete own vocabulary words" ON vocabulary_words
  FOR DELETE USING (auth.uid() = caregiver_id);

-- RLS Policies for caregiver_pings
CREATE POLICY "Users can view pings for their children" ON caregiver_pings
  FOR SELECT USING (auth.uid() = caregiver_id);

CREATE POLICY "Anyone can create pings" ON caregiver_pings
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Users can update own pings" ON caregiver_pings
  FOR UPDATE USING (auth.uid() = caregiver_id);

-- Indexes for performance
CREATE INDEX idx_vocabulary_categories_caregiver ON vocabulary_categories(caregiver_id);
CREATE INDEX idx_vocabulary_categories_child ON vocabulary_categories(child_id);
CREATE INDEX idx_vocabulary_words_caregiver ON vocabulary_words(caregiver_id);
CREATE INDEX idx_vocabulary_words_child ON vocabulary_words(child_id);
CREATE INDEX idx_vocabulary_words_category ON vocabulary_words(category_id);
CREATE INDEX idx_caregiver_pings_caregiver ON caregiver_pings(caregiver_id);
CREATE INDEX idx_caregiver_pings_child ON caregiver_pings(child_id);
CREATE INDEX idx_caregiver_pings_unread ON caregiver_pings(caregiver_id) WHERE is_read = FALSE;
