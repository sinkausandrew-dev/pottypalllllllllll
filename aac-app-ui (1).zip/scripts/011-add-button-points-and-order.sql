-- Add awards_points field to custom_buttons to let caregivers control which buttons give points
-- Add slot_position for explicit ordering

ALTER TABLE custom_buttons 
ADD COLUMN IF NOT EXISTS awards_points BOOLEAN DEFAULT true;

-- Update existing potty category buttons to award points, communication to not award by default
UPDATE custom_buttons SET awards_points = true WHERE category = 'potty';
UPDATE custom_buttons SET awards_points = false WHERE category = 'communication';
