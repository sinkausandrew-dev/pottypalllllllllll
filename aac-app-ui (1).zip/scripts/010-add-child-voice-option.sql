-- Add 'child' as a voice preference option
-- Drop the old constraint and create a new one with the additional option
ALTER TABLE children DROP CONSTRAINT IF EXISTS children_voice_preference_check;

ALTER TABLE children 
ADD CONSTRAINT children_voice_preference_check 
CHECK (voice_preference IN ('male', 'female', 'child'));
