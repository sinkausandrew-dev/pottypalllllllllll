-- Add avatar_url column to children table for profile pictures
ALTER TABLE children ADD COLUMN IF NOT EXISTS avatar_url TEXT;

-- Add voice_preference column to children table for TTS voice selection
-- Values: 'female' (default), 'male'
ALTER TABLE children ADD COLUMN IF NOT EXISTS voice_preference TEXT DEFAULT 'female';
