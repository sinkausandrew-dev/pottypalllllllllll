-- Celebration Templates System
-- Allows caregivers to create custom celebration screens that can be queued for children

-- Celebration templates table
CREATE TABLE IF NOT EXISTS celebration_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  child_id UUID REFERENCES children(id) ON DELETE CASCADE NOT NULL,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  description TEXT,
  -- Trigger event types
  trigger_event TEXT NOT NULL CHECK (trigger_event IN ('potty_success', 'poop_success', 'pee_success', 'points_milestone', 'custom', 'manual')),
  trigger_points_threshold INTEGER, -- For points_milestone trigger
  -- Visual assets
  image_url TEXT, -- Main celebration image
  background_color TEXT DEFAULT '#1a1a2e',
  accent_color TEXT DEFAULT '#22d3ee',
  -- Audio
  audio_url TEXT, -- Optional celebration sound
  use_default_jingle BOOLEAN DEFAULT true,
  -- Text content
  congratulations_text TEXT, -- Main message shown
  tts_message TEXT, -- What to speak aloud
  -- Character/theme
  theme TEXT DEFAULT 'default' CHECK (theme IN ('default', 'space', 'superhero', 'princess', 'dinosaur', 'animal', 'custom')),
  character_name TEXT, -- e.g., "Spidey", "Elsa"
  -- Status
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Queued celebrations - celebrations waiting to be shown to child
CREATE TABLE IF NOT EXISTS queued_celebrations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  child_id UUID REFERENCES children(id) ON DELETE CASCADE NOT NULL,
  template_id UUID REFERENCES celebration_templates(id) ON DELETE CASCADE NOT NULL,
  queued_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  -- When to show
  show_on_next_open BOOLEAN DEFAULT true,
  show_after_event TEXT, -- 'potty_success', 'any', etc.
  expires_at TIMESTAMPTZ, -- Optional expiration
  -- Status tracking
  status TEXT DEFAULT 'queued' CHECK (status IN ('queued', 'shown', 'expired', 'cancelled')),
  shown_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Celebration history - track what was shown
CREATE TABLE IF NOT EXISTS celebration_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  child_id UUID REFERENCES children(id) ON DELETE CASCADE NOT NULL,
  template_id UUID REFERENCES celebration_templates(id) ON DELETE SET NULL,
  queued_celebration_id UUID REFERENCES queued_celebrations(id) ON DELETE SET NULL,
  -- Snapshot of what was shown (in case template changes)
  celebration_name TEXT,
  celebration_data JSONB, -- Full snapshot
  shown_at TIMESTAMPTZ DEFAULT now(),
  dismissed_at TIMESTAMPTZ,
  -- Metrics
  duration_ms INTEGER -- How long child viewed it
);

-- Enable RLS
ALTER TABLE celebration_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE queued_celebrations ENABLE ROW LEVEL SECURITY;
ALTER TABLE celebration_history ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "celebration_templates_select" ON celebration_templates;
DROP POLICY IF EXISTS "celebration_templates_insert" ON celebration_templates;
DROP POLICY IF EXISTS "celebration_templates_update" ON celebration_templates;
DROP POLICY IF EXISTS "celebration_templates_delete" ON celebration_templates;

DROP POLICY IF EXISTS "queued_celebrations_select" ON queued_celebrations;
DROP POLICY IF EXISTS "queued_celebrations_insert" ON queued_celebrations;
DROP POLICY IF EXISTS "queued_celebrations_update" ON queued_celebrations;
DROP POLICY IF EXISTS "queued_celebrations_delete" ON queued_celebrations;

DROP POLICY IF EXISTS "celebration_history_select" ON celebration_history;
DROP POLICY IF EXISTS "celebration_history_insert" ON celebration_history;

-- Policies for celebration_templates
CREATE POLICY "celebration_templates_select" ON celebration_templates
  FOR SELECT USING (
    child_id IN (SELECT id FROM children WHERE user_id = auth.uid())
    OR created_by = auth.uid()
  );

CREATE POLICY "celebration_templates_insert" ON celebration_templates
  FOR INSERT WITH CHECK (
    child_id IN (SELECT id FROM children WHERE user_id = auth.uid())
  );

CREATE POLICY "celebration_templates_update" ON celebration_templates
  FOR UPDATE USING (
    child_id IN (SELECT id FROM children WHERE user_id = auth.uid())
    OR created_by = auth.uid()
  );

CREATE POLICY "celebration_templates_delete" ON celebration_templates
  FOR DELETE USING (
    child_id IN (SELECT id FROM children WHERE user_id = auth.uid())
    OR created_by = auth.uid()
  );

-- Policies for queued_celebrations
CREATE POLICY "queued_celebrations_select" ON queued_celebrations
  FOR SELECT USING (
    child_id IN (SELECT id FROM children WHERE user_id = auth.uid())
  );

CREATE POLICY "queued_celebrations_insert" ON queued_celebrations
  FOR INSERT WITH CHECK (
    child_id IN (SELECT id FROM children WHERE user_id = auth.uid())
  );

CREATE POLICY "queued_celebrations_update" ON queued_celebrations
  FOR UPDATE USING (
    child_id IN (SELECT id FROM children WHERE user_id = auth.uid())
  );

CREATE POLICY "queued_celebrations_delete" ON queued_celebrations
  FOR DELETE USING (
    child_id IN (SELECT id FROM children WHERE user_id = auth.uid())
  );

-- Policies for celebration_history
CREATE POLICY "celebration_history_select" ON celebration_history
  FOR SELECT USING (
    child_id IN (SELECT id FROM children WHERE user_id = auth.uid())
  );

CREATE POLICY "celebration_history_insert" ON celebration_history
  FOR INSERT WITH CHECK (
    child_id IN (SELECT id FROM children WHERE user_id = auth.uid())
  );

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_celebration_templates_child ON celebration_templates(child_id);
CREATE INDEX IF NOT EXISTS idx_queued_celebrations_child ON queued_celebrations(child_id);
CREATE INDEX IF NOT EXISTS idx_queued_celebrations_status ON queued_celebrations(status) WHERE status = 'queued';
CREATE INDEX IF NOT EXISTS idx_celebration_history_child ON celebration_history(child_id);

-- Update timestamp trigger
CREATE OR REPLACE FUNCTION update_celebration_template_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS celebration_templates_updated_at ON celebration_templates;
CREATE TRIGGER celebration_templates_updated_at
  BEFORE UPDATE ON celebration_templates
  FOR EACH ROW EXECUTE FUNCTION update_celebration_template_timestamp();
