-- Add caregiver invitations table for SMS-based enrollment
-- This allows admins to invite caregivers who can then create their own accounts

-- Create caregiver_invites table
CREATE TABLE IF NOT EXISTS caregiver_invites (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  profile_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  phone VARCHAR(20) NOT NULL,
  invite_code VARCHAR(8) NOT NULL UNIQUE,
  status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'expired', 'cancelled')),
  invited_by UUID REFERENCES auth.users(id),
  accepted_by UUID REFERENCES auth.users(id),
  expires_at TIMESTAMPTZ NOT NULL DEFAULT (NOW() + INTERVAL '7 days'),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  accepted_at TIMESTAMPTZ
);

-- Add user_id to caregivers table to link to authenticated users
ALTER TABLE caregivers ADD COLUMN IF NOT EXISTS user_id UUID REFERENCES auth.users(id);
ALTER TABLE caregivers ADD COLUMN IF NOT EXISTS is_admin BOOLEAN DEFAULT false;
ALTER TABLE caregivers ADD COLUMN IF NOT EXISTS invite_id UUID REFERENCES caregiver_invites(id);

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_caregiver_invites_code ON caregiver_invites(invite_code);
CREATE INDEX IF NOT EXISTS idx_caregiver_invites_phone ON caregiver_invites(phone);
CREATE INDEX IF NOT EXISTS idx_caregiver_invites_profile ON caregiver_invites(profile_id);
CREATE INDEX IF NOT EXISTS idx_caregivers_user_id ON caregivers(user_id);

-- RLS policies for caregiver_invites
ALTER TABLE caregiver_invites ENABLE ROW LEVEL SECURITY;

-- Users can view invites for profiles they own
CREATE POLICY "Users can view their own invites"
  ON caregiver_invites FOR SELECT
  USING (invited_by = auth.uid() OR profile_id IN (
    SELECT id FROM profiles WHERE id IN (
      SELECT profile_id FROM caregivers WHERE user_id = auth.uid()
    )
  ));

-- Users can create invites for their profiles
CREATE POLICY "Users can create invites for their profiles"
  ON caregiver_invites FOR INSERT
  WITH CHECK (invited_by = auth.uid());

-- Users can update their own invites
CREATE POLICY "Users can update their own invites"
  ON caregiver_invites FOR UPDATE
  USING (invited_by = auth.uid() OR profile_id IN (
    SELECT id FROM profiles WHERE id IN (
      SELECT profile_id FROM caregivers WHERE user_id = auth.uid()
    )
  ));

-- Public can view invite by code (for accepting invites)
CREATE POLICY "Anyone can view invite by code"
  ON caregiver_invites FOR SELECT
  USING (true);
