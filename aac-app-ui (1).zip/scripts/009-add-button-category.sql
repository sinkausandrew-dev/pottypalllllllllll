-- Add category field to custom_buttons to distinguish potty training buttons from communication buttons
-- 'potty' = awards points when completed (potty training related)
-- 'communication' = no points, just for communication/requests

ALTER TABLE custom_buttons 
ADD COLUMN IF NOT EXISTS category TEXT DEFAULT 'communication' CHECK (category IN ('potty', 'communication'));

-- Update existing buttons to be communication by default
UPDATE custom_buttons SET category = 'communication' WHERE category IS NULL;
