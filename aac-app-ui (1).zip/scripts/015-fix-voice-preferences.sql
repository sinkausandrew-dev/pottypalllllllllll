-- First drop the existing check constraint
ALTER TABLE children DROP CONSTRAINT IF EXISTS children_voice_preference_check;

-- Update existing values to new voice names
UPDATE children SET voice_preference = 'nova' WHERE voice_preference = 'female';
UPDATE children SET voice_preference = 'onyx' WHERE voice_preference = 'male';
UPDATE children SET voice_preference = 'shimmer' WHERE voice_preference = 'child';

-- Add new check constraint with expanded voice options
ALTER TABLE children ADD CONSTRAINT children_voice_preference_check 
CHECK (voice_preference IN ('nova', 'shimmer', 'onyx', 'alloy', 'echo', 'fable'));
