"use client"

import React from "react"

import { useState, useEffect, Suspense } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { StarField } from "@/components/star-field"
import { PottyPalLogo } from "@/components/pottypal-logo"
import { UserPlus, Check, AlertCircle, ArrowRight, Loader2 } from "lucide-react"
import Link from "next/link"
import Loading from "./loading"

function JoinPageContent({ searchParams }) {
  const router = useRouter()
  const codeFromUrl = searchParams.get("code")

  const [step, setStep] = useState<"code" | "signup" | "success">("code")
  const [inviteCode, setInviteCode] = useState(codeFromUrl || "")
  const [isValidating, setIsValidating] = useState(false)
  const [isSigningUp, setIsSigningUp] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [validatedInvite, setValidatedInvite] = useState<{
    id: string
    profile_id: string
    phone: string
  } | null>(null)

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
  })

  // Auto-validate if code is in URL
  useEffect(() => {
    if (codeFromUrl && codeFromUrl.length >= 6) {
      validateInviteCode()
    }
  }, [codeFromUrl])

  const validateInviteCode = async () => {
    if (!inviteCode.trim() || inviteCode.length < 6) {
      setError("Please enter a valid invite code")
      return
    }

    setIsValidating(true)
    setError(null)

    const supabase = createClient()

    try {
      const { data: invite, error: fetchError } = await supabase
        .from("caregiver_invites")
        .select("*")
        .eq("invite_code", inviteCode.toUpperCase())
        .single()

      if (fetchError || !invite) {
        setError("Invalid invite code. Please check and try again.")
        return
      }

      if (invite.status !== "pending") {
        setError("This invite has already been used or has expired.")
        return
      }

      if (new Date(invite.expires_at) < new Date()) {
        setError("This invite has expired. Please request a new one.")
        return
      }

      setValidatedInvite(invite)
      setStep("signup")
    } catch (err) {
      console.error("Validation error:", err)
      setError("Failed to validate invite code")
    } finally {
      setIsValidating(false)
    }
  }

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!validatedInvite) return

    if (formData.password !== formData.confirmPassword) {
      setError("Passwords do not match")
      return
    }

    if (formData.password.length < 6) {
      setError("Password must be at least 6 characters")
      return
    }

    setIsSigningUp(true)
    setError(null)

    const supabase = createClient()

    try {
      // Create the user account
      const { data: authData, error: signUpError } = await supabase.auth.signUp({
        email: formData.email,
        password: formData.password,
        options: {
          emailRedirectTo: process.env.NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL || `${window.location.origin}/caregiver`,
        },
      })

      if (signUpError) {
        setError(signUpError.message)
        return
      }

      if (!authData.user) {
        setError("Failed to create account")
        return
      }

      // Create a caregiver record linked to the profile
      const { error: caregiverError } = await supabase
        .from("caregivers")
        .insert({
          profile_id: validatedInvite.profile_id,
          name: formData.name,
          email: formData.email,
          phone: validatedInvite.phone,
          user_id: authData.user.id,
          is_admin: false,
          invite_id: validatedInvite.id,
          receive_notifications: true,
        })

      if (caregiverError) {
        console.error("Caregiver creation error:", caregiverError)
        // Don't fail completely, user can still be added later
      }

      // Update the invite status
      await supabase
        .from("caregiver_invites")
        .update({
          status: "accepted",
          accepted_by: authData.user.id,
          accepted_at: new Date().toISOString(),
        })
        .eq("id", validatedInvite.id)

      setStep("success")
    } catch (err) {
      console.error("Signup error:", err)
      setError("Failed to create account")
    } finally {
      setIsSigningUp(false)
    }
  }

  return (
    <main className="relative flex min-h-svh items-center justify-center p-4">
      <StarField />

      <Card className="relative z-10 w-full max-w-md border-border/50 bg-card/90 backdrop-blur-sm">
        <CardHeader className="text-center">
          <div className="mb-4 flex justify-center">
            <PottyPalLogo size="md" />
          </div>
          <CardTitle className="text-2xl">
            {step === "code" && "Join as Caregiver"}
            {step === "signup" && "Create Your Account"}
            {step === "success" && "Welcome!"}
          </CardTitle>
          <CardDescription>
            {step === "code" && "Enter your invite code to join"}
            {step === "signup" && "Set up your login credentials"}
            {step === "success" && "Your account has been created"}
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-6">
          {error && (
            <div className="flex items-center gap-2 rounded-lg bg-red-500/20 p-3 text-red-400">
              <AlertCircle className="h-4 w-4 flex-shrink-0" />
              <span className="text-sm">{error}</span>
            </div>
          )}

          {/* Step 1: Enter Invite Code */}
          {step === "code" && (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="inviteCode">Invite Code</Label>
                <Input
                  id="inviteCode"
                  placeholder="Enter 6-character code"
                  value={inviteCode}
                  onChange={(e) => setInviteCode(e.target.value.toUpperCase())}
                  className="text-center text-xl font-mono tracking-widest uppercase"
                  maxLength={6}
                />
              </div>

              <Button
                onClick={validateInviteCode}
                disabled={isValidating || inviteCode.length < 6}
                className="w-full bg-gradient-to-r from-[var(--space-purple)] to-[var(--space-blue)]"
              >
                {isValidating ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Validating...
                  </>
                ) : (
                  <>
                    Continue
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </>
                )}
              </Button>

              <div className="text-center">
                <p className="text-sm text-muted-foreground">Already have an account?</p>
                <Link href="/auth/login" className="text-sm text-[var(--space-cyan)] hover:underline">
                  Sign in here
                </Link>
              </div>
            </div>
          )}

          {/* Step 2: Create Account */}
          {step === "signup" && (
            <form onSubmit={handleSignUp} className="space-y-4">
              <div className="rounded-lg bg-muted/30 p-3 text-center">
                <p className="text-xs text-muted-foreground">Joining with code</p>
                <p className="font-mono text-lg font-bold text-[var(--space-cyan)]">{inviteCode}</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="name">Your Name</Label>
                <Input
                  id="name"
                  placeholder="Enter your name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="your@email.com"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="Create a password"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  required
                  minLength={6}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirmPassword">Confirm Password</Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  placeholder="Confirm your password"
                  value={formData.confirmPassword}
                  onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                  required
                />
              </div>

              <Button
                type="submit"
                disabled={isSigningUp || !formData.name || !formData.email || !formData.password}
                className="w-full bg-gradient-to-r from-[var(--space-purple)] to-[var(--space-blue)]"
              >
                {isSigningUp ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Creating Account...
                  </>
                ) : (
                  <>
                    <UserPlus className="mr-2 h-4 w-4" />
                    Create Account
                  </>
                )}
              </Button>

              <Button
                type="button"
                variant="ghost"
                onClick={() => {
                  setStep("code")
                  setValidatedInvite(null)
                }}
                className="w-full"
              >
                Back to invite code
              </Button>
            </form>
          )}

          {/* Step 3: Success */}
          {step === "success" && (
            <div className="space-y-6 text-center">
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-green-500/20">
                <Check className="h-8 w-8 text-green-400" />
              </div>

              <div>
                <p className="text-muted-foreground">
                  Check your email to verify your account, then you can sign in.
                </p>
              </div>

              <Button
                onClick={() => router.push("/auth/login")}
                className="w-full bg-gradient-to-r from-[var(--space-purple)] to-[var(--space-blue)]"
              >
                Go to Sign In
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </main>
  )
}

export default function JoinPage({ searchParams }) {
  return (
    <Suspense fallback={<Loading />}>
      <JoinPageContent searchParams={searchParams} />
    </Suspense>
  )
}
