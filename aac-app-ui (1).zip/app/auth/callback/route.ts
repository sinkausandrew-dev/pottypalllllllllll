import { createClient } from "@/lib/supabase/server"
import { NextResponse } from "next/server"

export async function GET(request: Request) {
  const { searchParams, origin } = new URL(request.url)
  const code = searchParams.get("code")
  const next = searchParams.get("next") ?? "/onboarding"

  if (code) {
    const supabase = await createClient()
    const { error } = await supabase.auth.exchangeCodeForSession(code)
    
    if (!error) {
      // Check if user has a profile
      const { data: { user } } = await supabase.auth.getUser()
      
      if (user) {
        const { data: profile } = await supabase
          .from("profiles")
          .select("*")
          .eq("id", user.id)
          .maybeSingle()

        if (profile) {
          // User has profile, go to mode selection
          return NextResponse.redirect(`${origin}/mode-select`)
        } else {
          // No profile yet, go to onboarding
          return NextResponse.redirect(`${origin}/onboarding`)
        }
      }
    }
  }

  // Return to home page if something went wrong
  return NextResponse.redirect(`${origin}/auth/login?error=Could not verify email`)
}
