"use client"

import type React from "react"

import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { useState, useEffect } from "react"
import { StarField } from "@/components/star-field"
import { SpaceAstronaut } from "@/components/space-astronaut"
import { Eye, EyeOff, Mail, Phone } from "lucide-react"

// Google icon component
function GoogleIcon({ className = "h-5 w-5" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24">
      <path
        fill="#4285F4"
        d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
      />
      <path
        fill="#34A853"
        d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
      />
      <path
        fill="#FBBC05"
        d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
      />
      <path
        fill="#EA4335"
        d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
      />
    </svg>
  )
}

export default function LoginPage() {
  const [authMethod, setAuthMethod] = useState<"email" | "phone">("email")
  const [email, setEmail] = useState("")
  const [phone, setPhone] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [rememberMe, setRememberMe] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [otpSent, setOtpSent] = useState(false)
  const [otp, setOtp] = useState("")
  const router = useRouter()

  // Load saved email if remember me was enabled
  useEffect(() => {
    const savedEmail = localStorage.getItem("pottypal_saved_email")
    if (savedEmail) {
      setEmail(savedEmail)
      setRememberMe(true)
    }
  }, [])

  // Format phone number for display
  const formatPhoneDisplay = (value: string) => {
    const digits = value.replace(/\D/g, "")
    if (digits.length <= 3) return digits
    if (digits.length <= 6) return `(${digits.slice(0, 3)}) ${digits.slice(3)}`
    return `(${digits.slice(0, 3)}) ${digits.slice(3, 6)}-${digits.slice(6, 10)}`
  }

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatPhoneDisplay(e.target.value)
    setPhone(formatted)
  }

  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError(null)

    try {
      const supabase = createClient()
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      })
      if (error) throw error
      
      // Save email if remember me is checked
      if (rememberMe) {
        localStorage.setItem("pottypal_saved_email", email)
        localStorage.setItem("pottypal_remember_me", "true")
      } else {
        localStorage.removeItem("pottypal_saved_email")
        localStorage.removeItem("pottypal_remember_me")
      }
      
      router.push("/")
      router.refresh()
    } catch (error: unknown) {
      setError(error instanceof Error ? error.message : "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError(null)

    const phoneDigits = phone.replace(/\D/g, "")
    if (phoneDigits.length !== 10) {
      setError("Please enter a valid 10-digit phone number")
      setIsLoading(false)
      return
    }

    try {
      const supabase = createClient()
      const { error } = await supabase.auth.signInWithOtp({
        phone: `+1${phoneDigits}`,
      })
      if (error) throw error
      setOtpSent(true)
    } catch (error: unknown) {
      setError(error instanceof Error ? error.message : "Failed to send verification code")
    } finally {
      setIsLoading(false)
    }
  }

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError(null)

    const phoneDigits = phone.replace(/\D/g, "")

    try {
      const supabase = createClient()
      const { error } = await supabase.auth.verifyOtp({
        phone: `+1${phoneDigits}`,
        token: otp,
        type: "sms",
      })
      if (error) throw error
      
      router.push("/")
      router.refresh()
    } catch (error: unknown) {
      setError(error instanceof Error ? error.message : "Invalid verification code")
    } finally {
      setIsLoading(false)
    }
  }

  const handleLogin = (e: React.FormEvent) => {
    if (authMethod === "email") {
      handleEmailLogin(e)
    } else {
      handleSendOtp(e)
    }
  }

  const handleGoogleSignIn = async () => {
    setIsLoading(true)
    setError(null)
    try {
      const supabase = createClient()
      const { error } = await supabase.auth.signInWithOAuth({
        provider: "google",
        options: {
          redirectTo: `${window.location.origin}/auth/callback`,
        },
      })
      if (error) throw error
    } catch (error: unknown) {
      setError(error instanceof Error ? error.message : "Failed to sign in with Google")
      setIsLoading(false)
    }
  }

  return (
    <div className="relative flex min-h-svh w-full items-center justify-center p-6 bg-slate-900">
      <StarField />

      <div className="relative z-10 w-full max-w-md flex flex-col items-center">
        {/* Space astronaut illustration */}
        <SpaceAstronaut className="mb-6" />

        <Card className="w-full glass-card border-slate-700/50">
          <CardHeader className="text-center pb-4">
            <CardTitle className="text-2xl text-slate-100 text-glow-cyan">Welcome back</CardTitle>
            <CardDescription className="text-slate-400">Enter your credentials to access your account</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs value={authMethod} onValueChange={(v) => { setAuthMethod(v as "email" | "phone"); setError(null); setOtpSent(false) }}>
              <TabsList className="grid w-full grid-cols-2 mb-4 bg-slate-800/50 border border-slate-700/50">
                <TabsTrigger value="email" className="flex items-center gap-2 data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400 text-slate-400">
                  <Mail className="h-4 w-4" />
                  Email
                </TabsTrigger>
                <TabsTrigger value="phone" className="flex items-center gap-2 data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400 text-slate-400">
                  <Phone className="h-4 w-4" />
                  Phone
                </TabsTrigger>
              </TabsList>

              {/* Email Login */}
              <TabsContent value="email">
                <form onSubmit={handleEmailLogin}>
                  <div className="flex flex-col gap-5">
                    <div className="grid gap-2">
                      <Label htmlFor="email" className="text-slate-200">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="your@email.com"
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="h-12 bg-slate-800/50 border-slate-700/50 focus:border-cyan-500/50 focus:ring-cyan-500/20 text-slate-100 placeholder:text-slate-500"
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="password" className="text-slate-200">Password</Label>
                      <div className="relative">
                        <Input
                          id="password"
                          type={showPassword ? "text" : "password"}
                          required
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          className="h-12 bg-slate-800/50 border-slate-700/50 focus:border-cyan-500/50 focus:ring-cyan-500/20 text-slate-100 pr-12"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-cyan-400 transition-colors"
                          aria-label={showPassword ? "Hide password" : "Show password"}
                        >
                          {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                        </button>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Checkbox
                        id="remember-me"
                        checked={rememberMe}
                        onCheckedChange={(checked) => setRememberMe(checked === true)}
                        className="border-slate-600 data-[state=checked]:bg-cyan-500 data-[state=checked]:border-cyan-500"
                      />
                      <Label htmlFor="remember-me" className="text-sm cursor-pointer text-slate-300">
                        Keep me signed in
                      </Label>
                    </div>
                    {error && <p className="text-sm text-red-400">{error}</p>}
                    <Button
                      type="submit"
                      className="h-12 w-full text-base bg-gradient-to-r from-cyan-500 to-cyan-400 text-slate-900 font-medium hover:from-cyan-400 hover:to-cyan-300 shadow-lg shadow-cyan-500/20"
                      disabled={isLoading}
                    >
                      {isLoading ? "Signing in..." : "Sign In"}
                    </Button>
                  </div>
                </form>
              </TabsContent>

              {/* Phone Login */}
              <TabsContent value="phone">
                {!otpSent ? (
                  <form onSubmit={handleSendOtp}>
                    <div className="flex flex-col gap-5">
                      <div className="grid gap-2">
                        <Label htmlFor="phone" className="text-slate-200">Phone Number</Label>
                        <div className="relative">
                          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">+1</span>
                          <Input
                            id="phone"
                            type="tel"
                            placeholder="(555) 123-4567"
                            required
                            value={phone}
                            onChange={handlePhoneChange}
                            className="h-12 bg-slate-800/50 border-slate-700/50 focus:border-cyan-500/50 focus:ring-cyan-500/20 text-slate-100 pl-10 placeholder:text-slate-500"
                            maxLength={14}
                          />
                        </div>
                        <p className="text-xs text-slate-400">US numbers only. Standard SMS rates may apply.</p>
                      </div>
                      {error && <p className="text-sm text-red-400">{error}</p>}
                      <Button
                        type="submit"
                        className="h-12 w-full text-base bg-gradient-to-r from-cyan-500 to-cyan-400 text-slate-900 font-medium hover:from-cyan-400 hover:to-cyan-300 shadow-lg shadow-cyan-500/20"
                        disabled={isLoading}
                      >
                        {isLoading ? "Sending code..." : "Send Verification Code"}
                      </Button>
                    </div>
                  </form>
                ) : (
                  <form onSubmit={handleVerifyOtp}>
                    <div className="flex flex-col gap-5">
                      <div className="text-center text-sm text-slate-400">
                        {"We sent a code to "}<span className="font-medium text-cyan-400">{phone}</span>
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="otp" className="text-slate-200">Verification Code</Label>
                        <Input
                          id="otp"
                          type="text"
                          inputMode="numeric"
                          placeholder="123456"
                          required
                          value={otp}
                          onChange={(e) => setOtp(e.target.value.replace(/\D/g, "").slice(0, 6))}
                          className="h-12 bg-slate-800/50 border-slate-700/50 focus:border-cyan-500/50 focus:ring-cyan-500/20 text-slate-100 text-center text-xl tracking-widest"
                          maxLength={6}
                        />
                      </div>
                      {error && <p className="text-sm text-red-400">{error}</p>}
                      <Button
                        type="submit"
                        className="h-12 w-full text-base bg-gradient-to-r from-cyan-500 to-cyan-400 text-slate-900 font-medium hover:from-cyan-400 hover:to-cyan-300 shadow-lg shadow-cyan-500/20"
                        disabled={isLoading || otp.length !== 6}
                      >
                        {isLoading ? "Verifying..." : "Verify & Sign In"}
                      </Button>
                      <button
                        type="button"
                        onClick={() => { setOtpSent(false); setOtp(""); setError(null) }}
                        className="text-sm text-slate-400 hover:text-cyan-400 transition-colors"
                      >
                        Use a different number
                      </button>
                    </div>
                  </form>
                )}
              </TabsContent>
            </Tabs>

            {/* Divider */}
            <div className="relative my-6">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t border-slate-700/50" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-slate-800/80 px-2 text-slate-500">Or continue with</span>
              </div>
            </div>

            {/* Google Sign In */}
            <Button
              type="button"
              variant="outline"
              className="w-full h-12 border-slate-600 bg-slate-800/50 text-slate-200 hover:bg-slate-700/50 hover:text-slate-100 hover:border-slate-500"
              onClick={handleGoogleSignIn}
              disabled={isLoading}
            >
              <GoogleIcon className="mr-2 h-5 w-5" />
              Sign in with Google
            </Button>

            <div className="mt-6 text-center text-sm text-slate-400">
              {"Don't have an account? "}
              <Link href="/auth/sign-up" className="text-cyan-400 hover:text-cyan-300 underline underline-offset-4">
                Sign up
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
