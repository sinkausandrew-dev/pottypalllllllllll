import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { ModeSelector } from "@/components/mode-selector"
import { StarField } from "@/components/star-field"

export default async function ModeSelectPage() {
  let profile = null
  // biome-ignore lint/suspicious/noExplicitAny: Supabase returns dynamic data
  let children: any[] = []
  let redirectTo: string | null = null

  try {
    const supabase = await createClient()
    const { data, error } = await supabase.auth.getUser()

    if (error || !data?.user) {
      redirectTo = "/auth/login"
    } else {
      const user = data.user

      // Get profile (for passcode and backward compatibility)
      const { data: profileData } = await supabase.from("profiles").select("*").eq("id", user.id).maybeSingle()
      profile = profileData

      // Get children (new multi-child support)
      const { data: childrenData } = await supabase
        .from("children")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: true })
      children = childrenData || []

      // If no profile and no children, redirect to onboarding
      if (!profile && children.length === 0) {
        redirectTo = "/onboarding"
      }
    }
  } catch (error) {
    // Supabase connection failed - redirect to login
    console.error("Supabase connection error:", error)
    redirectTo = "/auth/login"
  }

  // Perform redirect outside try-catch
  if (redirectTo) {
    redirect(redirectTo)
  }

  return (
    <main className="relative flex min-h-svh flex-col items-center justify-center overflow-hidden p-6 bg-slate-900">
      <StarField />
      <div className="relative z-10 w-full max-w-sm">
        <ModeSelector profile={profile} children={children} />
      </div>
    </main>
  )
}
