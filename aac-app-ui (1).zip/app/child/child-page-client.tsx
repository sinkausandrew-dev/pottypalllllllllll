"use client"

import { ChildModeTabs } from "@/components/child-mode-tabs"
import { CelebrationOverlay } from "@/components/celebration-overlay"
import { QueuedCelebrationHandler } from "@/components/queued-celebration-handler"
import type { CustomButton, Caregiver } from "@/lib/types"

interface ChildPageClientProps {
  childName: string
  totalPoints: number
  avatarUrl: string | null
  childId: string
  userId: string
  caregiverId: string
  hasPendingRequest: boolean
  pendingRequestType?: string
  pendingRequestId?: string
  pendingRequestCreatedAt?: string
  pendingCustomButtonId?: string | null
  customButtons: CustomButton[]
  voicePreference: "male" | "female" | "child"
  caregivers: Caregiver[]
  showCelebration: boolean
  celebrationPoints: number
}

export function ChildPageClient({
  childName,
  totalPoints,
  avatarUrl,
  childId,
  userId,
  caregiverId,
  hasPendingRequest,
  pendingRequestType,
  pendingRequestId,
  pendingRequestCreatedAt,
  pendingCustomButtonId,
  customButtons,
  voicePreference,
  caregivers,
  showCelebration,
  celebrationPoints,
}: ChildPageClientProps) {
  return (
    <>
      {showCelebration && (
        <CelebrationOverlay 
          pointsEarned={celebrationPoints} 
          childName={childName} 
        />
      )}
      {/* Handle queued celebrations from AI assistant */}
      <QueuedCelebrationHandler childId={childId} childName={childName} />
      <ChildModeTabs
        childName={childName}
        totalPoints={totalPoints}
        avatarUrl={avatarUrl}
        childId={childId}
        userId={userId}
        caregiverId={caregiverId}
        hasPendingRequest={hasPendingRequest}
        pendingRequestType={pendingRequestType as "pee" | "poop" | undefined}
        pendingRequestId={pendingRequestId}
        pendingRequestCreatedAt={pendingRequestCreatedAt}
        pendingCustomButtonId={pendingCustomButtonId || undefined}
        customButtons={customButtons}
        voicePreference={voicePreference}
        caregivers={caregivers}
      />
    </>
  )
}
