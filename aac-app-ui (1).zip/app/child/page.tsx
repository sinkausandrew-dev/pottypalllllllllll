import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { ChildModeTabs } from "@/components/child-mode-tabs"
import { CelebrationOverlay } from "@/components/celebration-overlay"
import { ChildPageClient } from "./child-page-client"

interface ChildPageProps {
  searchParams: Promise<{ childId?: string; demo?: string }>
}

// Check if Supabase is properly configured
function isSupabaseConfigured() {
  return !!(process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY)
}

export default async function ChildPage({ searchParams }: ChildPageProps) {
  const params = await searchParams
  const isDemo = params.demo === "true" || !isSupabaseConfigured()

  // Demo mode - show the app without authentication
  if (isDemo) {
    return (
      <ChildModeTabs
        childName="Demo Child"
        totalPoints={25}
        childId="demo-child-id"
        userId="demo-user-id"
        caregiverId="demo-caregiver-id"
        hasPendingRequest={false}
        customButtons={[]}
        voicePreference="female"
      />
    )
  }

  let redirectTo: string | null = null
  let supabase: Awaited<ReturnType<typeof createClient>> | null = null
  let user: { id: string } | null = null

  try {
    supabase = await createClient()
    const { data, error } = await supabase.auth.getUser()

    if (error || !data?.user) {
      redirectTo = "/auth/login"
    } else {
      user = data.user
    }
  } catch (error) {
    console.error("Supabase connection error:", error)
    // Fall back to demo mode on error
    return (
      <ChildModeTabs
        childName="Demo Child"
        totalPoints={25}
        childId="demo-child-id"
        userId="demo-user-id"
        caregiverId="demo-caregiver-id"
        hasPendingRequest={false}
        customButtons={[]}
        voicePreference="female"
      />
    )
  }

  // Perform redirect outside try-catch
  if (redirectTo || !supabase || !user) {
    redirect(redirectTo || "/auth/login")
  }

  const { childId } = await searchParams

  // First check if we have a childId and try to get the child from children table
  let childName: string
  let totalPoints: number
  let avatarUrl: string | null = null
  let actualChildId: string
  let caregiverId: string
  let voicePreference: "male" | "female" | "child" = "female"

  if (childId) {
    // Fetch from children table using the childId
    const { data: child } = await supabase
      .from("children")
      .select("*")
      .eq("id", childId)
      .eq("user_id", user.id)
      .maybeSingle()

    if (child) {
      childName = child.child_name
      totalPoints = child.total_points
      avatarUrl = child.avatar_url || null
      actualChildId = child.id
      caregiverId = child.caregiver_id
      voicePreference = child.voice_preference || "female"
    } else {
      // Child not found or doesn't belong to user, redirect to mode select
      redirect("/mode-select")
    }
  } else {
    // No childId provided - try to get the first child from children table
    const { data: children } = await supabase
      .from("children")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: true })
      .limit(1)

    if (children && children.length > 0) {
      childName = children[0].child_name
      totalPoints = children[0].total_points
      avatarUrl = children[0].avatar_url || null
      actualChildId = children[0].id
      caregiverId = children[0].caregiver_id
      voicePreference = children[0].voice_preference || "female"
    } else {
      // Fall back to profile for legacy support
      const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).maybeSingle()

      if (!profile) {
        redirect("/onboarding")
      }

      childName = profile.child_name
      totalPoints = profile.total_points
      actualChildId = user.id // Legacy: use user.id as child identifier
      caregiverId = user.id // Legacy: use user.id as caregiver identifier
    }
  }

  // Check for recently completed requests (within last 30 seconds) to show celebration
  // Try child_id first, then fall back to profile_id for legacy data
  const { data: recentCompleted } = await supabase
    .from("bathroom_requests")
    .select("*")
    .or(`child_id.eq.${actualChildId},profile_id.eq.${actualChildId}`)
    .eq("status", "completed")
    .gte("completed_at", new Date(Date.now() - 30000).toISOString())
    .order("completed_at", { ascending: false })
    .limit(1)

  // Check for pending requests
  const { data: pendingRequest } = await supabase
    .from("bathroom_requests")
    .select("*")
    .or(`child_id.eq.${actualChildId},profile_id.eq.${actualChildId}`)
    .eq("status", "pending")
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle()

  // Fetch custom buttons for this child
  const { data: customButtons } = await supabase
    .from("custom_buttons")
    .select("*")
    .eq("child_id", actualChildId)
    .eq("is_active", true)
    .order("display_order", { ascending: true })

  // Fetch caregivers who can receive notifications
  const { data: caregivers } = await supabase
    .from("caregivers")
    .select("*")
    .eq("profile_id", user.id)
    .eq("receive_notifications", true)
    .order("is_admin", { ascending: false })

  const showCelebration = recentCompleted && recentCompleted.length > 0
  const celebrationPoints = showCelebration ? recentCompleted[0].points_awarded : 0

  return (
    <ChildPageClient
      childName={childName}
      totalPoints={totalPoints}
      avatarUrl={avatarUrl}
      childId={actualChildId}
      userId={user.id}
      caregiverId={caregiverId}
      hasPendingRequest={!!pendingRequest}
      pendingRequestType={pendingRequest?.request_type}
      pendingRequestId={pendingRequest?.id}
      pendingRequestCreatedAt={pendingRequest?.created_at}
      pendingCustomButtonId={pendingRequest?.custom_button_id}
      customButtons={customButtons || []}
      voicePreference={voicePreference}
      caregivers={caregivers || []}
      showCelebration={showCelebration}
      celebrationPoints={celebrationPoints}
    />
  )
}
