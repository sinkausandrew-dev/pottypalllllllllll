import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { RewardsStore } from "@/components/rewards-store"

interface RewardsPageProps {
  searchParams: Promise<{ childId?: string }>
}

export default async function RewardsPage({ searchParams }: RewardsPageProps) {
  const supabase = await createClient()
  const { childId } = await searchParams
  
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Get child data based on childId or fall back to first child/profile
  let childName: string
  let totalPoints: number
  let actualChildId: string

  if (childId) {
    const { data: child } = await supabase
      .from("children")
      .select("*")
      .eq("id", childId)
      .eq("user_id", user.id)
      .maybeSingle()

    if (child) {
      childName = child.child_name
      totalPoints = child.total_points
      actualChildId = child.id
    } else {
      redirect("/mode-select")
    }
  } else {
    // Try to get first child
    const { data: children } = await supabase
      .from("children")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: true })
      .limit(1)

    if (children && children.length > 0) {
      childName = children[0].child_name
      totalPoints = children[0].total_points
      actualChildId = children[0].id
    } else {
      // Fall back to profile
      const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).maybeSingle()

      if (!profile) {
        redirect("/onboarding")
      }

      childName = profile.child_name
      totalPoints = profile.total_points
      actualChildId = user.id
    }
  }

  // Fetch active rewards for this child (try child_id first, then profile_id for legacy)
  const { data: rewards } = await supabase
    .from("rewards")
    .select("*")
    .or(`child_id.eq.${actualChildId},profile_id.eq.${actualChildId}`)
    .eq("is_active", true)
    .order("points_cost", { ascending: true })

  return (
    <RewardsStore
      childName={childName}
      totalPoints={totalPoints}
      rewards={rewards || []}
      childId={actualChildId}
      userId={user.id}
    />
  )
}
