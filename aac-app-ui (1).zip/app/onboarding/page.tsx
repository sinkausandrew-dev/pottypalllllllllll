import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { OnboardingForm } from "@/components/onboarding-form"
import { StarField } from "@/components/star-field"

export default async function OnboardingPage({
  searchParams,
}: {
  searchParams: { [key: string]: string | string[] | undefined }
}) {
  let redirectTo: string | null = null
  let supabase: Awaited<ReturnType<typeof createClient>> | null = null
  let user: { id: string } | null = null

  try {
    supabase = await createClient()
    const { data, error } = await supabase.auth.getUser()

    if (error || !data?.user) {
      redirectTo = "/auth/login"
    } else {
      user = data.user
    }
  } catch (error) {
    console.error("Supabase connection error:", error)
    redirectTo = "/auth/login"
  }

  // Perform redirect outside try-catch
  if (redirectTo || !supabase || !user) {
    redirect(redirectTo || "/auth/login")
  }

  // Check if already has profile
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).maybeSingle()

  // Handle searchParams - could be string or string[]
  const addChild = searchParams?.addChild
  const isAddingChild = 
    addChild === "true" || 
    (typeof addChild === "string" && addChild !== "") ||
    (Array.isArray(addChild) && addChild.length > 0)

  // If adding a child, allow even if profile exists
  if (profile && !isAddingChild) {
    redirect("/mode-select")
  }

  return (
    <main className="relative flex min-h-svh flex-col items-center justify-center overflow-hidden p-6 bg-slate-900">
      <StarField />
      <div className="relative z-10 w-full max-w-md">
        <OnboardingForm userId={user.id} isAddingChild={isAddingChild} />
      </div>
    </main>
  )
}
