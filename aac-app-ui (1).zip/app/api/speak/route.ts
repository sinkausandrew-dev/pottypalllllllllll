import { NextResponse } from "next/server"

// This endpoint now just signals to use browser-based TTS
// No paid API needed - all speech synthesis happens client-side
export async function POST(request: Request) {
  try {
    const { text, voice = "female" } = await request.json()

    if (!text || typeof text !== "string") {
      return NextResponse.json({ error: "Text is required" }, { status: 400 })
    }

    // Return signal to use browser TTS with the requested voice preference
    return NextResponse.json({
      useBrowserTTS: true,
      text,
      voice,
    })
  } catch (error) {
    console.error("TTS API error:", error)
    return NextResponse.json({ useBrowserTTS: true, error: "TTS setup failed" }, { status: 200 })
  }
}
