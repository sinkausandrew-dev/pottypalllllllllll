import { NextResponse } from "next/server"
import { createServerClient } from "@supabase/ssr"
import { cookies } from "next/headers"
import webpush from "web-push"

// Configure web-push with VAPID keys
// These should be generated once and stored in environment variables
const VAPID_PUBLIC_KEY = process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY || ""
const VAPID_PRIVATE_KEY = process.env.VAPID_PRIVATE_KEY || ""
const VAPID_EMAIL = process.env.VAPID_EMAIL || "mailto:admin@pottypal.app"

if (VAPID_PUBLIC_KEY && VAPID_PRIVATE_KEY) {
  webpush.setVapidDetails(VAPID_EMAIL, VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY)
}

export async function POST(request: Request) {
  try {
    const { childId, childName, phrase, isUrgent, pingId } = await request.json()

    if (!childId || !phrase) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const cookieStore = await cookies()
    const supabase = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          getAll() {
            return cookieStore.getAll()
          },
          setAll(cookiesToSet) {
            cookiesToSet.forEach(({ name, value, options }) =>
              cookieStore.set(name, value, options)
            )
          },
        },
      }
    )

    // Get the child's caregiver info to find push subscriptions
    const { data: child, error: childError } = await supabase
      .from("children")
      .select("caregiver_id")
      .eq("id", childId)
      .single()

    if (childError || !child) {
      console.error("Error finding child:", childError)
      return NextResponse.json({ error: "Child not found" }, { status: 404 })
    }

    // Get all caregivers linked to this profile who have push subscriptions
    const { data: caregivers, error: caregiverError } = await supabase
      .from("caregivers")
      .select("id, name, push_subscription")
      .eq("profile_id", child.caregiver_id)
      .eq("receive_notifications", true)
      .not("push_subscription", "is", null)

    if (caregiverError) {
      console.error("Error finding caregivers:", caregiverError)
    }

    // Also check the push_subscriptions table
    const { data: pushSubs, error: pushSubsError } = await supabase
      .from("push_subscriptions")
      .select("*")
      .eq("profile_id", child.caregiver_id)

    if (pushSubsError) {
      console.error("Error finding push subscriptions:", pushSubsError)
    }

    const notificationPayload = JSON.stringify({
      title: isUrgent ? `URGENT: ${childName}` : `Message from ${childName}`,
      body: phrase,
      icon: "/icon-192.png",
      badge: "/badge-72.png",
      tag: `ping-${pingId}`,
      data: {
        url: `/caregiver?ping=${pingId}`,
        pingId,
        childId,
        isUrgent,
      },
      vibrate: isUrgent ? [200, 100, 200, 100, 200] : [200, 100, 200],
      requireInteraction: isUrgent,
    })

    const sendResults: Array<{ success: boolean; target: string; error?: string }> = []

    // Send to caregivers with stored push subscriptions
    if (caregivers && VAPID_PUBLIC_KEY && VAPID_PRIVATE_KEY) {
      for (const caregiver of caregivers) {
        if (caregiver.push_subscription) {
          try {
            await webpush.sendNotification(
              caregiver.push_subscription as webpush.PushSubscription,
              notificationPayload
            )
            sendResults.push({ success: true, target: caregiver.name })
          } catch (error: unknown) {
            const errorMessage = error instanceof Error ? error.message : "Unknown error"
            console.error(`Failed to send to ${caregiver.name}:`, error)
            sendResults.push({ success: false, target: caregiver.name, error: errorMessage })

            // If subscription is expired/invalid, remove it
            if (errorMessage.includes("410") || errorMessage.includes("expired")) {
              await supabase
                .from("caregivers")
                .update({ push_subscription: null })
                .eq("id", caregiver.id)
            }
          }
        }
      }
    }

    // Send to push_subscriptions table entries
    if (pushSubs && VAPID_PUBLIC_KEY && VAPID_PRIVATE_KEY) {
      for (const sub of pushSubs) {
        try {
          const subscription = {
            endpoint: sub.endpoint,
            keys: {
              p256dh: sub.p256dh,
              auth: sub.auth,
            },
          }
          await webpush.sendNotification(subscription, notificationPayload)
          sendResults.push({ success: true, target: `subscription-${sub.id}` })
        } catch (error: unknown) {
          const errorMessage = error instanceof Error ? error.message : "Unknown error"
          console.error(`Failed to send to subscription ${sub.id}:`, error)
          sendResults.push({ success: false, target: `subscription-${sub.id}`, error: errorMessage })

          // Remove invalid subscription
          if (errorMessage.includes("410") || errorMessage.includes("expired")) {
            await supabase.from("push_subscriptions").delete().eq("id", sub.id)
          }
        }
      }
    }

    // Log the ping attempt
    console.log(`Ping sent: "${phrase}" from ${childName} (urgent: ${isUrgent})`, sendResults)

    return NextResponse.json({
      success: true,
      sent: sendResults.filter((r) => r.success).length,
      failed: sendResults.filter((r) => !r.success).length,
      results: sendResults,
    })
  } catch (error) {
    console.error("Error sending ping notification:", error)
    return NextResponse.json({ error: "Failed to send notification" }, { status: 500 })
  }
}
