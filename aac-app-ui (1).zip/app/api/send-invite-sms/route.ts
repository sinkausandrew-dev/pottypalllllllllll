import { NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

// Generate a random 6-character invite code
function generateInviteCode(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789" // Exclude confusing characters
  let code = ""
  for (let i = 0; i < 6; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length))
  }
  return code
}

// Format phone number for Twilio (E.164 format)
function formatPhoneNumber(phone: string): string {
  const digits = phone.replace(/\D/g, "")
  if (digits.length === 10) {
    return `+1${digits}` // Assume US number
  }
  if (digits.length === 11 && digits.startsWith("1")) {
    return `+${digits}`
  }
  return `+${digits}`
}

export async function POST(request: Request) {
  try {
    const { phone, profileId, inviterName } = await request.json()

    if (!phone || !profileId) {
      return NextResponse.json(
        { error: "Phone number and profile ID are required" },
        { status: 400 }
      )
    }

    const supabase = await createClient()

    // Check auth
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Generate unique invite code
    let inviteCode = generateInviteCode()
    let attempts = 0
    while (attempts < 5) {
      const { data: existing } = await supabase
        .from("caregiver_invites")
        .select("id")
        .eq("invite_code", inviteCode)
        .single()

      if (!existing) break
      inviteCode = generateInviteCode()
      attempts++
    }

    // Create invite record
    const { data: invite, error: inviteError } = await supabase
      .from("caregiver_invites")
      .insert({
        profile_id: profileId,
        phone: formatPhoneNumber(phone),
        invite_code: inviteCode,
        invited_by: user.id,
        status: "pending",
      })
      .select()
      .single()

    if (inviteError) {
      console.error("Failed to create invite:", inviteError)
      return NextResponse.json(
        { error: "Failed to create invitation" },
        { status: 500 }
      )
    }

    // Send SMS via Twilio
    const twilioAccountSid = process.env.TWILIO_ACCOUNT_SID
    const twilioAuthToken = process.env.TWILIO_AUTH_TOKEN
    const twilioPhoneNumber = process.env.TWILIO_PHONE_NUMBER

    if (!twilioAccountSid || !twilioAuthToken || !twilioPhoneNumber) {
      // Return success but note SMS wasn't sent (for development)
      return NextResponse.json({
        success: true,
        invite,
        smsSent: false,
        message: "Invite created but SMS not configured. Share code manually.",
        inviteCode,
      })
    }

    // Construct SMS message
    const appUrl = process.env.NEXT_PUBLIC_APP_URL || "https://pottypal.app"
    const smsMessage = `${inviterName || "Someone"} invited you to join PottyPal as a caregiver! Your invite code is: ${inviteCode}\n\nSign up here: ${appUrl}/join?code=${inviteCode}`

    // Send via Twilio
    const twilioUrl = `https://api.twilio.com/2010-04-01/Accounts/${twilioAccountSid}/Messages.json`
    const formData = new URLSearchParams()
    formData.append("To", formatPhoneNumber(phone))
    formData.append("From", twilioPhoneNumber)
    formData.append("Body", smsMessage)

    const twilioResponse = await fetch(twilioUrl, {
      method: "POST",
      headers: {
        "Authorization": `Basic ${Buffer.from(`${twilioAccountSid}:${twilioAuthToken}`).toString("base64")}`,
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: formData.toString(),
    })

    if (!twilioResponse.ok) {
      const errorData = await twilioResponse.json()
      console.error("Twilio error:", errorData)
      
      // Check for trial account / unverified number error
      const isTrialError = errorData?.message?.includes("unverified") || 
                           errorData?.code === 21608 ||
                           errorData?.message?.includes("Trial accounts")
      
      // Still return success since invite was created
      return NextResponse.json({
        success: true,
        invite,
        smsSent: false,
        message: isTrialError 
          ? "Twilio trial account: SMS not sent. Share the code below with your caregiver."
          : "Invite created but SMS failed to send. Share code manually.",
        inviteCode,
        twilioTrialMode: isTrialError,
      })
    }

    return NextResponse.json({
      success: true,
      invite,
      smsSent: true,
      message: "Invitation sent successfully!",
    })
  } catch (error) {
    console.error("Send invite error:", error)
    return NextResponse.json(
      { error: "Failed to send invitation" },
      { status: 500 }
    )
  }
}
