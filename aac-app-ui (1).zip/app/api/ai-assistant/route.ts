import { convertToModelMessages, streamText, tool, stepCountIs, type UIMessage, InferUITools, UIDataTypes, validateUIMessages } from "ai"
import { z } from "zod"
import { createClient } from "@/lib/supabase/server"

export const maxDuration = 30

const SYSTEM_PROMPT = `You are Luca, a friendly and knowledgeable potty training companion for parents and caregivers. You're warm, encouraging, and always positive.

Your role is to:
1. Provide evidence-based potty training advice and strategies
2. Answer questions about readiness signs, timing, and techniques  
3. Offer encouragement and emotional support during this journey
4. Share tips for dealing with common challenges (accidents, regression, nighttime training, etc.)
5. Suggest age-appropriate rewards and positive reinforcement strategies
6. Help troubleshoot specific situations parents describe
7. Schedule celebrations for children when caregivers want to recognize achievements

Your personality:
- Warm, supportive, and never judgmental
- You speak conversationally like a knowledgeable friend
- You use encouraging language and celebrate small wins
- You recognize every child is different - no one-size-fits-all
- You encourage patience and consistency
- You NEVER recommend punishment for accidents
- You suggest consulting a pediatrician for any medical concerns
- You keep responses concise (2-3 short paragraphs max) unless asked for more detail
- You occasionally use light humor to keep things positive

CELEBRATION CAPABILITIES:
When a caregiver wants to celebrate their child, you can:
- Schedule a celebration to appear on the child's screen with animation and voice
- Use the scheduleCelebration tool to queue it
- Available celebration types: potty_success, milestone, encouragement, custom
- You can customize the message, animation type, and points awarded
- The celebration will play with text-to-speech, animation, and confetti

Example triggers for celebrations:
- "Celebrate [child name] for using the potty!"
- "Send a celebration for staying dry all day"
- "Give [child name] a big celebration for trying so hard"

Remember: You're Luca - here to make potty training less stressful and more fun for everyone!`

// Tool for scheduling celebrations
const scheduleCelebrationTool = tool({
  description: "Schedule a celebration to appear on the child's screen with animation, TTS message, and optional points. Use this when caregivers want to celebrate their child's achievements.",
  inputSchema: z.object({
    childId: z.string().describe("The ID of the child to celebrate"),
    celebrationType: z.enum(["potty_success", "milestone", "encouragement", "custom"]).describe("Type of celebration"),
    message: z.string().describe("The celebration message to show and speak aloud to the child (e.g., 'Amazing job using the potty!')"),
    animationType: z.enum(["confetti", "stars", "rockets", "rainbow", "fireworks"]).default("confetti").describe("Visual animation to display"),
    pointsAwarded: z.number().min(0).max(100).default(0).describe("Optional bonus points to award (0-100)"),
    soundEffect: z.enum(["cheer", "fanfare", "magic", "woohoo"]).default("cheer").describe("Sound effect to play"),
  }),
  execute: async ({ childId, celebrationType, message, animationType, pointsAwarded, soundEffect }) => {
    const supabase = await createClient()
    
    // Get the current user
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      return { success: false, error: "Not authenticated" }
    }

    // Queue the celebration
    const { data, error } = await supabase
      .from("queued_celebrations")
      .insert({
        child_id: childId,
        celebration_type: celebrationType,
        message,
        animation_type: animationType,
        points_awarded: pointsAwarded,
        sound_effect: soundEffect,
        triggered_by: user.id,
      })
      .select()
      .single()

    if (error) {
      console.error("Error queuing celebration:", error)
      return { success: false, error: error.message }
    }

    // If points were awarded, update the child's total
    if (pointsAwarded > 0) {
      await supabase.rpc("increment_child_points", {
        child_id_param: childId,
        points_param: pointsAwarded,
      })
    }

    return { 
      success: true, 
      celebrationId: data.id,
      message: `Celebration scheduled! "${message}" will appear on the child's screen with ${animationType} animation and ${pointsAwarded} bonus points.`
    }
  },
})

// Tool for getting child info
const getChildInfoTool = tool({
  description: "Get information about the children associated with the current caregiver, including their names and IDs. Use this to find the child ID before scheduling a celebration.",
  inputSchema: z.object({}),
  execute: async () => {
    const supabase = await createClient()
    
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      return { success: false, error: "Not authenticated", children: [] }
    }

    const { data: children, error } = await supabase
      .from("children")
      .select("id, child_name, total_points")
      .eq("user_id", user.id)

    if (error || !children) {
      return { success: false, error: error?.message || "No children found", children: [] }
    }

    return { 
      success: true, 
      children: children.map(c => ({
        id: c.id,
        name: c.child_name,
        points: c.total_points
      }))
    }
  },
})

// Tool for getting celebration templates
const getCelebrationTemplatesTool = tool({
  description: "Get the caregiver's saved celebration templates for quick access to commonly used celebrations.",
  inputSchema: z.object({}),
  execute: async () => {
    const supabase = await createClient()
    
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      return { success: false, error: "Not authenticated", templates: [] }
    }

    const { data: templates, error } = await supabase
      .from("celebration_templates")
      .select("*")
      .eq("user_id", user.id)
      .eq("is_active", true)
      .order("use_count", { ascending: false })

    if (error || !templates) {
      return { success: false, error: error?.message || "No templates found", templates: [] }
    }

    return { success: true, templates }
  },
})

const tools = {
  scheduleCelebration: scheduleCelebrationTool,
  getChildInfo: getChildInfoTool,
  getCelebrationTemplates: getCelebrationTemplatesTool,
} as const

export type AIAssistantMessage = UIMessage<never, UIDataTypes, InferUITools<typeof tools>>

export async function POST(req: Request) {
  const body = await req.json()
  const { childId, childName } = body

  const messages = await validateUIMessages<AIAssistantMessage>({
    messages: body.messages,
    tools,
  })

  // Build context-aware system prompt
  const contextPrompt = childId && childName 
    ? `${SYSTEM_PROMPT}\n\nCURRENT CONTEXT:\n- You are helping with child: ${childName} (ID: ${childId})\n- When scheduling celebrations for this child, use this ID directly.`
    : SYSTEM_PROMPT

  const result = streamText({
    model: "openai/gpt-4o-mini",
    system: contextPrompt,
    messages: await convertToModelMessages(messages),
    tools,
    stopWhen: stepCountIs(5),
    maxOutputTokens: 1000,
    temperature: 0.7,
    abortSignal: req.signal,
  })

  return result.toUIMessageStreamResponse()
}
