import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const { childName } = await request.json()

    // Fun celebration messages with the child's name
    const celebrationMessages = [
      `Amazing job ${childName}! You're a superstar!`,
      `Way to go ${childName}! You did it!`,
      `Incredible ${childName}! Keep up the great work!`,
      `Awesome ${childName}! You're doing amazing!`,
      `Hooray ${childName}! You're the best!`,
      `Fantastic ${childName}! So proud of you!`,
      `Wow ${childName}! That was awesome!`,
      `Great job ${childName}! You rock!`,
    ]
    
    const randomMessage = celebrationMessages[Math.floor(Math.random() * celebrationMessages.length)]
    return NextResponse.json({ message: randomMessage })
  } catch {
    return NextResponse.json({ message: "Amazing job! You're a superstar!" })
  }
}
