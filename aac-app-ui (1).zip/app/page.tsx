import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { StarField } from "@/components/star-field"
import { PottyPalLogo } from "@/components/pottypal-logo"

export default async function HomePage() {
  let redirectTo: string | null = null

  // Check if Supabase is configured
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
  const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
  const isSupabaseConfigured = supabaseUrl && supabaseAnonKey

  if (isSupabaseConfigured) {
    try {
      const supabase = await createClient()
      
      // Wrap entire auth check in try-catch with timeout
      const checkAuth = async () => {
        try {
          const { data, error } = await supabase.auth.getUser()
          if (error || !data?.user) return null
          return data.user
        } catch {
          return null
        }
      }
      
      // Race between auth check and timeout
      const timeoutPromise = new Promise<null>((resolve) => setTimeout(() => resolve(null), 2000))
      const user = await Promise.race([checkAuth(), timeoutPromise])
      
      if (user) {
        // Check if they have a profile
        try {
          const { data: profile } = await supabase
            .from("profiles")
            .select("id")
            .eq("id", user.id)
            .maybeSingle()

          redirectTo = profile ? "/mode-select" : "/onboarding"
        } catch {
          // Profile check failed - still redirect to mode-select and let that page handle it
          redirectTo = "/mode-select"
        }
      }
    } catch {
      // Supabase client creation failed - show landing page
    }

    // Perform redirect outside try-catch to avoid catching redirect errors
    if (redirectTo) {
      redirect(redirectTo)
    }
  }

  return (
    <main className="relative flex min-h-svh flex-col items-center justify-center overflow-hidden p-6 bg-slate-900">
      <StarField />

      <div className="relative z-10 flex flex-col items-center gap-8 text-center">
        {/* PottyPal Logo */}
        <div className="animate-float">
          <PottyPalLogo size="xl" showText={true} />
        </div>

        {/* Subtitle with more excitement */}
        <div className="space-y-3">
          <p className="text-pretty text-xl font-semibold text-slate-100">
            Your space adventure to success! 🌟
          </p>
          <div className="flex items-center justify-center gap-2 text-lg text-slate-300">
            <span className="animate-pulse">🎉</span>
            <span>Earn rewards, get praise, have fun!</span>
            <span className="animate-pulse">🎉</span>
          </div>
        </div>

        {/* Feature highlights - emphasizing rewards and praise */}
        <div className="grid grid-cols-3 gap-4 w-full max-w-md">
          <div className="flex flex-col items-center gap-2 p-4 rounded-2xl bg-violet-500/10 border border-violet-500/30">
            <div className="text-3xl">⭐</div>
            <p className="text-sm font-semibold text-slate-100">Earn Points</p>
            <p className="text-xs text-slate-400">Every success counts!</p>
          </div>
          <div className="flex flex-col items-center gap-2 p-4 rounded-2xl bg-cyan-500/10 border border-cyan-500/30">
            <div className="text-3xl">🎁</div>
            <p className="text-sm font-semibold text-slate-100">Get Rewards</p>
            <p className="text-xs text-slate-400">Unlock fun prizes!</p>
          </div>
          <div className="flex flex-col items-center gap-2 p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30">
            <div className="text-3xl">👏</div>
            <p className="text-sm font-semibold text-slate-100">Feel Proud</p>
            <p className="text-xs text-slate-400">You're amazing!</p>
          </div>
        </div>

        {/* CTA Buttons with more visual appeal */}
        <div className="flex w-full max-w-xs flex-col gap-4">
          <Button
            asChild
            size="lg"
            className="h-16 text-xl font-bold bg-gradient-to-r from-cyan-500 to-cyan-400 text-slate-900 hover:from-cyan-400 hover:to-cyan-300 transition-all hover:scale-105 active:scale-95 shadow-xl shadow-cyan-500/30"
          >
            <Link href="/auth/sign-up" className="flex items-center gap-2">
              <span>🚀</span>
              <span>Start Your Adventure!</span>
            </Link>
          </Button>
          <Button
            asChild
            variant="outline"
            size="lg"
            className="h-14 text-lg border-2 border-slate-600 bg-transparent text-slate-200 hover:bg-slate-800 hover:text-cyan-400 hover:border-cyan-500/50 transition-all"
          >
            <Link href="/auth/login">I have an account</Link>
          </Button>
        </div>

        {/* Demo mode link for preview */}
        {!isSupabaseConfigured && (
          <Button
            asChild
            variant="ghost"
            size="sm"
            className="text-slate-400 hover:text-cyan-400"
          >
            <Link href="/child?demo=true">Try Demo Mode</Link>
          </Button>
        )}

        {/* Encouraging message */}
        <p className="text-sm text-slate-400 max-w-md">
          Join thousands of kids on their potty training journey!
        </p>

        {/* Referral code signup for caregivers */}
        <div className="mt-4 pt-4 border-t border-slate-700/50 w-full max-w-xs">
          <p className="text-xs text-slate-400 text-center mb-3">
            Have an invite code from a caregiver?
          </p>
          <Button
            asChild
            variant="outline"
            size="sm"
            className="w-full border-cyan-500/30 bg-transparent hover:bg-cyan-500/10 text-cyan-400"
          >
            <Link href="/join">Join with Invite Code</Link>
          </Button>
        </div>
      </div>
    </main>
  )
}
