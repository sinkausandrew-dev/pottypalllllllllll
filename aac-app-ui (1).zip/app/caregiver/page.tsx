import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { CaregiverDashboard } from "@/components/caregiver-dashboard"
import type { Child } from "@/lib/types"

export default async function CaregiverPage() {
  let redirectTo: string | null = null
  let supabase: Awaited<ReturnType<typeof createClient>> | null = null
  let user: { id: string } | null = null

  try {
    supabase = await createClient()
    const { data, error } = await supabase.auth.getUser()

    if (error || !data?.user) {
      redirectTo = "/auth/login"
    } else {
      user = data.user
    }
  } catch (error) {
    console.error("Supabase connection error:", error)
    redirectTo = "/auth/login"
  }

  // Perform redirect outside try-catch
  if (redirectTo || !supabase || !user) {
    redirect(redirectTo || "/auth/login")
  }

  // Fetch profile
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).maybeSingle()

  if (!profile) {
    redirect("/onboarding")
  }

  // Fetch all children for this user
  const { data: childrenData } = await supabase
    .from("children")
    .select("*")
    .eq("user_id", user.id)
    .order("created_at", { ascending: true })

  // If no children in children table, create a fallback from profile
  const children: Child[] = childrenData && childrenData.length > 0 
    ? childrenData 
    : [{
        id: profile.id,
        user_id: user.id,
        child_name: profile.child_name,
        child_age: profile.child_age,
        total_points: profile.total_points,
        created_at: profile.created_at,
        updated_at: profile.updated_at,
      }]

  // Get IDs for querying - include both child IDs and profile ID for legacy data
  const childIds = children.map(c => c.id)
  const allIds = [...new Set([...childIds, user.id])]

  // Fetch pending requests for all children
  const { data: pendingRequests } = await supabase
    .from("bathroom_requests")
    .select("*")
    .or(allIds.map(id => `child_id.eq.${id},profile_id.eq.${id}`).join(","))
    .eq("status", "pending")
    .order("created_at", { ascending: false })

  // Fetch recent history for all children
  const { data: history } = await supabase
    .from("bathroom_requests")
    .select("*")
    .or(allIds.map(id => `child_id.eq.${id},profile_id.eq.${id}`).join(","))
    .neq("status", "pending")
    .order("created_at", { ascending: false })
    .limit(20)

  // Fetch rewards for all children
  const { data: rewards } = await supabase
    .from("rewards")
    .select("*")
    .or(allIds.map(id => `child_id.eq.${id},profile_id.eq.${id}`).join(","))
    .order("points_cost", { ascending: true })

  // Fetch caregivers
  const { data: caregivers } = await supabase
    .from("caregivers")
    .select("*")
    .eq("profile_id", user.id)
    .order("created_at", { ascending: true })

  // Fetch custom buttons for all children
  const { data: customButtons } = await supabase
    .from("custom_buttons")
    .select("*")
    .in("child_id", childIds)
    .order("display_order", { ascending: true })

  return (
    <CaregiverDashboard
      profile={profile}
      children={children}
      initialPendingRequests={pendingRequests || []}
      initialHistory={history || []}
      initialRewards={rewards || []}
      initialCaregivers={caregivers || []}
      initialCustomButtons={customButtons || []}
      currentUserId={user.id}
    />
  )
}
