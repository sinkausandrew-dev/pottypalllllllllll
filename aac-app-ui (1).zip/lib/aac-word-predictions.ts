"use client"

import type { VocabularyWord, WordType } from "@/lib/types"

// Word type patterns for prediction
// Maps word types to likely next word types
const WORD_TYPE_PATTERNS: Record<string, string[]> = {
  // After pronouns, suggest verbs
  'pronoun': ['verb', 'social'],
  
  // After verbs, suggest nouns or descriptors
  'verb': ['noun', 'descriptor', 'preposition'],
  
  // After "want/need/like" type verbs, suggest nouns
  'desire_verb': ['noun', 'activity'],
  
  // After feeling verbs, suggest emotions or descriptors
  'feeling_verb': ['emotion', 'descriptor'],
  
  // After nouns, suggest verbs or end of sentence
  'noun': ['verb', 'connector', 'end'],
  
  // After questions, suggest nouns or verbs
  'question': ['noun', 'verb', 'pronoun'],
  
  // After descriptors, suggest nouns
  'descriptor': ['noun'],
  
  // After connectors, suggest nouns or pronouns
  'connector': ['noun', 'pronoun', 'verb'],
}

// Common phrase starters and their continuations
// These are the most common patterns for nonverbal children
const PHRASE_PATTERNS: Record<string, string[]> = {
  // Core communication patterns
  'I': ['want', 'need', 'feel', 'like', 'see', 'hear', 'go', 'am'],
  'I want': ['more', 'help', 'food', 'drink', 'play', 'go', 'this', 'that'],
  'I need': ['help', 'potty', 'bathroom', 'break', 'water', 'food', 'hug'],
  'I feel': ['happy', 'sad', 'tired', 'hungry', 'thirsty', 'sick', 'scared', 'angry'],
  'I like': ['this', 'that', 'it', 'more', 'play', 'food'],
  'I am': ['done', 'ready', 'tired', 'hungry', 'happy', 'sad', 'okay'],
  'I see': ['you', 'it', 'that', 'this', 'mommy', 'daddy'],
  
  // Help patterns
  'Help': ['me', 'please', 'now'],
  'Help me': ['please', 'now', 'with', 'open', 'get'],
  
  // Want patterns
  'Want': ['more', 'help', 'food', 'drink', 'play', 'go', 'this'],
  'Want more': ['please', 'food', 'play', 'this'],
  
  // Need patterns  
  'Need': ['help', 'potty', 'break', 'water', 'food', 'hug'],
  'Need help': ['please', 'now', 'with'],
  
  // Go patterns
  'Go': ['home', 'outside', 'potty', 'play', 'there', 'away'],
  'Go to': ['potty', 'bed', 'home', 'play'],
  
  // More patterns
  'More': ['please', 'food', 'drink', 'play', 'this'],
  
  // Question responses
  'Yes': ['please', 'I want', 'more'],
  'No': ['thank you', 'I don\'t want', 'stop'],
  
  // Bathroom/potty patterns (key for this app!)
  'Potty': ['please', 'now', 'help'],
  'I need potty': ['now', 'please', 'help'],
  'Bathroom': ['please', 'now', 'help'],
  
  // Emotion continuations
  'Happy': ['now', 'today', 'because'],
  'Sad': ['because', 'help', 'hug'],
  'Tired': ['now', 'sleep', 'rest', 'break'],
  'Hungry': ['food', 'eat', 'please', 'snack'],
  'Thirsty': ['drink', 'water', 'juice', 'please'],
  'Scared': ['help', 'hug', 'mommy', 'daddy'],
  
  // Polite endings
  'Please': ['and', 'thank you', 'help', 'more'],
  'Thank you': ['more', 'please', 'bye'],
  
  // Social
  'Hi': ['mommy', 'daddy', 'friend', 'teacher'],
  'Bye': ['bye', 'mommy', 'daddy', 'friend'],
  'Good': ['job', 'morning', 'night', 'bye'],
}

// Categories of words to boost based on context
const CONTEXT_BOOSTS: Record<string, string[]> = {
  // After emotion words, boost comfort words
  'emotion': ['hug', 'help', 'please', 'mommy', 'daddy'],
  
  // After food words, boost more/please
  'food': ['more', 'please', 'done', 'drink', 'yummy'],
  
  // After potty words, boost related words
  'potty': ['now', 'please', 'help', 'done', 'wash hands'],
  
  // After activity words, boost continuations
  'activity': ['more', 'done', 'again', 'stop', 'go'],
}

// Get word type from a vocabulary word
export function getWordType(word: VocabularyWord): string {
  // Check if word has explicit type
  if ((word as unknown as { word_type?: string }).word_type) {
    return (word as unknown as { word_type: string }).word_type
  }
  
  // Infer type from word text
  const text = word.word.toLowerCase()
  
  // Pronouns
  if (['i', 'you', 'he', 'she', 'it', 'we', 'they', 'me', 'my'].includes(text)) {
    return 'pronoun'
  }
  
  // Desire/need verbs
  if (['want', 'need', 'like', 'love', 'get'].includes(text)) {
    return 'desire_verb'
  }
  
  // Feeling verbs
  if (['feel', 'am'].includes(text)) {
    return 'feeling_verb'
  }
  
  // General verbs
  if (['go', 'stop', 'help', 'play', 'eat', 'drink', 'see', 'hear', 'open', 'close', 'give', 'take', 'put', 'wash'].includes(text)) {
    return 'verb'
  }
  
  // Emotions
  if (['happy', 'sad', 'angry', 'scared', 'tired', 'sick', 'hungry', 'thirsty', 'hurt'].includes(text)) {
    return 'emotion'
  }
  
  // Questions
  if (['what', 'where', 'who', 'when', 'why', 'how', 'which'].includes(text)) {
    return 'question'
  }
  
  // Social words
  if (['yes', 'no', 'please', 'thank you', 'sorry', 'hi', 'bye', 'hello', 'goodbye'].includes(text)) {
    return 'social'
  }
  
  // Connectors
  if (['and', 'or', 'but', 'because', 'then', 'so', 'to', 'with'].includes(text)) {
    return 'connector'
  }
  
  // Descriptors
  if (['more', 'all done', 'done', 'again', 'big', 'small', 'good', 'bad', 'hot', 'cold', 'fast', 'slow'].includes(text)) {
    return 'descriptor'
  }
  
  // Potty related
  if (['potty', 'bathroom', 'pee', 'poop', 'wet', 'diaper', 'wash hands', 'accident'].includes(text)) {
    return 'potty'
  }
  
  // Food related
  if (['food', 'eat', 'snack', 'drink', 'water', 'juice', 'milk', 'cookie', 'cracker'].includes(text)) {
    return 'food'
  }
  
  // Default to noun
  return 'noun'
}

// Build current phrase from utterance tokens
function buildCurrentPhrase(tokens: Array<{ text: string }>): string {
  return tokens.map(t => t.text).join(' ')
}

// Get the last few words for pattern matching
function getRecentWords(tokens: Array<{ text: string }>, count: number = 3): string {
  return tokens.slice(-count).map(t => t.text).join(' ')
}

export interface PredictedWord {
  word: VocabularyWord
  score: number
  reason: string
}

/**
 * Get predicted next words based on current utterance
 * Returns words sorted by likelihood score
 */
export function getPredictedWords(
  currentTokens: Array<{ text: string; word_id: string | null }>,
  availableWords: VocabularyWord[],
  recentlyUsedWordIds: string[] = [],
  maxResults: number = 8
): PredictedWord[] {
  if (availableWords.length === 0) {
    return []
  }

  const predictions: PredictedWord[] = []
  const currentPhrase = buildCurrentPhrase(currentTokens)
  const lastWord = currentTokens.length > 0 ? currentTokens[currentTokens.length - 1].text.toLowerCase() : ''
  const recentPhrase = getRecentWords(currentTokens, 2)
  
  // Score each available word
  for (const word of availableWords) {
    let score = 0
    let reason = ''
    const wordText = word.word.toLowerCase()
    
    // Don't suggest the same word that was just added
    if (lastWord === wordText) {
      continue
    }
    
    // Skip words already in the utterance (unless they're common repeat words like "more")
    const alreadyInUtterance = currentTokens.some(t => t.text.toLowerCase() === wordText)
    if (alreadyInUtterance && !['more', 'please', 'and'].includes(wordText)) {
      continue
    }
    
    // 1. Check phrase patterns (highest priority)
    const phraseMatches = PHRASE_PATTERNS[currentPhrase] || PHRASE_PATTERNS[recentPhrase] || PHRASE_PATTERNS[lastWord]
    if (phraseMatches && phraseMatches.some(p => wordText.includes(p.toLowerCase()) || p.toLowerCase().includes(wordText))) {
      score += 100
      reason = 'Common next word'
    }
    
    // 2. Check word type patterns
    if (currentTokens.length > 0) {
      const lastWordObj = availableWords.find(w => w.word.toLowerCase() === lastWord)
      if (lastWordObj) {
        const lastWordType = getWordType(lastWordObj)
        const expectedTypes = WORD_TYPE_PATTERNS[lastWordType] || []
        const currentWordType = getWordType(word)
        
        if (expectedTypes.includes(currentWordType)) {
          score += 50
          reason = reason || 'Grammatically likely'
        }
      }
    }
    
    // 3. Context boosts
    const lastWordType = lastWord ? getWordType({ word: lastWord } as VocabularyWord) : ''
    const contextBoosts = CONTEXT_BOOSTS[lastWordType]
    if (contextBoosts && contextBoosts.some(b => wordText.includes(b.toLowerCase()))) {
      score += 30
      reason = reason || 'Contextually relevant'
    }
    
    // 4. Boost sentence starters if utterance is empty
    if (currentTokens.length === 0) {
      if (['i', 'help', 'want', 'need', 'yes', 'no', 'hi', 'potty', 'more'].includes(wordText)) {
        score += 80
        reason = 'Good sentence starter'
      }
    }
    
    // 5. Boost sentence enders if utterance has content
    if (currentTokens.length >= 2) {
      if (['please', 'now', 'done', 'thank you'].includes(wordText)) {
        score += 40
        reason = reason || 'Good sentence ender'
      }
    }
    
    // 6. Boost frequently used words (but not too much)
    if (recentlyUsedWordIds.includes(word.id)) {
      score += 15
      reason = reason || 'Recently used'
    }
    
    // 7. Boost favorites
    if (word.is_favorite) {
      score += 20
      reason = reason || 'Favorite word'
    }
    
    // 8. Boost ping-enabled words slightly (important communication)
    if (word.is_ping_enabled) {
      score += 10
    }
    
    // Only include words with some relevance score, or all words if nothing matches
    if (score > 0) {
      predictions.push({ word, score, reason })
    }
  }
  
  // Sort by score descending
  predictions.sort((a, b) => b.score - a.score)
  
  // If we have very few predictions, add some general useful words
  if (predictions.length < maxResults) {
    const usefulDefaults = ['i', 'want', 'need', 'help', 'more', 'please', 'yes', 'no']
    for (const defaultWord of usefulDefaults) {
      if (predictions.length >= maxResults) break
      
      const wordObj = availableWords.find(w => w.word.toLowerCase() === defaultWord)
      if (wordObj && !predictions.some(p => p.word.id === wordObj.id)) {
        predictions.push({ word: wordObj, score: 5, reason: 'Useful word' })
      }
    }
  }
  
  return predictions.slice(0, maxResults)
}

/**
 * Get quick phrase suggestions based on common needs
 * These are complete phrases the child can tap to say quickly
 */
export function getQuickPhrases(availableWords: VocabularyWord[]): Array<{ phrase: string; wordIds: string[] }> {
  const quickPhrases = [
    ['I', 'want'],
    ['I', 'need', 'help'],
    ['I', 'need', 'potty'],
    ['More', 'please'],
    ['All', 'done'],
    ['I', 'feel', 'happy'],
    ['I', 'feel', 'sad'],
    ['Yes', 'please'],
    ['No', 'thank you'],
  ]
  
  const results: Array<{ phrase: string; wordIds: string[] }> = []
  
  for (const phraseWords of quickPhrases) {
    const wordIds: string[] = []
    let allFound = true
    
    for (const word of phraseWords) {
      const found = availableWords.find(w => w.word.toLowerCase() === word.toLowerCase())
      if (found) {
        wordIds.push(found.id)
      } else {
        allFound = false
        break
      }
    }
    
    if (allFound && wordIds.length > 0) {
      results.push({ phrase: phraseWords.join(' '), wordIds })
    }
  }
  
  return results
}
