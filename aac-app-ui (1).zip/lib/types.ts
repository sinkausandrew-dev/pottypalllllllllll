export interface Profile {
  id: string
  child_name: string
  child_age: number | null
  caregiver_passcode: string
  total_points: number
  created_at: string
  updated_at: string
}

// Voice types for browser-based Text-to-Speech
export type VoiceCharacter = "female" | "male"

export interface Child {
  id: string
  user_id: string
  child_name: string
  child_age: number | null
  total_points: number
  avatar_url?: string | null
  voice_preference?: VoiceCharacter
  notes?: string | null
  child_pin?: string | null // Optional PIN for protected actions
  pin_required_for_rewards?: boolean
  pin_required_for_exit?: boolean
  created_at: string
  updated_at: string
}

export interface CaregiverChildAssignment {
  id: string
  caregiver_id: string
  child_id: string
  can_edit_settings: boolean
  can_manage_rewards: boolean
  can_view_reports: boolean
  assigned_at: string
  assigned_by: string | null
  // Joined data
  child?: Child
  caregiver?: Caregiver
}

// Voice character metadata for UI display
export const VOICE_CHARACTERS: Record<VoiceCharacter, { name: string; description: string; icon: string }> = {
  female: { name: "Female", description: "Warm & friendly", icon: "sparkles" },
  male: { name: "Male", description: "Deep & reassuring", icon: "shield" },
}

export interface Caregiver {
  id: string
  profile_id: string
  name: string
  email: string | null
  phone: string | null
  avatar_url: string | null
  receive_notifications: boolean
  push_subscription: object | null
  user_id: string | null
  is_admin: boolean
  invite_id: string | null
  created_at: string
}

export interface CaregiverInvite {
  id: string
  profile_id: string
  phone: string | null
  email: string | null
  caregiver_name: string | null
  child_ids: string[] // Children to assign on acceptance
  invite_code: string
  status: "pending" | "accepted" | "expired" | "cancelled"
  invited_by: string
  accepted_by: string | null
  expires_at: string
  created_at: string
  accepted_at: string | null
}

export interface SecondaryOption {
  id: string
  label: string
  icon_url?: string
  color?: string
}

export interface CustomButton {
  id: string
  child_id: string
  name: string
  tts_message: string
  color: string
  icon_url: string | null
  display_order: number
  is_active: boolean
  category: "potty" | "communication"
  awards_points: boolean
  // Secondary intent options - if present, child sees sub-options after tapping
  secondary_options?: SecondaryOption[] | null
  // If true, skip secondary options and send immediately
  send_immediately?: boolean
  created_at: string
  updated_at: string
}

export interface BathroomRequest {
  id: string
  profile_id?: string // Legacy support
  child_id?: string // New multi-child support
  request_type: "pee" | "poop" | "custom"
  custom_button_id?: string | null // Reference to custom button if type is 'custom'
  status: "pending" | "completed" | "cancelled"
  points_awarded: number
  completed_by: string | null
  created_at: string
  completed_at: string | null
}

export interface Reward {
  id: string
  profile_id?: string // Legacy support
  child_id?: string // New multi-child support
  name: string
  description: string | null
  points_cost: number
  icon: string
  image_url: string | null
  is_active: boolean
  created_at: string
}

export interface RedeemedReward {
  id: string
  profile_id?: string // Legacy support
  child_id?: string // New multi-child support
  reward_id: string
  points_spent: number
  redeemed_at: string
}

// Vocabulary/AAC System Types
export interface VocabularyCategory {
  id: string
  caregiver_id: string
  child_id: string | null
  name: string
  icon: string
  color: string
  display_order: number
  is_system: boolean
  is_active: boolean
  created_at: string
  updated_at: string
}

export interface VocabularyWord {
  id: string
  caregiver_id: string
  category_id: string
  child_id: string | null
  word: string
  phrase: string | null
  icon: string | null
  image_url: string | null
  color: string | null
  display_order: number
  is_ping_enabled: boolean // Can send notification to caregiver
  ping_priority: "low" | "normal" | "high" | "urgent"
  is_favorite: boolean
  is_active: boolean
  created_at: string
  updated_at: string
}

export interface CaregiverPing {
  id: string
  child_id: string
  caregiver_id: string
  word_id: string | null
  message: string
  priority: "low" | "normal" | "high" | "urgent"
  is_read: boolean
  read_at: string | null
  responded_at: string | null
  response_note: string | null
  // UI uses these for status tracking
  status?: "pending" | "acknowledged" | "resolved"
  acknowledged_at?: string | null
  acknowledged_by?: string | null
  created_at: string
}

// ===========================================
// AAC LAMP-Style + Tiered Learning Types
// ===========================================

export type TierKey = 'T0' | 'T1' | 'T2' | 'T3' | 'T4' | 'T5'
export type LayoutMode = 'category_tabs' | 'lamp_grid'
export type GridSize = 20 | 28 | 40 | 60
export type WordType = 'noun' | 'verb' | 'adjective' | 'pronoun' | 'preposition' | 'connector' | 'social' | 'question' | 'descriptor'
export type GrammarHelperType = 'suffix' | 'prefix' | 'connector' | 'frame'
export type AACEventType = 
  | 'tap_word' 
  | 'add_to_utterance' 
  | 'remove_from_utterance'
  | 'speak_utterance' 
  | 'send_ping' 
  | 'prompted' 
  | 'independent'
  | 'grammar_helper_used' 
  | 'category_opened' 
  | 'backspace' 
  | 'clear_utterance'

export interface AACTier {
  id: string
  tier_key: TierKey
  name: string
  grade_band: string | null
  description: string | null
  unlocked_slots_count: number
  grammar_features: string[] // array of helper keys enabled at this tier
  unlock_rules: {
    next_tier?: TierKey
    multi_word_utterances_per_week?: number
    unique_words_7d?: number
    avg_utterance_len?: number
    grammar_helper_uses?: number
    connector_uses?: number
    social_script_uses?: number
  }
  display_order: number
  created_at: string
}

export interface ChildAACSettings {
  child_id: string
  active_tier_id: string | null
  tier_locked: boolean
  layout_mode: LayoutMode
  grid_size: GridSize
  sound_enabled_default: boolean
  show_grammar_helpers: boolean
  academic_packs_enabled: string[] // array of pack IDs
  created_at: string
  updated_at: string
  // Joined data
  active_tier?: AACTier
}

export interface AACLayoutSlot {
  id: string
  child_id: string | null
  tier_id: string | null
  slot_key: string // e.g., 'HOME_01', 'CAT_CORE_01'
  word_id: string | null
  locked_position: boolean
  created_at: string
  updated_at: string
  // Joined data
  word?: VocabularyWord
}

export interface AACUtteranceSession {
  id: string
  child_id: string
  mode: 'practice' | 'communicate'
  context_tag: string | null
  started_at: string
  ended_at: string | null
}

export interface AACUtteranceEvent {
  id: string
  session_id: string | null
  child_id: string
  event_type: AACEventType
  word_id: string | null
  utterance_text: string | null
  utterance_word_ids: string[] | null
  grammar_helper_key: string | null
  latency_ms: number | null
  created_at: string
}

export interface AACBenchmark {
  id: string
  tier_id: string
  metric_key: string // 'avg_utterance_len', 'unique_words_7d', 'grammar_feature_use'
  expected_range: {
    p25: number
    p50: number
    p75: number
  }
  notes: string | null
  created_at: string
}

export interface AACGrammarHelper {
  id: string
  helper_key: string
  display_name: string
  helper_type: GrammarHelperType
  text_to_append: string | null
  min_tier_key: TierKey
  display_order: number
  is_active: boolean
  created_at: string
}

// Utterance Bar State (for UI)
export interface UtteranceToken {
  id: string // unique ID for this token in the utterance
  word_id: string | null // null for grammar helpers
  text: string
  is_grammar_helper: boolean
  grammar_helper_key?: string
}

// Telemetry metrics computed from events
export interface AACMetrics {
  avgUtteranceLength: number
  uniqueWords7d: number
  multiWordUtterancePercent: number
  grammarHelperUseCount: number
  topCategories: Array<{ category: string; count: number }>
  functionalVsSocialBreakdown: {
    functional: number
    social: number
    academic: number
  }
  totalUtterances: number
  totalWords: number
}

// Tier recommendation result
export interface TierRecommendation {
  recommended_tier: TierKey
  current_tier: TierKey
  reasoning: string[]
  metrics: AACMetrics
  meets_advancement_criteria: boolean
}

// Default vocabulary categories
export const DEFAULT_VOCABULARY_CATEGORIES = [
  { name: "Core Words", icon: "message-circle", color: "#6366f1" },
  { name: "Potty", icon: "droplet", color: "#f59e0b" },
  { name: "Encouragement", icon: "star", color: "#10b981" },
  { name: "Emotions", icon: "heart", color: "#ec4899" },
] as const

// Default vocabulary words by category
export const DEFAULT_VOCABULARY_WORDS: Record<string, Array<{ word: string; phrase?: string; icon: string; isPing?: boolean }>> = {
  "Core Words": [
    { word: "I want", phrase: "I want something", icon: "hand" },
    { word: "Help", phrase: "I need help please", icon: "life-buoy", isPing: true },
    { word: "More", phrase: "I want more please", icon: "plus-circle" },
    { word: "All done", phrase: "I am all done", icon: "check-circle" },
    { word: "Stop", phrase: "Please stop", icon: "octagon" },
    { word: "Go", phrase: "Let's go", icon: "arrow-right" },
    { word: "Yes", phrase: "Yes please", icon: "thumbs-up" },
    { word: "No", phrase: "No thank you", icon: "thumbs-down" },
  ],
  "Potty": [
    { word: "Potty", phrase: "I need to go potty", icon: "droplet", isPing: true },
    { word: "Pee", phrase: "I need to pee", icon: "droplets", isPing: true },
    { word: "Poop", phrase: "I need to poop", icon: "circle", isPing: true },
    { word: "Accident", phrase: "I had an accident", icon: "alert-circle", isPing: true },
    { word: "Wet", phrase: "I feel wet", icon: "cloud-rain", isPing: true },
    { word: "Clean up", phrase: "I need to clean up", icon: "sparkles" },
    { word: "Wash hands", phrase: "I need to wash my hands", icon: "hand" },
    { word: "All done", phrase: "I am all done in the bathroom", icon: "check" },
  ],
  "Encouragement": [
    { word: "Good job", phrase: "Good job!", icon: "award" },
    { word: "Try again", phrase: "Let me try again", icon: "refresh-cw" },
    { word: "I did it", phrase: "I did it!", icon: "trophy" },
    { word: "Thank you", phrase: "Thank you!", icon: "heart" },
    { word: "High five", phrase: "Give me a high five!", icon: "hand" },
    { word: "Yay", phrase: "Yay!", icon: "party-popper" },
  ],
  "Emotions": [
    { word: "Happy", phrase: "I feel happy", icon: "smile" },
    { word: "Sad", phrase: "I feel sad", icon: "frown" },
    { word: "Scared", phrase: "I feel scared", icon: "alert-triangle", isPing: true },
    { word: "Angry", phrase: "I feel angry", icon: "flame" },
    { word: "Tired", phrase: "I feel tired", icon: "moon" },
    { word: "Sick", phrase: "I feel sick", icon: "thermometer", isPing: true },
    { word: "Hungry", phrase: "I feel hungry", icon: "utensils" },
    { word: "Thirsty", phrase: "I feel thirsty", icon: "cup-soda" },
  ],
}
