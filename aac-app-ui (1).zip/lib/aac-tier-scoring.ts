/**
 * AAC Tier Scoring and Recommendation Logic
 * 
 * This module provides deterministic scoring functions for tier advancement.
 * Thresholds are stored in aac_tiers.unlock_rules and can be adjusted by admins.
 * 
 * Key Principles:
 * - No ML required - pure threshold-based logic
 * - Transparent reasoning - explains WHY a recommendation is made
 * - Respects caregiver tier_locked setting
 * - Non-disruptive - existing words stay in place when advancing
 */

import type { AACTier, AACMetrics, TierRecommendation, TierKey } from "@/lib/types"

// Tier ordering for comparison
export const TIER_ORDER: TierKey[] = ['T0', 'T1', 'T2', 'T3', 'T4', 'T5']

/**
 * Compare two tier keys
 * @returns negative if a < b, 0 if equal, positive if a > b
 */
export function compareTiers(a: TierKey, b: TierKey): number {
  return TIER_ORDER.indexOf(a) - TIER_ORDER.indexOf(b)
}

/**
 * Check if current tier is at least the required tier
 */
export function isTierAtLeast(current: TierKey, required: TierKey): boolean {
  return compareTiers(current, required) >= 0
}

/**
 * Get the next tier key, or null if at max
 */
export function getNextTier(current: TierKey): TierKey | null {
  const currentIndex = TIER_ORDER.indexOf(current)
  if (currentIndex < TIER_ORDER.length - 1) {
    return TIER_ORDER[currentIndex + 1]
  }
  return null
}

/**
 * Get the previous tier key, or null if at min
 */
export function getPreviousTier(current: TierKey): TierKey | null {
  const currentIndex = TIER_ORDER.indexOf(current)
  if (currentIndex > 0) {
    return TIER_ORDER[currentIndex - 1]
  }
  return null
}

/**
 * Evaluation result for a single criterion
 */
interface CriterionResult {
  name: string
  met: boolean
  current: number
  threshold: number
  description: string
}

/**
 * Evaluate metrics against tier advancement criteria
 */
export function evaluateTierCriteria(
  tier: AACTier,
  metrics: AACMetrics
): { results: CriterionResult[]; percentMet: number; allMet: boolean } {
  const results: CriterionResult[] = []
  const rules = tier.unlock_rules

  // Multi-word utterances per week (for T0 -> T1)
  if (rules.multi_word_utterances_per_week !== undefined) {
    // Estimate weekly rate from total (assuming 14-day window)
    const weeklyRate = Math.round(metrics.totalUtterances * (metrics.multiWordUtterancePercent / 100) / 2)
    results.push({
      name: 'Multi-word Utterances',
      met: weeklyRate >= rules.multi_word_utterances_per_week,
      current: weeklyRate,
      threshold: rules.multi_word_utterances_per_week,
      description: `${weeklyRate} multi-word utterances per week (need ${rules.multi_word_utterances_per_week})`,
    })
  }

  // Unique words in 7 days
  if (rules.unique_words_7d !== undefined) {
    results.push({
      name: 'Unique Words',
      met: metrics.uniqueWords7d >= rules.unique_words_7d,
      current: metrics.uniqueWords7d,
      threshold: rules.unique_words_7d,
      description: `${metrics.uniqueWords7d} unique words (need ${rules.unique_words_7d})`,
    })
  }

  // Average utterance length
  if (rules.avg_utterance_len !== undefined) {
    results.push({
      name: 'Average Length',
      met: metrics.avgUtteranceLength >= rules.avg_utterance_len,
      current: metrics.avgUtteranceLength,
      threshold: rules.avg_utterance_len,
      description: `${metrics.avgUtteranceLength} words per utterance (need ${rules.avg_utterance_len})`,
    })
  }

  // Grammar helper usage
  if (rules.grammar_helper_uses !== undefined) {
    results.push({
      name: 'Grammar Helpers',
      met: metrics.grammarHelperUseCount >= rules.grammar_helper_uses,
      current: metrics.grammarHelperUseCount,
      threshold: rules.grammar_helper_uses,
      description: `${metrics.grammarHelperUseCount} grammar helper uses (need ${rules.grammar_helper_uses})`,
    })
  }

  // Connector usage (T3+)
  if (rules.connector_uses !== undefined) {
    // For now, we approximate this from grammar helper count
    // In a full implementation, we'd track connector-specific events
    const connectorUses = Math.floor(metrics.grammarHelperUseCount * 0.3)
    results.push({
      name: 'Connectors',
      met: connectorUses >= rules.connector_uses,
      current: connectorUses,
      threshold: rules.connector_uses,
      description: `${connectorUses} connector uses (need ${rules.connector_uses})`,
    })
  }

  // Social script usage (T4+)
  if (rules.social_script_uses !== undefined) {
    // Approximate from functional breakdown
    const socialUses = Math.floor(metrics.totalUtterances * (metrics.functionalVsSocialBreakdown.social / 100))
    results.push({
      name: 'Social Scripts',
      met: socialUses >= rules.social_script_uses,
      current: socialUses,
      threshold: rules.social_script_uses,
      description: `${socialUses} social expressions (need ${rules.social_script_uses})`,
    })
  }

  const metCount = results.filter(r => r.met).length
  const percentMet = results.length > 0 ? (metCount / results.length) * 100 : 0

  return {
    results,
    percentMet,
    allMet: results.length > 0 && metCount === results.length,
  }
}

/**
 * Generate a tier recommendation with reasoning
 */
export function generateTierRecommendation(
  tiers: AACTier[],
  currentTierKey: TierKey,
  metrics: AACMetrics,
  tierLocked: boolean
): TierRecommendation {
  const currentTier = tiers.find(t => t.tier_key === currentTierKey)
  const reasoning: string[] = []
  
  let recommendedTierKey = currentTierKey
  let meetsAdvancementCriteria = false

  if (!currentTier) {
    reasoning.push('Current tier not found')
    return {
      recommended_tier: currentTierKey,
      current_tier: currentTierKey,
      reasoning,
      metrics,
      meets_advancement_criteria: false,
    }
  }

  // Evaluate current tier's advancement criteria
  const evaluation = evaluateTierCriteria(currentTier, metrics)

  // Add reasoning for each criterion
  for (const result of evaluation.results) {
    if (result.met) {
      reasoning.push(`${result.name}: ${result.description}`)
    } else {
      reasoning.push(`${result.name}: ${result.description}`)
    }
  }

  // Determine if advancement is recommended
  // We use 70% threshold to allow some flexibility
  const advancementThreshold = 70
  
  if (evaluation.percentMet >= advancementThreshold) {
    meetsAdvancementCriteria = true
    
    const nextTier = currentTier.unlock_rules.next_tier as TierKey | undefined
    if (nextTier) {
      recommendedTierKey = nextTier
      
      if (tierLocked) {
        reasoning.unshift(`Tier is locked by caregiver. Would recommend ${nextTier}.`)
      } else {
        reasoning.unshift(`Ready to advance to ${nextTier}! (${Math.round(evaluation.percentMet)}% of criteria met)`)
      }
    } else {
      reasoning.unshift(`At highest tier. All criteria met!`)
    }
  } else {
    reasoning.unshift(`${Math.round(evaluation.percentMet)}% of advancement criteria met. Keep practicing!`)
    
    // Provide specific guidance
    const unmetCriteria = evaluation.results.filter(r => !r.met)
    if (unmetCriteria.length > 0) {
      const mostNeeded = unmetCriteria[0]
      reasoning.push(`Focus area: ${mostNeeded.name} - need ${mostNeeded.threshold - mostNeeded.current} more`)
    }
  }

  return {
    recommended_tier: tierLocked ? currentTierKey : recommendedTierKey,
    current_tier: currentTierKey,
    reasoning,
    metrics,
    meets_advancement_criteria: meetsAdvancementCriteria,
  }
}

/**
 * Get tier display info for UI
 */
export function getTierDisplayInfo(tierKey: TierKey): {
  color: string
  label: string
  shortLabel: string
} {
  const info: Record<TierKey, { color: string; label: string; shortLabel: string }> = {
    T0: { color: '#94a3b8', label: 'Emerging', shortLabel: 'T0' },
    T1: { color: '#22c55e', label: 'Early Words', shortLabel: 'T1' },
    T2: { color: '#3b82f6', label: 'Early Sentences', shortLabel: 'T2' },
    T3: { color: '#8b5cf6', label: 'Building Sentences', shortLabel: 'T3' },
    T4: { color: '#f59e0b', label: 'Complex Communication', shortLabel: 'T4' },
    T5: { color: '#ef4444', label: 'Academic Language', shortLabel: 'T5' },
  }
  return info[tierKey]
}

/**
 * Calculate progress percentage within current tier
 */
export function calculateTierProgress(tier: AACTier, metrics: AACMetrics): number {
  const evaluation = evaluateTierCriteria(tier, metrics)
  return Math.min(100, Math.round(evaluation.percentMet))
}
