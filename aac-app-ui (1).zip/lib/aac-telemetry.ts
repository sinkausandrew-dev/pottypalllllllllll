import { createBrowserClient } from "@supabase/ssr"
import type { AACEventType, AACUtteranceSession, AACUtteranceEvent } from "@/lib/types"

// Singleton Supabase client
let supabaseClient: ReturnType<typeof createBrowserClient> | null = null

function getSupabase() {
  if (!supabaseClient) {
    supabaseClient = createBrowserClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
    )
  }
  return supabaseClient
}

// Session management
let currentSession: AACUtteranceSession | null = null
let lastEventTime: number = Date.now()
let eventQueue: Partial<AACUtteranceEvent>[] = []
let flushTimeout: NodeJS.Timeout | null = null

const FLUSH_INTERVAL = 5000 // Flush every 5 seconds
const MAX_QUEUE_SIZE = 20 // Or when queue reaches this size

/**
 * Start a new AAC session
 */
export async function startSession(
  childId: string,
  mode: 'practice' | 'communicate',
  contextTag?: string
): Promise<string | null> {
  const supabase = getSupabase()
  
  // End any existing session first
  if (currentSession) {
    await endSession()
  }
  
  try {
    const { data, error } = await supabase
      .from("aac_utterance_sessions")
      .insert({
        child_id: childId,
        mode,
        context_tag: contextTag || null,
      })
      .select()
      .single()
    
    if (error) {
      console.error("Failed to start AAC session:", error)
      return null
    }
    
    currentSession = data
    lastEventTime = Date.now()
    return data.id
  } catch (err) {
    console.error("Error starting AAC session:", err)
    return null
  }
}

/**
 * End the current session
 */
export async function endSession(): Promise<void> {
  if (!currentSession) return
  
  // Flush any remaining events
  await flushEvents()
  
  const supabase = getSupabase()
  
  try {
    await supabase
      .from("aac_utterance_sessions")
      .update({ ended_at: new Date().toISOString() })
      .eq("id", currentSession.id)
  } catch (err) {
    console.error("Error ending AAC session:", err)
  }
  
  currentSession = null
}

/**
 * Log an AAC event (queued for batch insert)
 */
export function logEvent(
  childId: string,
  eventType: AACEventType,
  options: {
    wordId?: string | null
    utteranceText?: string | null
    utteranceWordIds?: string[] | null
    grammarHelperKey?: string | null
  } = {}
): void {
  const now = Date.now()
  const latencyMs = now - lastEventTime
  lastEventTime = now
  
  const event: Partial<AACUtteranceEvent> = {
    session_id: currentSession?.id || null,
    child_id: childId,
    event_type: eventType,
    word_id: options.wordId || null,
    utterance_text: options.utteranceText || null,
    utterance_word_ids: options.utteranceWordIds || null,
    grammar_helper_key: options.grammarHelperKey || null,
    latency_ms: latencyMs,
  }
  
  eventQueue.push(event)
  
  // Flush if queue is full
  if (eventQueue.length >= MAX_QUEUE_SIZE) {
    flushEvents()
  } else if (!flushTimeout) {
    // Schedule a flush
    flushTimeout = setTimeout(flushEvents, FLUSH_INTERVAL)
  }
}

/**
 * Flush queued events to database
 */
export async function flushEvents(): Promise<void> {
  if (flushTimeout) {
    clearTimeout(flushTimeout)
    flushTimeout = null
  }
  
  if (eventQueue.length === 0) return
  
  const supabase = getSupabase()
  const eventsToInsert = [...eventQueue]
  eventQueue = []
  
  try {
    const { error } = await supabase
      .from("aac_utterance_events")
      .insert(eventsToInsert)
    
    if (error) {
      console.error("Failed to flush AAC events:", error)
      // Re-queue failed events (with limit to prevent infinite growth)
      if (eventQueue.length < MAX_QUEUE_SIZE * 2) {
        eventQueue.unshift(...eventsToInsert)
      }
    }
  } catch (err) {
    console.error("Error flushing AAC events:", err)
  }
}

/**
 * Helper to log common events
 */
export const AACEvents = {
  tapWord: (childId: string, wordId: string) => 
    logEvent(childId, 'tap_word', { wordId }),
  
  addToUtterance: (childId: string, wordId: string, utteranceText: string, wordIds: string[]) =>
    logEvent(childId, 'add_to_utterance', { wordId, utteranceText, utteranceWordIds: wordIds }),
  
  removeFromUtterance: (childId: string, utteranceText: string, wordIds: string[]) =>
    logEvent(childId, 'remove_from_utterance', { utteranceText, utteranceWordIds: wordIds }),
  
  speakUtterance: (childId: string, utteranceText: string, wordIds: string[]) =>
    logEvent(childId, 'speak_utterance', { utteranceText, utteranceWordIds: wordIds }),
  
  sendPing: (childId: string, utteranceText: string, wordIds: string[]) =>
    logEvent(childId, 'send_ping', { utteranceText, utteranceWordIds: wordIds }),
  
  grammarHelperUsed: (childId: string, helperKey: string, utteranceText: string) =>
    logEvent(childId, 'grammar_helper_used', { grammarHelperKey: helperKey, utteranceText }),
  
  categoryOpened: (childId: string) =>
    logEvent(childId, 'category_opened'),
  
  backspace: (childId: string, utteranceText: string, wordIds: string[]) =>
    logEvent(childId, 'backspace', { utteranceText, utteranceWordIds: wordIds }),
  
  clearUtterance: (childId: string) =>
    logEvent(childId, 'clear_utterance'),
}

// Cleanup on page unload
if (typeof window !== 'undefined') {
  window.addEventListener('beforeunload', () => {
    // Synchronous flush attempt
    flushEvents()
    endSession()
  })
  
  // Also handle visibility change (mobile tab switching)
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
      flushEvents()
    }
  })
}
