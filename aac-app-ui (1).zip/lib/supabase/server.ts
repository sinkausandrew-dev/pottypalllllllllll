import { createServerClient } from "@supabase/ssr"
import { cookies } from "next/headers"

// Create a mock client for when Supabase is not configured
function createMockClient() {
  const mockQueryBuilder = () => ({
    select: () => mockQueryBuilder(),
    eq: () => mockQueryBuilder(),
    neq: () => mockQueryBuilder(),
    or: () => mockQueryBuilder(),
    order: () => mockQueryBuilder(),
    limit: () => mockQueryBuilder(),
    maybeSingle: async () => ({ data: null, error: null }),
    single: async () => ({ data: null, error: null }),
    then: (resolve: (value: { data: unknown[], error: null }) => void) => resolve({ data: [], error: null }),
  })

  return {
    auth: {
      getUser: async () => ({ data: { user: null }, error: null }),
      getSession: async () => ({ data: { session: null }, error: null }),
      signInWithPassword: async () => ({ data: { user: null, session: null }, error: { message: "Supabase not configured" } }),
      signUp: async () => ({ data: { user: null, session: null }, error: { message: "Supabase not configured" } }),
      signOut: async () => ({ error: null }),
    },
    from: () => ({
      select: () => mockQueryBuilder(),
      insert: () => mockQueryBuilder(),
      update: () => ({
        eq: () => mockQueryBuilder(),
        match: () => mockQueryBuilder(),
      }),
      delete: () => ({
        eq: () => mockQueryBuilder(),
        match: () => mockQueryBuilder(),
      }),
      upsert: () => mockQueryBuilder(),
    }),
    rpc: async () => ({ data: null, error: null }),
    storage: {
      from: () => ({
        upload: async () => ({ data: null, error: { message: "Supabase not configured" } }),
        getPublicUrl: () => ({ data: { publicUrl: "" } }),
      }),
    },
  } as unknown as ReturnType<typeof createServerClient>
}

export async function createClient() {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
  const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

  // If env vars not configured, return a mock client
  if (!supabaseUrl || !supabaseAnonKey) {
    return createMockClient()
  }

  const cookieStore = await cookies()

  return createServerClient(supabaseUrl, supabaseAnonKey, {
    cookies: {
      getAll() {
        return cookieStore.getAll()
      },
      setAll(cookiesToSet) {
        try {
          cookiesToSet.forEach(({ name, value, options }) => cookieStore.set(name, value, options))
        } catch {
          // Called from Server Component - ignore
        }
      },
    },
  })
}
