import { createBrowserClient } from "@supabase/ssr"

// Use globalThis to persist client across HMR and multiple imports
const globalForSupabase = globalThis as unknown as {
  supabaseClient: ReturnType<typeof createBrowserClient> | undefined
}

// Create a mock client that returns safe defaults
function createMockClient() {
  const mockQueryBuilder = (): Record<string, unknown> => ({
    select: () => mockQueryBuilder(),
    eq: () => mockQueryBuilder(),
    neq: () => mockQueryBuilder(),
    or: () => mockQueryBuilder(),
    order: () => mockQueryBuilder(),
    limit: () => mockQueryBuilder(),
    match: () => mockQueryBuilder(),
    in: () => mockQueryBuilder(),
    is: () => mockQueryBuilder(),
    maybeSingle: async () => ({ data: null, error: null }),
    single: async () => ({ data: null, error: null }),
    then: (resolve: (value: { data: unknown[], error: null }) => void) => resolve({ data: [], error: null }),
  })

  return {
    auth: {
      signInWithPassword: async () => ({ data: { user: null, session: null }, error: { message: "Please connect Supabase from the integrations panel." } }),
      signUp: async () => ({ data: { user: null, session: null }, error: { message: "Please connect Supabase from the integrations panel." } }),
      signOut: async () => ({ error: null }),
      getUser: async () => ({ data: { user: null }, error: null }),
      getSession: async () => ({ data: { session: null }, error: null }),
      onAuthStateChange: () => ({ data: { subscription: { unsubscribe: () => {} } } }),
    },
    from: () => ({
      select: () => mockQueryBuilder(),
      insert: () => mockQueryBuilder(),
      update: () => ({
        eq: () => mockQueryBuilder(),
        match: () => mockQueryBuilder(),
      }),
      delete: () => ({
        eq: () => mockQueryBuilder(),
        match: () => mockQueryBuilder(),
      }),
      upsert: () => mockQueryBuilder(),
    }),
    channel: () => ({
      on: () => ({ subscribe: () => ({ unsubscribe: () => {} }) }),
    }),
    removeChannel: () => {},
    rpc: async () => ({ data: null, error: null }),
    storage: {
      from: () => ({
        upload: async () => ({ data: null, error: { message: "Supabase not configured" } }),
        getPublicUrl: () => ({ data: { publicUrl: "" } }),
      }),
    },
  } as unknown as ReturnType<typeof createBrowserClient>
}

export function createClient() {
  // Return cached client if available
  if (globalForSupabase.supabaseClient) return globalForSupabase.supabaseClient

  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
  const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

  // Return mock client if credentials are missing
  if (!supabaseUrl || !supabaseAnonKey) {
    return createMockClient()
  }

  try {
    globalForSupabase.supabaseClient = createBrowserClient(supabaseUrl, supabaseAnonKey)
    return globalForSupabase.supabaseClient
  } catch (error) {
    console.error("[v0] Failed to create Supabase client:", error)
    return createMockClient()
  }
}
