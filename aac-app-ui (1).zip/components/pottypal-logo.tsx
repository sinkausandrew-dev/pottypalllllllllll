"use client"

import { cn } from "@/lib/utils"

interface PottyPalLogoProps {
  size?: "sm" | "md" | "lg" | "xl"
  showText?: boolean
  className?: string
}

export function PottyPalLogo({ size = "md", showText = true, className }: PottyPalLogoProps) {
  const sizeClasses = {
    sm: "h-16 w-16 text-4xl",
    md: "h-24 w-24 text-5xl",
    lg: "h-32 w-32 text-6xl",
    xl: "h-40 w-40 text-7xl",
  }

  const textSizes = {
    sm: "text-lg",
    md: "text-2xl",
    lg: "text-4xl",
    xl: "text-6xl",
  }

  return (
    <div className={cn("flex flex-col items-center gap-3", className)}>
      <div className={cn("relative", sizeClasses[size])}>
        {/* Main toilet icon with glow background - Futuristic cyan */}
        <div className="relative w-full h-full rounded-full bg-gradient-to-br from-cyan-400 via-cyan-500 to-cyan-600 shadow-2xl shadow-cyan-500/40 flex items-center justify-center">
          <span className="relative z-10">🚽</span>
          {/* Glow effect */}
          <div className="absolute inset-0 rounded-full bg-cyan-400/30 blur-xl animate-pulse"></div>
        </div>
        {/* Star decoration */}
        <div className="absolute -top-1 -right-1 text-xl animate-bounce" style={{ animationDelay: "0.2s", animationDuration: "2s" }}>
          ⭐
        </div>
      </div>
      {showText && (
        <h1 className={cn("font-bold tracking-tight bg-gradient-to-r from-cyan-400 via-cyan-300 to-cyan-400 bg-clip-text text-transparent drop-shadow-lg", textSizes[size])}>
          PottyPal
        </h1>
      )}
    </div>
  )
}
