"use client"

import React from "react"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import type { Caregiver, CaregiverInvite, Child, CaregiverChildAssignment } from "@/lib/types"
import { Checkbox } from "@/components/ui/checkbox"
import { Plus, User, Trash2, Bell, BellOff, MessageSquare, Clock, Check, X, Copy, Shield, UserPlus, Send, Users, Mail, Phone, Pencil, Camera, Loader2 } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

interface CaregiversManagerProps {
  caregivers: Caregiver[]
  profileId: string
  children: Child[] // All children under this admin
  onCaregiversChange: (caregivers: Caregiver[]) => void
  currentUserId?: string
}

export function CaregiversManager({ caregivers, profileId, children: initialChildren, onCaregiversChange, currentUserId }: CaregiversManagerProps) {
  // Ensure children is always an array
  const children = initialChildren || []
  const [isOpen, setIsOpen] = useState(false)
  const [newCaregiver, setNewCaregiver] = useState({ name: "", email: "", phone: "" })
  const [isLoading, setIsLoading] = useState(false)
  
  // Invite state - now supports email and child assignments
  const [inviteMethod, setInviteMethod] = useState<"sms" | "email">("email")
  const [inviteEmail, setInviteEmail] = useState("")
  const [invitePhone, setInvitePhone] = useState("")
  const [inviteName, setInviteName] = useState("")
  const [selectedChildIds, setSelectedChildIds] = useState<string[]>([])
  const [isSendingInvite, setIsSendingInvite] = useState(false)
  const [inviteMessage, setInviteMessage] = useState<{ type: "success" | "error"; text: string } | null>(null)
  const [pendingInvites, setPendingInvites] = useState<CaregiverInvite[]>([])
  const [showInviteCode, setShowInviteCode] = useState<string | null>(null)
  const [caregiverToRemove, setCaregiverToRemove] = useState<Caregiver | null>(null)
  const [caregiverAssignments, setCaregiverAssignments] = useState<Record<string, string[]>>({})
  const [editingAssignments, setEditingAssignments] = useState<string | null>(null)
  
  // Edit caregiver state
  const [editingCaregiver, setEditingCaregiver] = useState<Caregiver | null>(null)
  const [editForm, setEditForm] = useState({ name: "", email: "", phone: "", avatar_url: "" })
  const [isUploading, setIsUploading] = useState(false)
  const [isSaving, setIsSaving] = useState(false)

  // Fetch pending invites and assignments on mount
  useEffect(() => {
    const fetchData = async () => {
      const supabase = createClient()
      
      // Fetch pending invites
      const { data: invites } = await supabase
        .from("caregiver_invites")
        .select("*")
        .eq("profile_id", profileId)
        .eq("status", "pending")
        .order("created_at", { ascending: false })

      if (invites) {
        setPendingInvites(invites)
      }

      // Fetch caregiver-child assignments
      const { data: assignments } = await supabase
        .from("caregiver_child_assignments")
        .select("caregiver_id, child_id")
        .in("caregiver_id", caregivers.map(c => c.id))

      if (assignments) {
        const assignmentMap: Record<string, string[]> = {}
        for (const a of assignments) {
          if (!assignmentMap[a.caregiver_id]) {
            assignmentMap[a.caregiver_id] = []
          }
          assignmentMap[a.caregiver_id].push(a.child_id)
        }
        setCaregiverAssignments(assignmentMap)
      }
    }
    fetchData()
  }, [profileId, caregivers])

  // Send invite (email or SMS)
  const handleSendInvite = async () => {
    const contact = inviteMethod === "email" ? inviteEmail.trim() : invitePhone.trim()
    if (!contact) return
    
    // Must select at least one child
    if (selectedChildIds.length === 0 && children.length > 0) {
      setInviteMessage({ type: "error", text: "Please select at least one child to assign" })
      return
    }
    
    setIsSendingInvite(true)
    setInviteMessage(null)

    try {
      const response = await fetch("/api/send-caregiver-invite", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: inviteMethod === "email" ? inviteEmail.trim() : null,
          phone: inviteMethod === "sms" ? invitePhone.trim() : null,
          profileId,
          caregiverName: inviteName.trim() || null,
          childIds: selectedChildIds,
          inviterName: caregivers.find(c => c.is_admin)?.name || "A caregiver",
        }),
      })

      const data = await response.json()

      if (data.success) {
        // Always show the invite code
        if (data.inviteCode) {
          setShowInviteCode(data.inviteCode)
        }
        
        setInviteMessage({
          type: "success",
          text: data.emailSent || data.smsSent
            ? `Invitation sent via ${inviteMethod === "email" ? "email" : "SMS"}!` 
            : "Invite created! Share the code below:",
        })
        
        if (data.invite) {
          setPendingInvites(prev => [data.invite, ...prev])
        }
        
        // Reset form
        setInviteEmail("")
        setInvitePhone("")
        setInviteName("")
        setSelectedChildIds([])
      } else {
        setInviteMessage({ type: "error", text: data.error || "Failed to send invite" })
      }
    } catch (error) {
      console.error("Failed to send invite:", error)
      setInviteMessage({ type: "error", text: "Failed to send invitation" })
    } finally {
      setIsSendingInvite(false)
    }
  }

  // Toggle child selection for invite
  const toggleChildSelection = (childId: string) => {
    setSelectedChildIds(prev => 
      prev.includes(childId) 
        ? prev.filter(id => id !== childId)
        : [...prev, childId]
    )
  }

  // Update caregiver child assignments
  const updateCaregiverAssignments = async (caregiverId: string, newChildIds: string[]) => {
    const supabase = createClient()
    const currentAssignments = caregiverAssignments[caregiverId] || []
    
    // Find children to add and remove
    const toAdd = newChildIds.filter(id => !currentAssignments.includes(id))
    const toRemove = currentAssignments.filter(id => !newChildIds.includes(id))
    
    try {
      // Remove old assignments
      if (toRemove.length > 0) {
        await supabase
          .from("caregiver_child_assignments")
          .delete()
          .eq("caregiver_id", caregiverId)
          .in("child_id", toRemove)
      }
      
      // Add new assignments
      if (toAdd.length > 0) {
        await supabase
          .from("caregiver_child_assignments")
          .insert(toAdd.map(childId => ({
            caregiver_id: caregiverId,
            child_id: childId,
            assigned_by: currentUserId
          })))
      }
      
      // Update local state
      setCaregiverAssignments(prev => ({
        ...prev,
        [caregiverId]: newChildIds
      }))
      
      setEditingAssignments(null)
    } catch (error) {
      console.error("Failed to update assignments:", error)
      setInviteMessage({ type: "error", text: "Failed to update child assignments" })
    }
  }

  // Cancel pending invite
  const handleCancelInvite = async (inviteId: string) => {
    const supabase = createClient()
    try {
      await supabase
        .from("caregiver_invites")
        .update({ status: "cancelled" })
        .eq("id", inviteId)

      setPendingInvites(prev => prev.filter(i => i.id !== inviteId))
    } catch (error) {
      console.error("Failed to cancel invite:", error)
    }
  }

  // Copy invite code to clipboard
  const copyInviteCode = (code: string) => {
    navigator.clipboard.writeText(code)
    setInviteMessage({ type: "success", text: "Invite code copied!" })
    setTimeout(() => setInviteMessage(null), 2000)
  }

  // Open edit dialog for a caregiver
  const openEditDialog = (caregiver: Caregiver) => {
    setEditForm({
      name: caregiver.name,
      email: caregiver.email || "",
      phone: caregiver.phone || "",
      avatar_url: caregiver.avatar_url || ""
    })
    setEditingCaregiver(caregiver)
  }

  // Handle avatar upload
  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // Validate file type
    if (!file.type.startsWith("image/")) {
      setInviteMessage({ type: "error", text: "Please select an image file" })
      return
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      setInviteMessage({ type: "error", text: "Image must be less than 5MB" })
      return
    }

    setIsUploading(true)
    try {
      const formData = new FormData()
      formData.append("file", file)

      const response = await fetch("/api/upload", {
        method: "POST",
        body: formData
      })

      if (!response.ok) throw new Error("Upload failed")

      const { url } = await response.json()
      setEditForm(prev => ({ ...prev, avatar_url: url }))
    } catch (error) {
      console.error("Upload error:", error)
      setInviteMessage({ type: "error", text: "Failed to upload image" })
    } finally {
      setIsUploading(false)
    }
  }

  // Save caregiver edits
  const handleSaveCaregiver = async () => {
    if (!editingCaregiver || !editForm.name.trim()) return

    setIsSaving(true)
    const supabase = createClient()

    try {
      const { error } = await supabase
        .from("caregivers")
        .update({
          name: editForm.name.trim(),
          email: editForm.email.trim() || null,
          phone: editForm.phone.trim() || null,
          avatar_url: editForm.avatar_url || null
        })
        .eq("id", editingCaregiver.id)

      if (error) throw error

      // Update local state
      onCaregiversChange(
        caregivers.map((c) => 
          c.id === editingCaregiver.id 
            ? { 
                ...c, 
                name: editForm.name.trim(),
                email: editForm.email.trim() || null,
                phone: editForm.phone.trim() || null,
                avatar_url: editForm.avatar_url || null
              } 
            : c
        )
      )

      setEditingCaregiver(null)
      setInviteMessage({ type: "success", text: "Caregiver updated successfully" })
      setTimeout(() => setInviteMessage(null), 2000)
    } catch (error) {
      console.error("Failed to update caregiver:", error)
      setInviteMessage({ type: "error", text: "Failed to update caregiver" })
    } finally {
      setIsSaving(false)
    }
  }

  const handleAddCaregiver = async () => {
    if (!newCaregiver.name.trim()) return
    setIsLoading(true)

    const supabase = createClient()

    try {
      const { data, error } = await supabase
        .from("caregivers")
        .insert({
          profile_id: profileId,
          name: newCaregiver.name,
          email: newCaregiver.email || null,
          phone: newCaregiver.phone || null,
        })
        .select()
        .single()

      if (error) throw error

      onCaregiversChange([...caregivers, data])
      setNewCaregiver({ name: "", email: "", phone: "" })
      setIsOpen(false)
    } catch (error) {
      console.error("Failed to add caregiver:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleToggleNotifications = async (caregiver: Caregiver) => {
    const supabase = createClient()

    try {
      await supabase
        .from("caregivers")
        .update({ receive_notifications: !caregiver.receive_notifications })
        .eq("id", caregiver.id)

      onCaregiversChange(
        caregivers.map((c) => (c.id === caregiver.id ? { ...c, receive_notifications: !c.receive_notifications } : c)),
      )
    } catch (error) {
      console.error("Failed to toggle notifications:", error)
    }
  }

  const handleDeleteCaregiver = async (caregiverId: string) => {
    const caregiver = caregivers.find(c => c.id === caregiverId)
    
    // Don't allow deleting the last admin
    const adminCount = caregivers.filter(c => c.is_admin).length
    if (caregiver?.is_admin && adminCount <= 1) {
      setInviteMessage({ type: "error", text: "Cannot remove the last admin" })
      setTimeout(() => setInviteMessage(null), 3000)
      return
    }

    const supabase = createClient()

    try {
      await supabase.from("caregivers").delete().eq("id", caregiverId)
      
      // Also cancel any pending invite associated with this caregiver
      if (caregiver?.invite_id) {
        await supabase
          .from("caregiver_invites")
          .update({ status: "cancelled" })
          .eq("id", caregiver.invite_id)
      }
      
      onCaregiversChange(caregivers.filter((c) => c.id !== caregiverId))
      setCaregiverToRemove(null)
    } catch (error) {
      console.error("Failed to delete caregiver:", error)
    }
  }

  return (
    <div className="space-y-4">
      {/* Message Display */}
      {inviteMessage && (
        <div className={`flex items-center gap-2 rounded-lg p-3 ${
          inviteMessage.type === "success" 
            ? "bg-green-500/20 text-green-400" 
            : "bg-red-500/20 text-red-400"
        }`}>
          {inviteMessage.type === "success" ? <Check className="h-4 w-4" /> : <X className="h-4 w-4" />}
          <span className="text-sm">{inviteMessage.text}</span>
        </div>
      )}

      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold">Team Management</h2>
          <p className="text-sm text-muted-foreground">Invite and manage caregivers</p>
        </div>
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="bg-gradient-to-r from-[var(--space-purple)] to-[var(--space-blue)]">
              <UserPlus className="mr-1 h-4 w-4" />
              Invite
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Invite Caregiver</DialogTitle>
              <DialogDescription>
                Send an invitation for someone to join as a caregiver. They will be assigned to the children you select.
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              {/* Caregiver Name */}
              <div className="space-y-2">
                <Label htmlFor="invite-name">Caregiver Name</Label>
                <Input
                  id="invite-name"
                  placeholder="e.g., Grandma, Teacher Sarah"
                  value={inviteName}
                  onChange={(e) => setInviteName(e.target.value)}
                />
              </div>

              {/* Contact Method Toggle */}
              <div className="space-y-2">
                <Label>Send Invite Via</Label>
                <div className="flex gap-2">
                  <Button
                    type="button"
                    variant={inviteMethod === "email" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setInviteMethod("email")}
                    className={inviteMethod === "email" ? "bg-[var(--space-purple)]" : "bg-transparent"}
                  >
                    <Mail className="mr-2 h-4 w-4" />
                    Email
                  </Button>
                  <Button
                    type="button"
                    variant={inviteMethod === "sms" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setInviteMethod("sms")}
                    className={inviteMethod === "sms" ? "bg-[var(--space-purple)]" : "bg-transparent"}
                  >
                    <Phone className="mr-2 h-4 w-4" />
                    SMS
                  </Button>
                </div>
              </div>

              {/* Email or Phone Input */}
              {inviteMethod === "email" ? (
                <div className="space-y-2">
                  <Label htmlFor="invite-email">Email Address</Label>
                  <Input
                    id="invite-email"
                    type="email"
                    placeholder="caregiver@example.com"
                    value={inviteEmail}
                    onChange={(e) => setInviteEmail(e.target.value)}
                  />
                </div>
              ) : (
                <div className="space-y-2">
                  <Label htmlFor="invite-phone">Phone Number</Label>
                  <Input
                    id="invite-phone"
                    type="tel"
                    placeholder="(555) 123-4567"
                    value={invitePhone}
                    onChange={(e) => setInvitePhone(e.target.value)}
                  />
                </div>
              )}

              {/* Child Assignment Selection */}
              {children.length > 0 && (
                <div className="space-y-2">
                  <Label className="flex items-center gap-2">
                    <Users className="h-4 w-4" />
                    Assign to Children
                  </Label>
                  <div className="rounded-lg border border-border/50 p-3 space-y-2 max-h-40 overflow-y-auto">
                    {children.map((child) => (
                      <div key={child.id} className="flex items-center gap-3">
                        <Checkbox
                          id={`child-${child.id}`}
                          checked={selectedChildIds.includes(child.id)}
                          onCheckedChange={() => toggleChildSelection(child.id)}
                        />
                        <label 
                          htmlFor={`child-${child.id}`}
                          className="flex items-center gap-2 cursor-pointer flex-1"
                        >
                          <div className="h-8 w-8 rounded-full bg-gradient-to-br from-[var(--space-cyan)] to-[var(--space-blue)] flex items-center justify-center text-white text-sm font-bold">
                            {child.child_name.charAt(0).toUpperCase()}
                          </div>
                          <span className="text-sm font-medium">{child.child_name}</span>
                        </label>
                      </div>
                    ))}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Caregivers can only see and manage children they are assigned to
                  </p>
                </div>
              )}

              {/* Invite Code Display */}
              {showInviteCode && (
                <div className="rounded-lg bg-muted/50 p-4 text-center">
                  <p className="text-sm text-muted-foreground mb-2">Invite Code</p>
                  <div className="flex items-center justify-center gap-2">
                    <span className="text-2xl font-mono font-bold tracking-widest text-[var(--space-cyan)]">
                      {showInviteCode}
                    </span>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => copyInviteCode(showInviteCode)}
                      className="h-8 w-8"
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    Share this code if the invitation didn't arrive
                  </p>
                </div>
              )}

              {/* Send Button */}
              <Button
                onClick={handleSendInvite}
                disabled={isSendingInvite || (inviteMethod === "email" ? !inviteEmail.trim() : !invitePhone.trim())}
                className="w-full bg-gradient-to-r from-[var(--space-purple)] to-[var(--space-blue)]"
              >
                {isSendingInvite ? (
                  "Sending..."
                ) : (
                  <>
                    <Send className="mr-2 h-4 w-4" />
                    Send Invitation
                  </>
                )}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Pending Invites Section */}
      {pendingInvites.length > 0 && (
        <div className="space-y-2">
          <h3 className="text-sm font-medium text-muted-foreground flex items-center gap-2">
            <Clock className="h-4 w-4" />
            Pending Invites
          </h3>
          {pendingInvites.map((invite) => (
            <Card key={invite.id} className="border-border/50 bg-card/80 border-dashed">
              <CardContent className="flex items-center gap-3 p-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[var(--star-gold)]/20 text-[var(--star-gold)]">
                  <MessageSquare className="h-5 w-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm truncate">{invite.phone}</p>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono text-muted-foreground">{invite.invite_code}</span>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => copyInviteCode(invite.invite_code)}
                      className="h-6 w-6"
                    >
                      <Copy className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleCancelInvite(invite.id)}
                  className="h-8 w-8 text-destructive hover:bg-destructive/10"
                >
                  <X className="h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Active Caregivers Section */}
      <div className="space-y-2">
        <h3 className="text-sm font-medium text-muted-foreground">Active Caregivers</h3>
        <div className="space-y-3">
          {caregivers.map((caregiver) => {
            const assignedChildren = caregiverAssignments[caregiver.id] || []
            const isEditingThis = editingAssignments === caregiver.id
            
            return (
              <Card key={caregiver.id} className="border-border/50 bg-card/80">
                <CardContent className="p-4 space-y-3">
                  {/* Main caregiver info row */}
                  <div className="flex items-center gap-3">
                    <Avatar className="h-12 w-12 flex-shrink-0">
                      {caregiver.avatar_url ? (
                        <AvatarImage src={caregiver.avatar_url || "/placeholder.svg"} alt={caregiver.name} />
                      ) : null}
                      <AvatarFallback className={`${
                        caregiver.is_admin 
                          ? "bg-[var(--star-gold)]/20 text-[var(--star-gold)]" 
                          : caregiver.user_id 
                            ? "bg-[var(--space-cyan)]/20 text-[var(--space-cyan)]"
                            : "bg-[var(--space-blue)]/20 text-[var(--space-blue)]"
                      }`}>
                        {caregiver.is_admin ? <Shield className="h-6 w-6" /> : caregiver.name.charAt(0).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="font-medium truncate">{caregiver.name}</p>
                        {caregiver.is_admin && (
                          <Badge variant="outline" className="text-[10px] px-1.5 py-0 border-[var(--star-gold)] text-[var(--star-gold)]">
                            Admin
                          </Badge>
                        )}
                        {caregiver.user_id && !caregiver.is_admin && (
                          <Badge variant="outline" className="text-[10px] px-1.5 py-0 border-[var(--space-cyan)] text-[var(--space-cyan)]">
                            Linked
                          </Badge>
                        )}
                      </div>
                      {caregiver.email && <p className="text-xs text-muted-foreground truncate flex items-center gap-1"><Mail className="h-3 w-3" />{caregiver.email}</p>}
                      {caregiver.phone && <p className="text-xs text-muted-foreground truncate flex items-center gap-1"><Phone className="h-3 w-3" />{caregiver.phone}</p>}
                    </div>
                    <div className="flex items-center gap-1 flex-shrink-0">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => openEditDialog(caregiver)}
                        className="h-9 w-9 text-muted-foreground hover:text-foreground"
                        title="Edit profile"
                      >
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleToggleNotifications(caregiver)}
                        className={`h-9 w-9 ${caregiver.receive_notifications ? "text-[var(--space-cyan)]" : "text-muted-foreground"}`}
                      >
                        {caregiver.receive_notifications ? <Bell className="h-4 w-4" /> : <BellOff className="h-4 w-4" />}
                      </Button>
                      {caregiver.user_id !== currentUserId && (
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => setCaregiverToRemove(caregiver)}
                          className="h-9 w-9 text-destructive hover:bg-destructive/10"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                  
                  {/* Child assignments section (not shown for admins - they see all) */}
                  {!caregiver.is_admin && children.length > 0 && (
                    <div className="border-t border-border/30 pt-3">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs text-muted-foreground flex items-center gap-1">
                          <Users className="h-3 w-3" />
                          Assigned Children
                        </span>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setEditingAssignments(isEditingThis ? null : caregiver.id)}
                          className="h-6 text-xs"
                        >
                          {isEditingThis ? "Done" : "Edit"}
                        </Button>
                      </div>
                      
                      {isEditingThis ? (
                        <div className="space-y-2">
                          {children.map((child) => (
                            <div key={child.id} className="flex items-center gap-2">
                              <Checkbox
                                id={`assign-${caregiver.id}-${child.id}`}
                                checked={assignedChildren.includes(child.id)}
                                onCheckedChange={(checked) => {
                                  const newAssignments = checked 
                                    ? [...assignedChildren, child.id]
                                    : assignedChildren.filter(id => id !== child.id)
                                  updateCaregiverAssignments(caregiver.id, newAssignments)
                                }}
                              />
                              <label 
                                htmlFor={`assign-${caregiver.id}-${child.id}`}
                                className="text-sm cursor-pointer"
                              >
                                {child.child_name}
                              </label>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="flex flex-wrap gap-1">
                          {assignedChildren.length === 0 ? (
                            <span className="text-xs text-muted-foreground italic">No children assigned</span>
                          ) : (
                            assignedChildren.map((childId) => {
                              const child = children.find(c => c.id === childId)
                              return child ? (
                                <Badge 
                                  key={childId} 
                                  variant="secondary" 
                                  className="text-xs bg-[var(--space-blue)]/20 text-[var(--space-cyan)]"
                                >
                                  {child.child_name}
                                </Badge>
                              ) : null
                            })
                          )}
                        </div>
                      )}
                    </div>
                  )}
                  
                  {/* Admin sees all indicator */}
                  {caregiver.is_admin && children.length > 0 && (
                    <div className="border-t border-border/30 pt-2">
                      <span className="text-xs text-[var(--star-gold)] flex items-center gap-1">
                        <Shield className="h-3 w-3" />
                        Admin has access to all children
                      </span>
                    </div>
                  )}
                </CardContent>
              </Card>
            )
          })}
        </div>
      </div>

      {/* Remove Caregiver Confirmation */}
      <AlertDialog open={!!caregiverToRemove} onOpenChange={() => setCaregiverToRemove(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove Caregiver</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to remove {caregiverToRemove?.name}? They will no longer have access to manage this profile.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => caregiverToRemove && handleDeleteCaregiver(caregiverToRemove.id)}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Remove
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Edit Caregiver Dialog */}
      <Dialog open={!!editingCaregiver} onOpenChange={(open) => !open && setEditingCaregiver(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Caregiver Profile</DialogTitle>
            <DialogDescription>
              Update profile picture and contact information
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6 py-4">
            {/* Avatar Upload Section */}
            <div className="flex flex-col items-center gap-4">
              <div className="relative">
                <Avatar className="h-24 w-24">
                  {editForm.avatar_url ? (
                    <AvatarImage src={editForm.avatar_url || "/placeholder.svg"} alt={editForm.name} />
                  ) : null}
                  <AvatarFallback className="bg-[var(--space-cyan)]/20 text-[var(--space-cyan)] text-2xl">
                    {editForm.name.charAt(0).toUpperCase() || "?"}
                  </AvatarFallback>
                </Avatar>
                <label 
                  htmlFor="avatar-upload" 
                  className="absolute bottom-0 right-0 flex h-8 w-8 cursor-pointer items-center justify-center rounded-full bg-[var(--space-cyan)] text-white shadow-lg hover:bg-[var(--space-cyan)]/80 transition-colors"
                >
                  {isUploading ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Camera className="h-4 w-4" />
                  )}
                </label>
                <input
                  id="avatar-upload"
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleAvatarUpload}
                  disabled={isUploading}
                />
              </div>
              <p className="text-xs text-muted-foreground">Tap to upload a profile picture</p>
            </div>

            {/* Contact Information */}
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="edit-name">Name</Label>
                <Input
                  id="edit-name"
                  value={editForm.name}
                  onChange={(e) => setEditForm(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Enter name"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="edit-email" className="flex items-center gap-2">
                  <Mail className="h-4 w-4" />
                  Email
                </Label>
                <Input
                  id="edit-email"
                  type="email"
                  value={editForm.email}
                  onChange={(e) => setEditForm(prev => ({ ...prev, email: e.target.value }))}
                  placeholder="email@example.com"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="edit-phone" className="flex items-center gap-2">
                  <Phone className="h-4 w-4" />
                  Phone
                </Label>
                <Input
                  id="edit-phone"
                  type="tel"
                  value={editForm.phone}
                  onChange={(e) => setEditForm(prev => ({ ...prev, phone: e.target.value }))}
                  placeholder="+1 (555) 123-4567"
                />
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-3 pt-2">
            <Button
              variant="outline"
              className="flex-1 bg-transparent"
              onClick={() => setEditingCaregiver(null)}
            >
              Cancel
            </Button>
            <Button
              onClick={handleSaveCaregiver}
              disabled={isSaving || !editForm.name.trim()}
              className="flex-1 bg-gradient-to-r from-[var(--space-purple)] to-[var(--space-blue)]"
            >
              {isSaving ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : (
                "Save Changes"
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
