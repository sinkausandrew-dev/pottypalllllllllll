"use client"

import { cn } from "@/lib/utils"

import type React from "react"
import { useState, useRef, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog"
import { ScrollArea } from "@/components/ui/scroll-area"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import type { Profile, Child, CustomButton, Reward, VoiceCharacter } from "@/lib/types"
import { VOICE_CHARACTERS } from "@/lib/types"
import { 
  User, Star, Gift, Zap, Plus, Minus, Trash2, Pencil, AlertTriangle, 
  ImageIcon, X, Camera, Volume2, Check, ChevronDown, UserPlus, Mic, MessageCircle, ChevronRight, FileText,
  Sparkles, Cloud, Book, Shield
} from "lucide-react"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

interface ChildrenManagerProps {
  profile: Profile
  children: Child[]
  customButtons: CustomButton[]
  rewards: Reward[]
  onChildrenChange: (children: Child[]) => void
  onCustomButtonsChange: (buttons: CustomButton[]) => void
  onRewardsChange: (rewards: Reward[]) => void
  selectedChildId?: string
  onSelectChild?: (childId: string) => void
  hideChildSelector?: boolean
}

const COLOR_PRESETS = [
  { name: "Purple", value: "#9333ea" },
  { name: "Blue", value: "#3b82f6" },
  { name: "Cyan", value: "#06b6d4" },
  { name: "Green", value: "#22c55e" },
  { name: "Yellow", value: "#eab308" },
  { name: "Orange", value: "#f97316" },
  { name: "Red", value: "#ef4444" },
  { name: "Pink", value: "#ec4899" },
]

const SUGGESTED_REWARD_TIERS = [
  { name: "Small Reward", points: 25, description: "e.g., Sticker, High-five, Small snack" },
  { name: "Medium Reward", points: 50, description: "e.g., 15 min screen time, Favorite snack" },
  { name: "Big Reward", points: 100, description: "e.g., Trip to park, New toy, Special activity" },
]

export function ChildrenManager({
  profile,
  children,
  customButtons,
  rewards,
  onChildrenChange,
  onCustomButtonsChange,
  onRewardsChange,
  selectedChildId: externalSelectedChildId,
  onSelectChild,
  hideChildSelector = false,
}: ChildrenManagerProps) {
  const router = useRouter()
  const safeChildren = children || []
  const [internalSelectedChildId, setInternalSelectedChildId] = useState<string>(safeChildren[0]?.id || "")
  
  // Use external selectedChildId if provided, otherwise use internal state
  const selectedChildId = externalSelectedChildId ?? internalSelectedChildId
  const setSelectedChildId = (id: string) => {
    if (onSelectChild) {
      onSelectChild(id)
    } else {
      setInternalSelectedChildId(id)
    }
  }
  const [activeTab, setActiveTab] = useState<"profile" | "buttons" | "rewards">("profile")
  const [savedMessage, setSavedMessage] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  
  // Selected child data
  const selectedChild = children.find(c => c.id === selectedChildId)
  const childButtons = customButtons.filter(b => b.child_id === selectedChildId)
  const childRewards = rewards.filter(r => r.child_id === selectedChildId)

  // Profile editing state
  const [childName, setChildName] = useState(selectedChild?.child_name || "")
  const [childAge, setChildAge] = useState(selectedChild?.child_age?.toString() || "")
  const [totalPoints, setTotalPoints] = useState(selectedChild?.total_points?.toString() || "0")
  const [voicePreference, setVoicePreference] = useState<VoiceCharacter>(selectedChild?.voice_preference || "female")
  const [childNotes, setChildNotes] = useState(selectedChild?.notes || "")
  const [isEditingPoints, setIsEditingPoints] = useState(false)
  
  // Profile picture state
  const [avatarPreview, setAvatarPreview] = useState<string | null>(selectedChild?.avatar_url || null)
  const [isUploadingAvatar, setIsUploadingAvatar] = useState(false)
  const avatarInputRef = useRef<HTMLInputElement>(null)

  // Delete child state
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false)
  const [deleteConfirmName, setDeleteConfirmName] = useState("")
  const [isDeleting, setIsDeleting] = useState(false)

  // Add child state
  const [addChildOpen, setAddChildOpen] = useState(false)
  const [newChildName, setNewChildName] = useState("")
  const [newChildAge, setNewChildAge] = useState("")
  const [newChildAvatarUrl, setNewChildAvatarUrl] = useState<string | null>(null)
  const [newChildAvatarPreview, setNewChildAvatarPreview] = useState<string | null>(null)
  const [isUploadingNewChildAvatar, setIsUploadingNewChildAvatar] = useState(false)
  const newChildAvatarInputRef = useRef<HTMLInputElement>(null)

  // Custom button state
  const [buttonDialogOpen, setButtonDialogOpen] = useState(false)
  const [editingButton, setEditingButton] = useState<CustomButton | null>(null)
  const [buttonForm, setButtonForm] = useState({ name: "", tts_message: "", color: "#9333ea", icon_url: "", category: "potty" as "potty" | "communication", awards_points: true })
  const [buttonImagePreview, setButtonImagePreview] = useState<string | null>(null)
  const buttonFileInputRef = useRef<HTMLInputElement>(null)
  const [isUploading, setIsUploading] = useState(false)

  // Reward state
  const [rewardDialogOpen, setRewardDialogOpen] = useState(false)
  const [rewardStep, setRewardStep] = useState<"tier" | "customize">("tier")
  const [selectedTier, setSelectedTier] = useState<typeof SUGGESTED_REWARD_TIERS[0] | null>(null)
  const [editingReward, setEditingReward] = useState<Reward | null>(null)
  const [rewardForm, setRewardForm] = useState({ name: "", description: "", points_cost: "25", image_url: "" })
  const [rewardImagePreview, setRewardImagePreview] = useState<string | null>(null)
  const rewardFileInputRef = useRef<HTMLInputElement>(null)

  // Update form when selected child changes
  useEffect(() => {
    if (selectedChild) {
      setChildName(selectedChild.child_name)
      setChildAge(selectedChild.child_age?.toString() || "")
      setTotalPoints(selectedChild.total_points?.toString() || "0")
      setVoicePreference(selectedChild.voice_preference || "female")
      setChildNotes(selectedChild.notes || "")
      setAvatarPreview(selectedChild.avatar_url || null)
    }
  }, [selectedChild])

  const showSavedMessage = (message: string) => {
    setSavedMessage(message)
    setTimeout(() => setSavedMessage(null), 2000)
  }

  // Avatar upload
  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file || !selectedChild) return

    const reader = new FileReader()
    reader.onloadend = () => setAvatarPreview(reader.result as string)
    reader.readAsDataURL(file)

    setIsUploadingAvatar(true)
    try {
      const formData = new FormData()
      formData.append("file", file)
      const response = await fetch("/api/upload-reward-image", { method: "POST", body: formData })
      const data = await response.json()
      
      if (data.url) {
        const supabase = createClient()
        await supabase.from("children").update({ avatar_url: data.url }).eq("id", selectedChild.id)
        
        onChildrenChange(children.map(c => 
          c.id === selectedChild.id ? { ...c, avatar_url: data.url } : c
        ))
        showSavedMessage("Photo updated!")
      }
    } catch (error) {
      console.error("Failed to upload avatar:", error)
      setAvatarPreview(selectedChild.avatar_url || null)
    } finally {
      setIsUploadingAvatar(false)
    }
  }

  // Profile functions
  const handleSaveProfile = async () => {
    if (!selectedChild) return
    setIsLoading(true)
    const supabase = createClient()

    try {
      await supabase
        .from("children")
        .update({
          child_name: childName,
          child_age: childAge ? Number.parseInt(childAge) : null,
          voice_preference: voicePreference,
          notes: childNotes || null,
        })
        .eq("id", selectedChild.id)

      onChildrenChange(children.map(c => 
        c.id === selectedChild.id 
          ? { ...c, child_name: childName, child_age: childAge ? Number.parseInt(childAge) : null, voice_preference: voicePreference, notes: childNotes || null }
          : c
      ))
      showSavedMessage("Profile saved!")
    } catch (error) {
      console.error("Failed to save profile:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleSavePoints = async () => {
    if (!selectedChild) return
    const points = Number.parseInt(totalPoints)
    if (isNaN(points) || points < 0) return

    setIsLoading(true)
    const supabase = createClient()

    try {
      await supabase.from("children").update({ total_points: points }).eq("id", selectedChild.id)
      onChildrenChange(children.map(c => 
        c.id === selectedChild.id ? { ...c, total_points: points } : c
      ))
      setIsEditingPoints(false)
      showSavedMessage("Points updated!")
    } catch (error) {
      console.error("Failed to update points:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleDeleteChild = async () => {
    if (!selectedChild || deleteConfirmName !== selectedChild.child_name) return
    
    setIsDeleting(true)
    const supabase = createClient()

    try {
      await supabase.from("children").delete().eq("id", selectedChild.id)
      
      const updatedChildren = children.filter(c => c.id !== selectedChild.id)
      onChildrenChange(updatedChildren)
      onCustomButtonsChange(customButtons.filter(b => b.child_id !== selectedChild.id))
      onRewardsChange(rewards.filter(r => r.child_id !== selectedChild.id))
      
      setDeleteConfirmOpen(false)
      setDeleteConfirmName("")
      
      if (updatedChildren.length > 0) {
        setSelectedChildId(updatedChildren[0].id)
      }
    } catch (error) {
      console.error("Failed to delete child:", error)
    } finally {
      setIsDeleting(false)
    }
  }

  // New child avatar upload handler
  const handleNewChildAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onloadend = () => setNewChildAvatarPreview(reader.result as string)
    reader.readAsDataURL(file)

    setIsUploadingNewChildAvatar(true)
    try {
      const formData = new FormData()
      formData.append("file", file)
      const response = await fetch("/api/upload-reward-image", { method: "POST", body: formData })
      const data = await response.json()
      
      if (data.url) {
        setNewChildAvatarUrl(data.url)
      }
    } catch (error) {
      console.error("Failed to upload avatar:", error)
      setNewChildAvatarPreview(null)
    } finally {
      setIsUploadingNewChildAvatar(false)
    }
  }

  const handleAddChild = async () => {
    if (!newChildName.trim()) return
    setIsLoading(true)
    const supabase = createClient()

    try {
      const { data: userData } = await supabase.auth.getUser()
      if (!userData.user) throw new Error("Not authenticated")

      const { data, error } = await supabase
        .from("children")
        .insert({
          user_id: userData.user.id,
          child_name: newChildName,
          child_age: newChildAge ? Number.parseInt(newChildAge) : null,
          total_points: 0,
          avatar: "rocket",
          avatar_url: newChildAvatarUrl || null,
          voice_preference: "female",
        })
        .select()
        .single()

      if (error) throw error

      onChildrenChange([...children, data])
      setSelectedChildId(data.id)
      setAddChildOpen(false)
      setNewChildName("")
      setNewChildAge("")
      setNewChildAvatarUrl(null)
      setNewChildAvatarPreview(null)
      showSavedMessage("Child added!")
    } catch (error) {
      console.error("Failed to add child:", error)
    } finally {
      setIsLoading(false)
    }
  }

  // Test TTS with voice preference - prioritizes modern, natural-sounding voices
  const testTTS = (message: string, voice?: "male" | "female") => {
    if ("speechSynthesis" in window) {
      speechSynthesis.cancel()
      
      const voices = speechSynthesis.getVoices()
      const preference = voice || voicePreference
      
      // Find the best natural-sounding voice by checking for quality indicators
      const findNaturalVoice = (genderNames: string[], fallbackNames: string[]) => {
        const englishVoices = voices.filter(v => v.lang.startsWith("en"))
        
        // Priority 1: Google or Microsoft Neural/Natural voices (highest quality)
        for (const name of genderNames) {
          const googleVoice = englishVoices.find(v => 
            v.name.toLowerCase().includes("google") && 
            v.name.toLowerCase().includes(name.toLowerCase())
          )
          if (googleVoice) return googleVoice
        }
        
        // Priority 2: Voices with "Natural" or "Neural" in name
        for (const name of genderNames) {
          const naturalVoice = englishVoices.find(v => 
            (v.name.includes("Natural") || v.name.includes("Neural")) &&
            v.name.toLowerCase().includes(name.toLowerCase())
          )
          if (naturalVoice) return naturalVoice
        }
        
        // Priority 3: Premium Apple voices (Samantha, Alex on macOS/iOS)
        for (const name of genderNames) {
          const premiumVoice = englishVoices.find(v => 
            v.name.includes(name) && v.localService === false
          )
          if (premiumVoice) return premiumVoice
        }
        
        // Priority 4: Any voice with these names
        for (const name of [...genderNames, ...fallbackNames]) {
          const voice = englishVoices.find(v => v.name.includes(name))
          if (voice) return voice
        }
        
        // Priority 5: Any US English voice
        const usVoice = englishVoices.find(v => v.lang === "en-US")
        if (usVoice) return usVoice
        
        return englishVoices[0] || voices[0]
      }
      
      let selectedVoice: SpeechSynthesisVoice | null = null
      
      if (preference === "male") {
        // Modern male voices - avoiding robotic ones like "Fred" or default system voices
        selectedVoice = findNaturalVoice(
          ["James", "Guy", "Aaron", "Christopher", "Liam", "Matthew", "Ryan", "Brian", "Andrew"],
          ["Daniel", "David", "Alex", "Tom", "Oliver", "William"]
        )
      } else {
        // Modern female voices
        selectedVoice = findNaturalVoice(
          ["Samantha", "Ava", "Allison", "Zoe", "Emma", "Lily", "Olivia", "Charlotte"],
          ["Jenny", "Aria", "Susan", "Karen", "Victoria", "Kate"]
        )
      }
      
      // Create utterance with natural speech settings
      const utterance = new SpeechSynthesisUtterance(message)
      utterance.volume = 1.0
      utterance.pitch = preference === "male" ? 0.95 : 1.0 // Slightly lower pitch for male
      utterance.rate = 0.95 // Natural speaking pace
      
      if (selectedVoice) {
        utterance.voice = selectedVoice
      }
      
      // Handle Chrome's bug where long utterances get cut off - split into chunks
      const maxChunkLength = 200
      if (message.length > maxChunkLength) {
        const sentences = message.match(/[^.!?]+[.!?]+/g) || [message]
        let currentChunk = ""
        const chunks: string[] = []
        
        for (const sentence of sentences) {
          if ((currentChunk + sentence).length > maxChunkLength && currentChunk) {
            chunks.push(currentChunk.trim())
            currentChunk = sentence
          } else {
            currentChunk += sentence
          }
        }
        if (currentChunk.trim()) chunks.push(currentChunk.trim())
        
        let chunkIndex = 0
        const speakNextChunk = () => {
          if (chunkIndex < chunks.length) {
            const chunkUtterance = new SpeechSynthesisUtterance(chunks[chunkIndex])
            chunkUtterance.volume = 1.0
            chunkUtterance.pitch = preference === "male" ? 0.95 : 1.0
            chunkUtterance.rate = 0.95
            if (selectedVoice) chunkUtterance.voice = selectedVoice
            chunkUtterance.onend = () => {
              chunkIndex++
              speakNextChunk()
            }
            speechSynthesis.speak(chunkUtterance)
          }
        }
        speakNextChunk()
      } else {
        speechSynthesis.speak(utterance)
      }
    }
  }

  // Button functions
  const resetButtonForm = () => {
    setButtonForm({ name: "", tts_message: "", color: "#9333ea", icon_url: "", category: "potty", awards_points: true })
    setButtonImagePreview(null)
    setEditingButton(null)
  }

  const handleButtonImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onloadend = () => setButtonImagePreview(reader.result as string)
    reader.readAsDataURL(file)

    setIsUploading(true)
    try {
      const formData = new FormData()
      formData.append("file", file)
      const response = await fetch("/api/upload-reward-image", { method: "POST", body: formData })
      const data = await response.json()
      if (data.url) {
        setButtonForm({ ...buttonForm, icon_url: data.url })
      }
    } catch (error) {
      console.error("Failed to upload image:", error)
      setButtonImagePreview(null)
    } finally {
      setIsUploading(false)
    }
  }

  const handleSaveButton = async () => {
    if (!selectedChild || !buttonForm.name.trim() || !buttonForm.tts_message.trim()) return
    setIsLoading(true)
    const supabase = createClient()

    try {
      if (editingButton) {
        const { data, error } = await supabase
          .from("custom_buttons")
          .update({
            name: buttonForm.name,
            tts_message: buttonForm.tts_message,
            color: buttonForm.color,
            icon_url: buttonForm.icon_url || null,
            category: buttonForm.category,
            awards_points: buttonForm.awards_points,
          })
          .eq("id", editingButton.id)
          .select()
          .single()

        if (error) throw error
        onCustomButtonsChange(customButtons.map(b => b.id === editingButton.id ? data : b))
      } else {
        const { data, error } = await supabase
          .from("custom_buttons")
          .insert({
            child_id: selectedChild.id,
            name: buttonForm.name,
            tts_message: buttonForm.tts_message,
            color: buttonForm.color,
            icon_url: buttonForm.icon_url || null,
            display_order: childButtons.length,
            category: buttonForm.category,
            awards_points: buttonForm.awards_points,
          })
          .select()
          .single()

        if (error) throw error
        onCustomButtonsChange([...customButtons, data])
      }

      setButtonDialogOpen(false)
      resetButtonForm()
      showSavedMessage(editingButton ? "Button updated!" : "Button created!")
    } catch (error) {
      console.error("Failed to save button:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleToggleButton = async (button: CustomButton) => {
    const supabase = createClient()
    try {
      await supabase.from("custom_buttons").update({ is_active: !button.is_active }).eq("id", button.id)
      onCustomButtonsChange(customButtons.map(b => b.id === button.id ? { ...b, is_active: !b.is_active } : b))
    } catch (error) {
      console.error("Failed to toggle button:", error)
    }
  }

  const handleDeleteButton = async (buttonId: string) => {
    const supabase = createClient()
    try {
      await supabase.from("custom_buttons").delete().eq("id", buttonId)
      onCustomButtonsChange(customButtons.filter(b => b.id !== buttonId))
      showSavedMessage("Button deleted!")
    } catch (error) {
      console.error("Failed to delete button:", error)
    }
  }

  // Reward functions
  const resetRewardForm = () => {
    setRewardForm({ name: "", description: "", points_cost: "25", image_url: "" })
    setRewardImagePreview(null)
    setEditingReward(null)
    setRewardStep("tier")
    setSelectedTier(null)
  }

  const handleRewardImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onloadend = () => setRewardImagePreview(reader.result as string)
    reader.readAsDataURL(file)

    setIsUploading(true)
    try {
      const formData = new FormData()
      formData.append("file", file)
      const response = await fetch("/api/upload-reward-image", { method: "POST", body: formData })
      const data = await response.json()
      if (data.url) {
        setRewardForm({ ...rewardForm, image_url: data.url })
      }
    } catch (error) {
      console.error("Failed to upload image:", error)
      setRewardImagePreview(null)
    } finally {
      setIsUploading(false)
    }
  }

  const handleSaveReward = async () => {
    if (!selectedChild || !rewardForm.name.trim()) return
    setIsLoading(true)
    const supabase = createClient()

    try {
      if (editingReward) {
        const { data, error } = await supabase
          .from("rewards")
          .update({
            name: rewardForm.name,
            description: rewardForm.description || null,
            points_cost: Number.parseInt(rewardForm.points_cost) || 25,
            image_url: rewardForm.image_url || null,
          })
          .eq("id", editingReward.id)
          .select()
          .single()

        if (error) throw error
        onRewardsChange(rewards.map(r => r.id === editingReward.id ? data : r))
      } else {
        const { data, error } = await supabase
          .from("rewards")
          .insert({
            child_id: selectedChild.id,
            profile_id: profile.id,
            name: rewardForm.name,
            description: rewardForm.description || null,
            points_cost: Number.parseInt(rewardForm.points_cost) || 25,
            image_url: rewardForm.image_url || null,
            icon: "gift",
          })
          .select()
          .single()

        if (error) throw error
        onRewardsChange([...rewards, data])
      }

      setRewardDialogOpen(false)
      resetRewardForm()
      showSavedMessage(editingReward ? "Reward updated!" : "Reward created!")
    } catch (error) {
      console.error("Failed to save reward:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleToggleReward = async (reward: Reward) => {
    const supabase = createClient()
    try {
      await supabase.from("rewards").update({ is_active: !reward.is_active }).eq("id", reward.id)
      onRewardsChange(rewards.map(r => r.id === reward.id ? { ...r, is_active: !r.is_active } : r))
    } catch (error) {
      console.error("Failed to toggle reward:", error)
    }
  }

  const handleDeleteReward = async (rewardId: string) => {
    const supabase = createClient()
    try {
      await supabase.from("rewards").delete().eq("id", rewardId)
      onRewardsChange(rewards.filter(r => r.id !== rewardId))
      showSavedMessage("Reward deleted!")
    } catch (error) {
      console.error("Failed to delete reward:", error)
    }
  }

  if (children.length === 0) {
    return (
      <Card className="border-border/50 bg-card/80">
        <CardContent className="flex flex-col items-center justify-center py-12">
          <User className="h-12 w-12 text-muted-foreground/50" />
          <p className="mt-4 text-center text-muted-foreground">No children added yet</p>
          <Button
            onClick={() => setAddChildOpen(true)}
            className="mt-4 bg-gradient-to-r from-[var(--space-purple)] to-[var(--space-blue)]"
          >
            <UserPlus className="mr-2 h-4 w-4" />
            Add Your First Child
          </Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      {savedMessage && (
        <div className="flex items-center justify-center gap-2 rounded-lg bg-green-500/20 p-3 text-green-400">
          <Check className="h-4 w-4" />
          <span className="text-sm">{savedMessage}</span>
        </div>
      )}

      {/* Children Selector - Horizontal scroll cards (hidden when controlled externally) */}
      {!hideChildSelector && (
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <Label className="text-sm font-medium">Select Child</Label>
          <span className="text-xs text-muted-foreground">{children.length} child{children.length !== 1 ? "ren" : ""}</span>
        </div>
        
        <div className="flex gap-3 overflow-x-auto pb-2 -mx-1 px-1">
          {/* Existing Children */}
          {children.map((child) => (
            <button
              key={child.id}
              onClick={() => setSelectedChildId(child.id)}
              className={cn(
                "flex flex-col items-center gap-2 p-3 rounded-xl border-2 transition-all min-w-[90px] flex-shrink-0",
                selectedChildId === child.id
                  ? "border-[var(--space-purple)] bg-[var(--space-purple)]/10"
                  : "border-border/50 bg-card/50 hover:border-[var(--space-purple)]/50"
              )}
            >
              <div className="h-12 w-12 rounded-full overflow-hidden bg-muted flex-shrink-0">
                {child.avatar_url ? (
                  <img src={child.avatar_url || "/placeholder.svg"} alt={child.child_name} className="h-full w-full object-cover" />
                ) : (
                  <div className="h-full w-full flex items-center justify-center bg-gradient-to-br from-[var(--space-cyan)] to-[var(--space-blue)] text-white font-bold text-lg">
                    {child.child_name.charAt(0).toUpperCase()}
                  </div>
                )}
              </div>
              <div className="text-center">
                <p className="font-medium text-sm truncate max-w-[80px]">{child.child_name}</p>
                <p className="text-xs text-muted-foreground flex items-center justify-center gap-1">
                  <Star className="h-3 w-3 fill-[var(--star-gold)] text-[var(--star-gold)]" />
                  {child.total_points}
                </p>
              </div>
            </button>
          ))}
          
          {/* Add Child Button - Prominent */}
          <button
            onClick={() => setAddChildOpen(true)}
            className="flex flex-col items-center justify-center gap-2 p-3 rounded-xl border-2 border-dashed border-[var(--space-purple)]/50 bg-[var(--space-purple)]/5 hover:bg-[var(--space-purple)]/10 transition-all min-w-[90px] flex-shrink-0"
          >
            <div className="h-12 w-12 rounded-full bg-gradient-to-br from-[var(--space-purple)] to-[var(--space-blue)] flex items-center justify-center">
              <UserPlus className="h-6 w-6 text-white" />
            </div>
            <p className="font-medium text-sm text-[var(--space-purple)]">Add Child</p>
          </button>
        </div>
      </div>
      )}

{/* Hidden trigger for external access */}
<button 
  data-add-child-trigger 
  onClick={() => setAddChildOpen(true)} 
  className="hidden"
  aria-hidden="true"
/>

{/* Add Child Dialog */}
<Dialog open={addChildOpen} onOpenChange={setAddChildOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Child</DialogTitle>
            <DialogDescription>Add a new child to your profile</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {/* Optional Photo Upload */}
            <div className="space-y-2">
              <Label>Photo (optional)</Label>
              <div className="flex items-center gap-4">
                <button
                  type="button"
                  onClick={() => newChildAvatarInputRef.current?.click()}
                  className="relative h-20 w-20 rounded-full border-2 border-dashed border-border flex items-center justify-center hover:border-[var(--space-purple)] transition-colors overflow-hidden bg-muted/30"
                >
                  {newChildAvatarPreview ? (
                    <img src={newChildAvatarPreview || "/placeholder.svg"} alt="" className="h-full w-full object-cover" />
                  ) : (
                    <Camera className="h-8 w-8 text-muted-foreground" />
                  )}
                  {isUploadingNewChildAvatar && (
                    <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                      <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    </div>
                  )}
                </button>
                <input
                  ref={newChildAvatarInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleNewChildAvatarUpload}
                  className="hidden"
                />
                <div className="text-sm text-muted-foreground">
                  <p>Add a photo of your child</p>
                  <p className="text-xs">This is optional</p>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="newChildName">Name</Label>
              <Input
                id="newChildName"
                value={newChildName}
                onChange={(e) => setNewChildName(e.target.value)}
                placeholder="Child's name"
                className="bg-input/50"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="newChildAge">Age (optional)</Label>
              <Input
                id="newChildAge"
                type="number"
                value={newChildAge}
                onChange={(e) => setNewChildAge(e.target.value)}
                placeholder="Age in years"
                className="bg-input/50"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAddChildOpen(false)} className="bg-transparent">Cancel</Button>
            <Button
              onClick={handleAddChild}
              disabled={!newChildName.trim() || isLoading}
              className="bg-gradient-to-r from-[var(--space-purple)] to-[var(--space-blue)]"
            >
              Add Child
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Selected Child Management */}
      {selectedChild && (
        <Card className="border-border/50 bg-card/80">
          <CardContent className="pt-4">
            <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as typeof activeTab)} className="w-full">
              <TabsList className="grid w-full grid-cols-3 bg-muted/50">
                <TabsTrigger value="profile" className="data-[state=active]:bg-background">
                  <User className="h-4 w-4 mr-1" />
                  Profile
                </TabsTrigger>
                <TabsTrigger value="buttons" className="data-[state=active]:bg-background">
                  <Zap className="h-4 w-4 mr-1" />
                  Buttons
                </TabsTrigger>
                <TabsTrigger value="rewards" className="data-[state=active]:bg-background">
                  <Gift className="h-4 w-4 mr-1" />
                  Rewards
                </TabsTrigger>
              </TabsList>

              {/* Profile Tab */}
              <TabsContent value="profile" className="mt-4 space-y-4">
                {/* Profile Picture */}
                <div className="flex flex-col items-center gap-3">
                  <div className="relative">
                    <div className="h-24 w-24 rounded-full overflow-hidden bg-muted">
                      {avatarPreview ? (
                        <img src={avatarPreview || "/placeholder.svg"} alt={selectedChild.child_name} className="h-full w-full object-cover" />
                      ) : (
                        <div className="h-full w-full flex items-center justify-center bg-gradient-to-br from-[var(--space-cyan)] to-[var(--space-blue)] text-white font-bold text-3xl">
                          {selectedChild.child_name.charAt(0).toUpperCase()}
                        </div>
                      )}
                    </div>
                    <button
                      onClick={() => avatarInputRef.current?.click()}
                      disabled={isUploadingAvatar}
                      className="absolute bottom-0 right-0 h-8 w-8 rounded-full bg-[var(--space-purple)] text-white flex items-center justify-center shadow-lg hover:opacity-90 transition-opacity"
                    >
                      <Camera className="h-4 w-4" />
                    </button>
                    <input
                      ref={avatarInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleAvatarUpload}
                      className="hidden"
                    />
                  </div>
                  <p className="text-xs text-muted-foreground">Tap camera to change photo</p>
                </div>

                {/* Name and Age */}
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="childName">Name</Label>
                    <Input
                      id="childName"
                      value={childName}
                      onChange={(e) => setChildName(e.target.value)}
                      className="bg-input/50"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="childAge">Age</Label>
                    <Input
                      id="childAge"
                      type="number"
                      value={childAge}
                      onChange={(e) => setChildAge(e.target.value)}
                      className="bg-input/50"
                    />
                  </div>
                </div>

                {/* Voice Preference */}
                <div className="space-y-3 pt-2">
                  <Label className="flex items-center gap-2">
                    <Mic className="h-4 w-4 text-[var(--space-cyan)]" />
                    Voice for Messages (American)
                  </Label>
                  <RadioGroup
                    value={voicePreference}
                    onValueChange={(v) => setVoicePreference(v as "male" | "female")}
                    className="flex flex-col gap-3"
                  >
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted/30 border border-border/50">
                      <div className="flex items-center space-x-3">
                        <RadioGroupItem value="female" id="female" />
                        <Label htmlFor="female" className="cursor-pointer">
                          <span className="font-medium">Female Voice</span>
                          <span className="block text-xs text-muted-foreground">Warm, friendly American woman</span>
                        </Label>
                      </div>
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => testTTS(`Hi ${childName || "there"}! You're doing such an amazing job today! Keep up the great work!`, "female")}
                        className="h-9 px-3"
                      >
                        <Volume2 className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted/30 border border-border/50">
                      <div className="flex items-center space-x-3">
                        <RadioGroupItem value="male" id="male" />
                        <Label htmlFor="male" className="cursor-pointer">
                          <span className="font-medium">Male Voice</span>
                          <span className="block text-xs text-muted-foreground">Warm, friendly American man</span>
                        </Label>
                      </div>
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => testTTS(`Hi ${childName || "there"}! You're doing such an amazing job today! Keep up the great work!`, "male")}
                        className="h-9 px-3"
                      >
                        <Volume2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </RadioGroup>
                </div>

                {/* Notes Section */}
                <div className="space-y-3 pt-2">
                  <Label htmlFor="childNotes" className="flex items-center gap-2">
                    <FileText className="h-4 w-4 text-[var(--space-pink)]" />
                    Notes
                  </Label>
                  <Textarea
                    id="childNotes"
                    value={childNotes}
                    onChange={(e) => setChildNotes(e.target.value)}
                    placeholder="Add notes about this child's progress, preferences, or anything to remember..."
                    className="bg-input/50 min-h-[100px] resize-none"
                    rows={4}
                  />
                  <p className="text-xs text-muted-foreground">Notes are only visible to caregivers</p>
                </div>

                <Button onClick={handleSaveProfile} disabled={isLoading} className="w-full bg-gradient-to-r from-[var(--space-purple)] to-[var(--space-blue)]">
                  Save Profile
                </Button>

                {/* Points Management */}
                <div className="pt-4 border-t border-border/50">
                  <Label className="flex items-center gap-2 mb-3">
                    <Star className="h-4 w-4 text-[var(--star-gold)]" />
                    Points Management
                  </Label>
                  {isEditingPoints ? (
                    <div className="space-y-3">
                      <div className="flex items-center justify-center gap-4">
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={() => setTotalPoints(Math.max(0, Number.parseInt(totalPoints) - 10).toString())}
                          className="h-12 w-12 bg-transparent"
                        >
                          <Minus className="h-5 w-5" />
                        </Button>
                        <Input
                          type="number"
                          value={totalPoints}
                          onChange={(e) => setTotalPoints(e.target.value)}
                          className="h-14 w-28 text-center text-2xl font-bold bg-input/50"
                          min="0"
                        />
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={() => setTotalPoints((Number.parseInt(totalPoints) + 10).toString())}
                          className="h-12 w-12 bg-transparent"
                        >
                          <Plus className="h-5 w-5" />
                        </Button>
                      </div>
                      <div className="flex gap-3">
                        <Button
                          variant="outline"
                          onClick={() => {
                            setIsEditingPoints(false)
                            setTotalPoints(selectedChild.total_points.toString())
                          }}
                          className="flex-1 bg-transparent"
                        >
                          Cancel
                        </Button>
                        <Button
                          onClick={handleSavePoints}
                          disabled={isLoading}
                          className="flex-1 bg-gradient-to-r from-[var(--space-purple)] to-[var(--space-blue)]"
                        >
                          Save Points
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
                      <div>
                        <p className="text-sm text-muted-foreground">Current Points</p>
                        <p className="text-2xl font-bold text-[var(--star-gold)]">{selectedChild.total_points}</p>
                      </div>
                      <Button variant="outline" onClick={() => setIsEditingPoints(true)} className="bg-transparent">
                        Adjust Points
                      </Button>
                    </div>
                  )}
                </div>

                {/* Delete Child */}
                {children.length > 1 && (
                  <div className="pt-4 border-t border-border/50">
                    <Dialog open={deleteConfirmOpen} onOpenChange={setDeleteConfirmOpen}>
                      <DialogTrigger asChild>
                        <Button variant="outline" className="w-full border-destructive/50 text-destructive hover:bg-destructive/10 bg-transparent">
                          <Trash2 className="mr-2 h-4 w-4" />
                          Remove {selectedChild.child_name}
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle className="flex items-center gap-2 text-destructive">
                            <AlertTriangle className="h-5 w-5" />
                            Remove Child Profile
                          </DialogTitle>
                          <DialogDescription className="text-left">
                            This will permanently delete <strong>{selectedChild.child_name}</strong> and all associated data.
                            <p className="mt-4 font-medium">This action cannot be undone.</p>
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-2 py-4">
                          <Label>Type <strong>{selectedChild.child_name}</strong> to confirm:</Label>
                          <Input
                            value={deleteConfirmName}
                            onChange={(e) => setDeleteConfirmName(e.target.value)}
                            placeholder={selectedChild.child_name}
                            className="bg-input/50"
                          />
                        </div>
                        <DialogFooter>
                          <Button variant="outline" onClick={() => setDeleteConfirmOpen(false)} className="bg-transparent">Cancel</Button>
                          <Button
                            variant="destructive"
                            onClick={handleDeleteChild}
                            disabled={deleteConfirmName !== selectedChild.child_name || isDeleting}
                          >
                            {isDeleting ? "Removing..." : "Remove Child"}
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </div>
                )}
              </TabsContent>

              {/* Buttons Tab */}
              <TabsContent value="buttons" className="mt-4 space-y-4">
                <div className="flex items-center justify-between">
                  <p className="text-sm text-muted-foreground">Custom call-to-action buttons</p>
                  <Button
                    size="sm"
                    onClick={() => {
                      resetButtonForm()
                      setButtonDialogOpen(true)
                    }}
                    className="bg-gradient-to-r from-[var(--space-purple)] to-[var(--space-blue)]"
                  >
                    <Plus className="mr-1 h-4 w-4" />
                    Add Button
                  </Button>
                </div>

                {childButtons.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-8 text-center">
                    <Zap className="h-10 w-10 text-muted-foreground/50" />
                    <p className="mt-2 text-sm text-muted-foreground">No custom buttons yet</p>
                    <p className="text-xs text-muted-foreground">Add buttons for things like "HELP", "WATER", or "SNACK"</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {childButtons.map((button) => (
                      <div
                        key={button.id}
                        className="flex items-center gap-3 p-3 rounded-xl border border-border/50 bg-muted/30"
                      >
                        <div
                          className="h-12 w-12 rounded-xl flex items-center justify-center flex-shrink-0"
                          style={{ backgroundColor: button.color }}
                        >
                          {button.icon_url ? (
                            <img src={button.icon_url || "/placeholder.svg"} alt="" className="h-8 w-8 object-contain" />
                          ) : (
                            <Zap className="h-6 w-6 text-white" />
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <p className="font-medium truncate">{button.name}</p>
                            {button.awards_points && (
                              <Star className="h-3.5 w-3.5 fill-[var(--star-gold)] text-[var(--star-gold)] flex-shrink-0" />
                            )}
                          </div>
                          <p className="text-xs text-muted-foreground truncate">{button.tts_message}</p>
                        </div>
                        <Switch checked={button.is_active} onCheckedChange={() => handleToggleButton(button)} />
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => {
                            setEditingButton(button)
                            setButtonForm({
                              name: button.name,
                              tts_message: button.tts_message,
                              color: button.color,
                              icon_url: button.icon_url || "",
                              category: button.category || "potty",
                              awards_points: button.awards_points ?? true,
                            })
                            setButtonImagePreview(button.icon_url || null)
                            setButtonDialogOpen(true)
                          }}
                          className="h-8 w-8"
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDeleteButton(button.id)}
                          className="h-8 w-8 text-destructive hover:text-destructive"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </TabsContent>

              {/* Rewards Tab */}
              <TabsContent value="rewards" className="mt-4 space-y-4">
                <div className="flex items-center justify-between">
                  <p className="text-sm text-muted-foreground">Custom rewards for {selectedChild.child_name}</p>
                  <Button
                    size="sm"
                    onClick={() => {
                      resetRewardForm()
                      setRewardDialogOpen(true)
                    }}
                    className="bg-gradient-to-r from-[var(--space-purple)] to-[var(--space-blue)]"
                  >
                    <Plus className="mr-1 h-4 w-4" />
                    Add Reward
                  </Button>
                </div>

                {childRewards.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-8 text-center">
                    <Gift className="h-10 w-10 text-muted-foreground/50" />
                    <p className="mt-2 text-sm text-muted-foreground">No rewards yet</p>
                    <p className="text-xs text-muted-foreground">Add motivating rewards tailored to this child</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {[...childRewards].sort((a, b) => a.points_cost - b.points_cost).map((reward) => (
                      <div
                        key={reward.id}
                        className="flex items-center gap-3 p-3 rounded-xl border border-border/50 bg-muted/30"
                      >
                        <div className="h-12 w-12 rounded-xl flex items-center justify-center flex-shrink-0 bg-[var(--space-purple)]/20">
                          {reward.image_url ? (
                            <img src={reward.image_url || "/placeholder.svg"} alt="" className="h-12 w-12 rounded-xl object-cover" />
                          ) : (
                            <Gift className="h-6 w-6 text-[var(--space-purple)]" />
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium truncate">{reward.name}</p>
                          <div className="flex items-center gap-1 text-[var(--star-gold)]">
                            <Star className="h-3 w-3 fill-current" />
                            <span className="text-sm font-medium">{reward.points_cost}</span>
                          </div>
                        </div>
                        <Switch checked={reward.is_active} onCheckedChange={() => handleToggleReward(reward)} />
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => {
                            setEditingReward(reward)
                            setRewardForm({
                              name: reward.name,
                              description: reward.description || "",
                              points_cost: reward.points_cost.toString(),
                              image_url: reward.image_url || "",
                            })
                            setRewardImagePreview(reward.image_url || null)
                            setRewardStep("customize")
                            setRewardDialogOpen(true)
                          }}
                          className="h-8 w-8"
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDeleteReward(reward.id)}
                          className="h-8 w-8 text-destructive hover:text-destructive"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      )}

      {/* Button Dialog */}
      <Dialog open={buttonDialogOpen} onOpenChange={setButtonDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{editingButton ? "Edit Button" : "Create Custom Button"}</DialogTitle>
            <DialogDescription>
              Create a button that appears on the child's screen
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {/* Category Selection */}
            <div className="space-y-2">
              <Label>Button Type</Label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setButtonForm({ ...buttonForm, category: "potty" })}
                  className={`p-3 rounded-lg border-2 transition-all text-left ${
                    buttonForm.category === "potty" 
                      ? "border-yellow-400 bg-yellow-400/10" 
                      : "border-border hover:border-yellow-400/50"
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <Star className="h-4 w-4 text-yellow-400" />
                    <span className="font-semibold text-sm">Potty Training</span>
                  </div>
                  <p className="text-xs text-muted-foreground">Earns stars when completed</p>
                </button>
                <button
                  type="button"
                  onClick={() => setButtonForm({ ...buttonForm, category: "communication" })}
                  className={`p-3 rounded-lg border-2 transition-all text-left ${
                    buttonForm.category === "communication" 
                      ? "border-blue-400 bg-blue-400/10" 
                      : "border-border hover:border-blue-400/50"
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <MessageCircle className="h-4 w-4 text-blue-400" />
                    <span className="font-semibold text-sm">Communication</span>
                  </div>
                  <p className="text-xs text-muted-foreground">Request help (no stars)</p>
                </button>
              </div>
            </div>

            {/* Awards Points Toggle */}
            <div className="flex items-center justify-between p-3 rounded-lg bg-muted/30 border border-border/50">
              <div className="flex items-center gap-3">
                <Star className="h-5 w-5 text-[var(--star-gold)]" />
                <div>
                  <Label htmlFor="awards-points" className="cursor-pointer font-medium">Awards Stars</Label>
                  <p className="text-xs text-muted-foreground">Child earns points when completed</p>
                </div>
              </div>
              <Switch
                id="awards-points"
                checked={buttonForm.awards_points}
                onCheckedChange={(checked) => setButtonForm({ ...buttonForm, awards_points: checked })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="buttonName">Button Name (max 12 characters)</Label>
              <Input
                id="buttonName"
                value={buttonForm.name}
                onChange={(e) => setButtonForm({ ...buttonForm, name: e.target.value.slice(0, 12) })}
                placeholder={buttonForm.category === "potty" ? "e.g., DRY PANTS" : "e.g., WATER, HELP"}
                className="bg-input/50"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="buttonTTS">Voice Message</Label>
              <div className="flex gap-2">
                <Input
                  id="buttonTTS"
                  value={buttonForm.tts_message}
                  onChange={(e) => setButtonForm({ ...buttonForm, tts_message: e.target.value })}
                  placeholder="What should be spoken?"
                  className="bg-input/50 flex-1"
                />
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  onClick={() => testTTS(buttonForm.tts_message || "Test message")}
                  disabled={!buttonForm.tts_message}
                  className="bg-transparent"
                >
                  <Volume2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
            <div className="space-y-2">
              <Label>Button Color</Label>
              <div className="grid grid-cols-4 gap-2">
                {COLOR_PRESETS.map((color) => (
                  <button
                    key={color.value}
                    onClick={() => setButtonForm({ ...buttonForm, color: color.value })}
                    className={`h-10 rounded-lg transition-all ${
                      buttonForm.color === color.value ? "ring-2 ring-white ring-offset-2 ring-offset-background" : ""
                    }`}
                    style={{ backgroundColor: color.value }}
                  />
                ))}
              </div>
              <div className="flex items-center gap-2 mt-2">
                <Label htmlFor="customColor" className="text-xs">Custom:</Label>
                <input
                  id="customColor"
                  type="color"
                  value={buttonForm.color}
                  onChange={(e) => setButtonForm({ ...buttonForm, color: e.target.value })}
                  className="h-8 w-16 cursor-pointer rounded"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Button Icon (optional)</Label>
              <div className="flex items-center gap-4">
                <button
                  onClick={() => buttonFileInputRef.current?.click()}
                  className="h-16 w-16 rounded-xl border-2 border-dashed border-border flex items-center justify-center hover:border-[var(--space-purple)] transition-colors"
                  style={{ backgroundColor: buttonForm.color + "40" }}
                >
                  {buttonImagePreview ? (
                    <img src={buttonImagePreview || "/placeholder.svg"} alt="" className="h-12 w-12 object-contain" />
                  ) : (
                    <ImageIcon className="h-6 w-6 text-muted-foreground" />
                  )}
                </button>
                <input
                  ref={buttonFileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleButtonImageUpload}
                  className="hidden"
                />
                {buttonImagePreview && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      setButtonImagePreview(null)
                      setButtonForm({ ...buttonForm, icon_url: "" })
                    }}
                  >
                    <X className="h-4 w-4 mr-1" />
                    Remove
                  </Button>
                )}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setButtonDialogOpen(false)} className="bg-transparent">Cancel</Button>
            <Button
              onClick={handleSaveButton}
              disabled={!buttonForm.name.trim() || !buttonForm.tts_message.trim() || isLoading || isUploading}
              className="bg-gradient-to-r from-[var(--space-purple)] to-[var(--space-blue)]"
            >
              {isUploading ? "Uploading..." : editingButton ? "Update" : "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reward Dialog */}
      <Dialog open={rewardDialogOpen} onOpenChange={setRewardDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{editingReward ? "Edit Reward" : "Create Reward"}</DialogTitle>
            <DialogDescription>
              {rewardStep === "tier" ? "Choose a reward tier to start" : "Customize your reward"}
            </DialogDescription>
          </DialogHeader>
          
          {rewardStep === "tier" && !editingReward ? (
            <div className="space-y-3 py-4">
              {SUGGESTED_REWARD_TIERS.map((tier) => (
                <button
                  key={tier.name}
                  onClick={() => {
                    setSelectedTier(tier)
                    setRewardForm({ ...rewardForm, points_cost: tier.points.toString() })
                    setRewardStep("customize")
                  }}
                  className="w-full p-4 rounded-xl border border-border/50 bg-muted/30 hover:bg-muted/50 transition-colors text-left"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-medium">{tier.name}</span>
                    <div className="flex items-center gap-1 text-[var(--star-gold)]">
                      <Star className="h-4 w-4 fill-current" />
                      <span className="font-bold">{tier.points}</span>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">{tier.description}</p>
                </button>
              ))}
              <Button
                variant="outline"
                onClick={() => setRewardStep("customize")}
                className="w-full bg-transparent"
              >
                Custom Amount
              </Button>
            </div>
          ) : (
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="rewardName">Reward Name</Label>
                <Input
                  id="rewardName"
                  value={rewardForm.name}
                  onChange={(e) => setRewardForm({ ...rewardForm, name: e.target.value })}
                  placeholder="e.g., Ice cream, Park trip"
                  className="bg-input/50"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="rewardDesc">Description (optional)</Label>
                <Input
                  id="rewardDesc"
                  value={rewardForm.description}
                  onChange={(e) => setRewardForm({ ...rewardForm, description: e.target.value })}
                  placeholder="Brief description"
                  className="bg-input/50"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="rewardPoints">Points Cost</Label>
                <Input
                  id="rewardPoints"
                  type="number"
                  value={rewardForm.points_cost}
                  onChange={(e) => setRewardForm({ ...rewardForm, points_cost: e.target.value })}
                  min="1"
                  className="bg-input/50"
                />
              </div>
              <div className="space-y-2">
                <Label>Reward Image (optional)</Label>
                <div className="flex items-center gap-4">
                  <button
                    onClick={() => rewardFileInputRef.current?.click()}
                    className="h-16 w-16 rounded-xl border-2 border-dashed border-border flex items-center justify-center hover:border-[var(--space-purple)] transition-colors bg-muted/30"
                  >
                    {rewardImagePreview ? (
                      <img src={rewardImagePreview || "/placeholder.svg"} alt="" className="h-16 w-16 rounded-xl object-cover" />
                    ) : (
                      <ImageIcon className="h-6 w-6 text-muted-foreground" />
                    )}
                  </button>
                  <input
                    ref={rewardFileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleRewardImageUpload}
                    className="hidden"
                  />
                  {rewardImagePreview && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setRewardImagePreview(null)
                        setRewardForm({ ...rewardForm, image_url: "" })
                      }}
                    >
                      <X className="h-4 w-4 mr-1" />
                      Remove
                    </Button>
                  )}
                </div>
              </div>
            </div>
          )}
          
          <DialogFooter>
            {rewardStep === "customize" && !editingReward && (
              <Button variant="outline" onClick={() => setRewardStep("tier")} className="mr-auto bg-transparent">
                Back
              </Button>
            )}
            <Button variant="outline" onClick={() => { setRewardDialogOpen(false); resetRewardForm(); }} className="bg-transparent">
              Cancel
            </Button>
            {rewardStep === "customize" && (
              <Button
                onClick={handleSaveReward}
                disabled={!rewardForm.name.trim() || isLoading || isUploading}
                className="bg-gradient-to-r from-[var(--space-purple)] to-[var(--space-blue)]"
              >
                {isUploading ? "Uploading..." : editingReward ? "Update" : "Create"}
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
