"use client"

import { useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import type { BathroomRequest } from "@/lib/types"
import { Check, X, Droplets, CircleDot, Star, Zap } from "lucide-react"

interface PendingRequestCardProps {
  request: BathroomRequest
  childName: string
  childId: string
  profileId: string
  customButtonName?: string
  onRequestResolved: (requestId: string) => void
}

export function PendingRequestCard({ 
  request, 
  childName, 
  childId, 
  profileId, 
  customButtonName,
  onRequestResolved 
}: PendingRequestCardProps) {
  const [points, setPoints] = useState("10")
  const [isProcessing, setIsProcessing] = useState(false)

  const handleComplete = async () => {
    if (isProcessing) return
    setIsProcessing(true)
    const supabase = createClient()
    const pointsNum = Number.parseInt(points) || 10

    try {
      // Update request status
      const { error: updateError } = await supabase
        .from("bathroom_requests")
        .update({
          status: "completed",
          points_awarded: pointsNum,
          completed_at: new Date().toISOString(),
        })
        .eq("id", request.id)

      if (updateError) throw updateError

      // First get current points from children table
      const { data: childData } = await supabase
        .from("children")
        .select("total_points")
        .eq("id", childId)
        .single()

      if (childData) {
        // Update children table with incremented points
        await supabase
          .from("children")
          .update({ total_points: (childData.total_points || 0) + pointsNum })
          .eq("id", childId)
      } else {
        // Fallback to profiles table via RPC for legacy data
        await supabase.rpc("increment_points", {
          user_id: profileId,
          points_to_add: pointsNum,
        })
      }

      // Immediately remove from UI - deterministic state update
      onRequestResolved(request.id)
    } catch (error) {
      console.error("Failed to complete request:", error)
      setIsProcessing(false)
    }
  }

  const handleCancel = async () => {
    if (isProcessing) return
    setIsProcessing(true)
    const supabase = createClient()

    try {
      const { error } = await supabase
        .from("bathroom_requests")
        .update({
          status: "cancelled",
          completed_at: new Date().toISOString(),
        })
        .eq("id", request.id)

      if (error) throw error

      // Immediately remove from UI - deterministic state update
      onRequestResolved(request.id)
    } catch (error) {
      console.error("Failed to cancel request:", error)
      setIsProcessing(false)
    }
  }

  const timeSince = () => {
    const seconds = Math.floor((Date.now() - new Date(request.created_at).getTime()) / 1000)
    if (seconds < 60) return `${seconds}s ago`
    const minutes = Math.floor(seconds / 60)
    if (minutes < 60) return `${minutes}m ago`
    const hours = Math.floor(minutes / 60)
    return `${hours}h ago`
  }

  // Get display name and styling for the request type
  const getRequestDisplay = () => {
    if (request.request_type === "custom" && customButtonName) {
      return {
        name: customButtonName,
        icon: <Zap className="h-7 w-7 text-white" />,
        gradient: "bg-gradient-to-br from-[var(--star-gold)] to-[oklch(0.75_0.18_60)]",
      }
    }
    if (request.request_type === "pee") {
      return {
        name: "Pee",
        icon: <Droplets className="h-7 w-7 text-white" />,
        gradient: "bg-gradient-to-br from-[var(--space-cyan)] to-[var(--space-blue)]",
      }
    }
    return {
      name: "Poop",
      icon: <CircleDot className="h-7 w-7 text-white" />,
      gradient: "bg-gradient-to-br from-[var(--space-purple)] to-[var(--space-pink)]",
    }
  }

  const requestDisplay = getRequestDisplay()

  return (
    <Card className="border-2 border-[var(--space-purple)] bg-card/90 animate-pulse-glow">
      <CardContent className="p-4">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div
              className={`flex h-14 w-14 items-center justify-center rounded-full ${requestDisplay.gradient}`}
            >
              {requestDisplay.icon}
            </div>
            <div>
              <h3 className="text-lg font-bold capitalize">{requestDisplay.name} Request</h3>
              <p className="text-sm text-muted-foreground">{childName} needs help</p>
              <p className="text-xs text-muted-foreground/70">{timeSince()}</p>
            </div>
          </div>
        </div>

        <div className="mt-4 space-y-3">
          <div className="flex items-center gap-2">
            <Label htmlFor={`points-${request.id}`} className="text-sm">
              Points to award:
            </Label>
            <div className="flex items-center gap-2">
              <Input
                id={`points-${request.id}`}
                type="number"
                min="0"
                max="100"
                value={points}
                onChange={(e) => setPoints(e.target.value)}
                className="h-9 w-20 bg-input/50 text-center"
              />
              <Star className="h-4 w-4 text-[var(--star-gold)]" />
            </div>
          </div>

          <div className="flex gap-2">
            <Button
              onClick={handleComplete}
              disabled={isProcessing}
              className="h-12 flex-1 bg-gradient-to-r from-green-600 to-green-500 hover:from-green-500 hover:to-green-400"
            >
              <Check className="mr-2 h-5 w-5" />
              Complete
            </Button>
            <Button
              variant="outline"
              onClick={handleCancel}
              disabled={isProcessing}
              className="h-12 border-destructive/50 text-destructive hover:bg-destructive/10 bg-transparent"
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
