"use client"

import { useState, useEffect } from "react"
import { createBrowserClient } from "@supabase/ssr"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import {
  Bell, BellRing, Check, Clock, AlertTriangle, Loader2,
  BellOff, Smartphone
} from "lucide-react"
import { usePushNotifications } from "@/hooks/use-push-notifications"
import type { CaregiverPing } from "@/lib/types"

interface PingNotificationsProps {
  caregiverId: string
  childId?: string
}

export function PingNotifications({ caregiverId, childId }: PingNotificationsProps) {
  const [pings, setPings] = useState<CaregiverPing[]>([])
  const [loading, setLoading] = useState(true)
  const { isSupported, isSubscribed, permission, subscribe, unsubscribe, loading: pushLoading } = usePushNotifications({ caregiverId })

  const supabase = createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  )

  // Load pings
  useEffect(() => {
    const loadPings = async () => {
      setLoading(true)
      try {
        let query = supabase
          .from("caregiver_pings")
          .select("*")
          .order("created_at", { ascending: false })
          .limit(50)

        if (childId) {
          query = query.eq("child_id", childId)
        }

        const { data, error } = await query

        if (error) throw error
        setPings(data || [])
      } catch (error) {
        console.error("Error loading pings:", error)
      } finally {
        setLoading(false)
      }
    }

    loadPings()

    // Subscribe to real-time updates
    const channel = supabase
      .channel("ping-updates")
      .on("postgres_changes", {
        event: "INSERT",
        schema: "public",
        table: "caregiver_pings",
      }, (payload) => {
        if (!childId || payload.new.child_id === childId) {
          setPings(prev => [payload.new as CaregiverPing, ...prev])
        }
      })
      .on("postgres_changes", {
        event: "UPDATE",
        schema: "public",
        table: "caregiver_pings",
      }, (payload) => {
        setPings(prev => prev.map(p => p.id === payload.new.id ? payload.new as CaregiverPing : p))
      })
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [childId, supabase])

  // Acknowledge ping (mark as read)
  const acknowledgePing = async (pingId: string) => {
    try {
      await supabase
        .from("caregiver_pings")
        .update({
          is_read: true,
          read_at: new Date().toISOString(),
        })
        .eq("id", pingId)

      setPings(pings.map(p =>
        p.id === pingId
          ? { ...p, is_read: true, read_at: new Date().toISOString(), status: "acknowledged" }
          : p
      ))
    } catch (error) {
      console.error("Error acknowledging ping:", error)
    }
  }

  // Resolve ping (mark as responded)
  const resolvePing = async (pingId: string) => {
    try {
      await supabase
        .from("caregiver_pings")
        .update({ responded_at: new Date().toISOString() })
        .eq("id", pingId)

      setPings(pings.map(p =>
        p.id === pingId ? { ...p, responded_at: new Date().toISOString(), status: "resolved" } : p
      ))
    } catch (error) {
      console.error("Error resolving ping:", error)
    }
  }

  // Handle push notification toggle
  const handlePushToggle = async () => {
    if (isSubscribed) {
      await unsubscribe()
    } else {
      await subscribe()
    }
  }

  // Filter pings based on read/responded state
  const pendingPings = pings.filter(p => !p.is_read && !p.responded_at)
  const acknowledgedPings = pings.filter(p => p.is_read && !p.responded_at)
  const resolvedPings = pings.filter(p => p.responded_at)

  const formatTime = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffMs = now.getTime() - date.getTime()
    const diffMins = Math.floor(diffMs / 60000)
    const diffHours = Math.floor(diffMins / 60)

    if (diffMins < 1) return "Just now"
    if (diffMins < 60) return `${diffMins}m ago`
    if (diffHours < 24) return `${diffHours}h ago`
    return date.toLocaleDateString()
  }

  return (
    <div className="space-y-4">
      {/* Push notification settings */}
      <Card>
        <CardContent className="flex items-center justify-between py-4">
          <div className="flex items-center gap-3">
            <Smartphone className="h-5 w-5 text-muted-foreground" />
            <div>
              <Label className="font-medium">Push Notifications</Label>
              <p className="text-xs text-muted-foreground">
                {!isSupported
                  ? "Not supported on this device"
                  : permission === "denied"
                    ? "Notifications blocked in browser settings"
                    : isSubscribed
                      ? "You will receive alerts when your child sends a message"
                      : "Enable to receive alerts on this device"}
              </p>
            </div>
          </div>
          <Switch
            checked={isSubscribed}
            onCheckedChange={handlePushToggle}
            disabled={!isSupported || permission === "denied" || pushLoading}
          />
        </CardContent>
      </Card>

      {/* Pending pings */}
      {pendingPings.length > 0 && (
        <Card className="border-amber-200 bg-amber-50 dark:bg-amber-950/20">
          <CardHeader className="py-3">
            <CardTitle className="text-base flex items-center gap-2 text-amber-700 dark:text-amber-400">
              <BellRing className="h-5 w-5 animate-pulse" />
              New Messages ({pendingPings.length})
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {pendingPings.map((ping) => (
              <div
                key={ping.id}
                className={`flex items-center justify-between p-3 rounded-lg border ${
                  ping.priority === "urgent" || ping.priority === "high"
                    ? "bg-red-100 border-red-300 dark:bg-red-950/30"
                    : "bg-white dark:bg-background"
                }`}
              >
                <div className="flex items-center gap-3">
                  {(ping.priority === "urgent" || ping.priority === "high") && (
                    <AlertTriangle className="h-5 w-5 text-red-600" />
                  )}
                  <div>
                    <div className="font-medium">{ping.message}</div>
                    <div className="text-xs text-muted-foreground flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {formatTime(ping.created_at)}
                    </div>
                  </div>
                </div>
                <Button size="sm" onClick={() => acknowledgePing(ping.id)}>
                  <Check className="h-4 w-4 mr-1" />
                  Got it
                </Button>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Acknowledged pings */}
      {acknowledgedPings.length > 0 && (
        <Card>
          <CardHeader className="py-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Bell className="h-5 w-5" />
              In Progress ({acknowledgedPings.length})
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {acknowledgedPings.map((ping) => (
              <div
                key={ping.id}
                className="flex items-center justify-between p-3 rounded-lg border bg-muted/30"
              >
                <div>
                  <div className="font-medium">{ping.message}</div>
                  <div className="text-xs text-muted-foreground">
                    Acknowledged {formatTime(ping.acknowledged_at || ping.created_at)}
                  </div>
                </div>
                <Button variant="outline" size="sm" onClick={() => resolvePing(ping.id)}>
                  <Check className="h-4 w-4 mr-1" />
                  Done
                </Button>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Recent resolved */}
      {resolvedPings.length > 0 && (
        <Card>
          <CardHeader className="py-3">
            <CardTitle className="text-base text-muted-foreground flex items-center gap-2">
              <BellOff className="h-5 w-5" />
              Recent History
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="max-h-[200px]">
              <div className="space-y-2">
                {resolvedPings.slice(0, 10).map((ping) => (
                  <div
                    key={ping.id}
                    className="flex items-center justify-between p-2 text-sm text-muted-foreground"
                  >
                    <span>{ping.message}</span>
                    <span className="text-xs">{formatTime(ping.created_at)}</span>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      )}

      {/* Empty state */}
      {loading ? (
        <div className="flex items-center justify-center p-8">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      ) : pings.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center p-8 text-center">
            <Bell className="h-12 w-12 text-muted-foreground/50 mb-4" />
            <h3 className="font-semibold mb-1">No Messages Yet</h3>
            <p className="text-sm text-muted-foreground">
              When your child sends a message from the app, it will appear here.
            </p>
          </CardContent>
        </Card>
      ) : null}
    </div>
  )
}
