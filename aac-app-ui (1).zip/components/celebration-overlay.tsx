"use client"

import { useEffect, useState, useRef } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Star, Sparkles, Rocket, Volume2, VolumeX } from "lucide-react"

interface CelebrationOverlayProps {
  pointsEarned: number
  childName: string
  requestType?: "pee" | "poop"
}

// Dancing Dog SVG Component
function DancingDog({ className }: { className?: string }) {
  return (
    <svg 
      viewBox="0 0 100 100" 
      className={className}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* Body */}
      <ellipse cx="50" cy="55" rx="25" ry="20" fill="#8B4513" className="animate-wiggle" />
      {/* Head */}
      <circle cx="50" cy="30" r="18" fill="#A0522D" className="animate-nod" />
      {/* Ears */}
      <ellipse cx="35" cy="20" rx="8" ry="12" fill="#6B3811" transform="rotate(-20 35 20)" className="animate-ear-flap" />
      <ellipse cx="65" cy="20" rx="8" ry="12" fill="#6B3811" transform="rotate(20 65 20)" className="animate-ear-flap-reverse" />
      {/* Eyes */}
      <circle cx="43" cy="28" r="4" fill="white" />
      <circle cx="57" cy="28" r="4" fill="white" />
      <circle cx="44" cy="29" r="2" fill="#222" />
      <circle cx="58" cy="29" r="2" fill="#222" />
      {/* Nose */}
      <ellipse cx="50" cy="36" rx="5" ry="3" fill="#222" />
      {/* Tongue */}
      <ellipse cx="50" cy="42" rx="4" ry="6" fill="#FF6B6B" className="animate-tongue" />
      {/* Tail */}
      <path 
        d="M 75 50 Q 90 40 85 55 Q 95 45 90 60" 
        stroke="#8B4513" 
        strokeWidth="4" 
        strokeLinecap="round"
        fill="none"
        className="animate-wag"
      />
      {/* Front legs */}
      <rect x="38" y="68" width="6" height="18" rx="3" fill="#A0522D" className="animate-leg-left" />
      <rect x="56" y="68" width="6" height="18" rx="3" fill="#A0522D" className="animate-leg-right" />
      {/* Back legs - slightly visible */}
      <rect x="32" y="70" width="5" height="14" rx="2" fill="#8B4513" className="animate-leg-back-left" />
      <rect x="63" y="70" width="5" height="14" rx="2" fill="#8B4513" className="animate-leg-back-right" />
      {/* Collar */}
      <rect x="38" y="45" width="24" height="4" rx="2" fill="#FF4500" />
      {/* Tag */}
      <circle cx="50" cy="51" r="3" fill="#FFD700" />
    </svg>
  )
}

export function CelebrationOverlay({ pointsEarned, childName, requestType = "pee" }: CelebrationOverlayProps) {
  const router = useRouter()
  const audioRef = useRef<HTMLAudioElement | null>(null)
  const [musicPlaying, setMusicPlaying] = useState(true)
  const [confetti, setConfetti] = useState<
    Array<{ id: number; x: number; delay: number; color: string; size: number }>
  >([])
  const [celebrationMessage, setCelebrationMessage] = useState(`Amazing job ${childName}!`)
  const [showContent, setShowContent] = useState(false)

  useEffect(() => {
    // Generate more colorful confetti - Futuristic cyan theme
    const colors = [
      "#22d3ee", // cyan-400
      "#06b6d4", // cyan-500
      "#a78bfa", // violet-400
      "#fbbf24", // amber-400
      "#f472b6", // pink-400
      "#fff",
    ]
    const newConfetti = Array.from({ length: 60 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      delay: Math.random() * 2,
      color: colors[Math.floor(Math.random() * colors.length)],
      size: Math.random() * 12 + 6,
    }))
    setConfetti(newConfetti)

    // Animate content in
    setTimeout(() => setShowContent(true), 200)
    
    // Play celebration music using Web Audio API for a simple jingle
    if (typeof window === "undefined" || !musicPlaying) return
    
    let audioContext: AudioContext | null = null
    
    try {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext
      if (!AudioContextClass) return
      
      audioContext = new AudioContextClass()
      
      // Play a happy celebration melody
      const playNote = (freq: number, startTime: number, duration: number) => {
        if (!audioContext) return
        try {
          const oscillator = audioContext.createOscillator()
          const gainNode = audioContext.createGain()
          
          oscillator.connect(gainNode)
          gainNode.connect(audioContext.destination)
          
          oscillator.frequency.value = freq
          oscillator.type = "sine"
          
          gainNode.gain.setValueAtTime(0.3, audioContext.currentTime + startTime)
          gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + startTime + duration)
          
          oscillator.start(audioContext.currentTime + startTime)
          oscillator.stop(audioContext.currentTime + startTime + duration)
        } catch {
          // Ignore individual note errors
        }
      }
      
      // Happy victory melody (C major scale ascending with rhythm)
      const melody = [
        { note: 523.25, time: 0, dur: 0.15 },     // C5
        { note: 659.25, time: 0.15, dur: 0.15 },  // E5
        { note: 783.99, time: 0.3, dur: 0.15 },   // G5
        { note: 1046.50, time: 0.45, dur: 0.3 },  // C6 (longer)
        { note: 783.99, time: 0.8, dur: 0.15 },   // G5
        { note: 1046.50, time: 0.95, dur: 0.5 },  // C6 (final, longest)
      ]
      
      melody.forEach(({ note, time, dur }) => {
        playNote(note, time, dur)
      })
      
      // Close audio context after melody finishes
      setTimeout(() => {
        if (audioContext && audioContext.state !== "closed") {
          audioContext.close().catch(() => {})
        }
      }, 2000)
    } catch {
      // Audio not supported - close context if it was created
      if (audioContext && audioContext.state !== "closed") {
        audioContext.close().catch(() => {})
      }
    }

    const fetchCelebrationMessage = async () => {
      // Helper to find best quality voice - prioritizes Natural/Premium/Enhanced voices
      const findBestVoice = (patterns: string[], langPrefix: string) => {
        const voices = speechSynthesis.getVoices()
        const langVoices = voices.filter(v => v.lang.startsWith(langPrefix))
        
        // First priority: Natural/Neural/Premium/Enhanced voices (highest quality)
        for (const pattern of ["Natural", "Neural", "Premium", "Enhanced", "Online"]) {
          const voice = langVoices.find(v => v.name.includes(pattern))
          if (voice) return voice
        }
        
        // Second priority: Specific high-quality voice names
        for (const pattern of patterns) {
          const voice = langVoices.find(v => v.name.includes(pattern))
          if (voice) return voice
        }
        
        // Fallback to any English voice
        return langVoices[0] || voices.find(v => v.lang.startsWith("en")) || voices[0]
      }

      const speakMessage = (text: string) => {
        if ("speechSynthesis" in window) {
          speechSynthesis.cancel()
          const utterance = new SpeechSynthesisUtterance(text)
          utterance.volume = 1.0
          utterance.rate = 0.95
          utterance.pitch = 1.0
          
          // Use high-quality female voice for celebrations
          const voice = findBestVoice(
            ["Samantha", "Siri Female", "Ava", "Allison", "Karen", "Moira", "Zira", "Jenny", "Aria"],
            "en-US"
          )
          if (voice) {
            utterance.voice = voice
          }
          
          speechSynthesis.speak(utterance)
        }
      }

      try {
        const response = await fetch("/api/celebration-message", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ childName, requestType, pointsEarned }),
        })
        const data = await response.json()
        if (data.message) {
          setCelebrationMessage(data.message)
          speakMessage(data.message + ` You earned ${pointsEarned} stars!`)
        }
      } catch {
        speakMessage(`Amazing job ${childName}! You earned ${pointsEarned} stars!`)
      }
    }

    fetchCelebrationMessage()
  }, [childName, pointsEarned, requestType])

  const dismiss = () => {
    router.refresh()
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900 overflow-hidden">
      {/* Radial glow background - Cyan */}
      <div
        className="absolute inset-0"
        style={{
          background: "radial-gradient(circle at 50% 40%, rgba(34, 211, 238, 0.3), transparent 60%)",
        }}
      />

      {/* Confetti */}
      {confetti.map((piece) => (
        <div
          key={piece.id}
          className="pointer-events-none absolute rounded-full"
          style={{
            left: `${piece.x}%`,
            width: `${piece.size}px`,
            height: `${piece.size}px`,
            backgroundColor: piece.color,
            animation: `confetti-fall 3s ease-out ${piece.delay}s forwards`,
          }}
        />
      ))}

      {/* Floating rockets - Cyan themed */}
      <Rocket className="absolute top-20 left-10 h-12 w-12 text-cyan-400 animate-rocket-hover opacity-60" />
      <Rocket
        className="absolute top-32 right-16 h-10 w-10 text-pink-400 animate-rocket-hover opacity-60"
        style={{ animationDelay: "0.5s", transform: "scaleX(-1)" }}
      />

      {/* Content */}
      <div
        className={`relative z-10 flex flex-col items-center gap-6 p-8 text-center transition-all duration-500 ${
          showContent ? "opacity-100 scale-100" : "opacity-0 scale-90"
        }`}
      >
        {/* Dancing Dog Character */}
        <div className="relative mb-4">
          <DancingDog className="h-32 w-32" />
        </div>

        {/* Big animated star - Cyan themed */}
        <div className="relative animate-bounce">
          <div
            className="flex h-28 w-28 items-center justify-center rounded-full bg-gradient-to-br from-cyan-500 to-cyan-400"
            style={{
              boxShadow: "0 0 60px rgba(34, 211, 238, 0.6)",
            }}
          >
            <Star className="h-16 w-16 fill-slate-900 text-slate-900" />
          </div>
          <Sparkles className="absolute -right-4 -top-4 h-10 w-10 text-cyan-400 animate-pulse" />
          <Sparkles
            className="absolute -bottom-2 -left-4 h-8 w-8 text-amber-400 animate-pulse"
            style={{ animationDelay: "0.3s" }}
          />
          <Sparkles
            className="absolute top-4 -right-6 h-6 w-6 text-pink-400 animate-pulse"
            style={{ animationDelay: "0.6s" }}
          />
        </div>

        {/* Big celebration text */}
        <div className="space-y-3">
          <h1 className="text-5xl font-extrabold text-cyan-400 text-glow-cyan tracking-wide">AMAZING!</h1>
          <p className="text-2xl text-slate-100 font-medium max-w-xs leading-relaxed">{celebrationMessage}</p>
        </div>

        {/* Points earned - big and clear */}
        <div
          className="flex items-center gap-4 rounded-3xl bg-gradient-to-r from-cyan-500 to-cyan-400 px-10 py-5"
          style={{
            boxShadow: "0 8px 32px rgba(34, 211, 238, 0.5)",
          }}
        >
          <Star className="h-12 w-12 fill-slate-900 text-slate-900" />
          <span className="text-5xl font-extrabold text-slate-900">+{pointsEarned}</span>
        </div>

        <Button
          onClick={dismiss}
          className="h-16 w-full max-w-xs text-xl font-bold bg-gradient-to-r from-cyan-500 to-cyan-400 text-slate-900 hover:from-cyan-400 hover:to-cyan-300 mt-4 shadow-xl shadow-cyan-500/30"
        >
          AWESOME!
        </Button>
      </div>

      <style jsx>{`
        @keyframes confetti-fall {
          0% {
            transform: translateY(-100vh) rotate(0deg);
            opacity: 1;
          }
          100% {
            transform: translateY(100vh) rotate(720deg);
            opacity: 0;
          }
        }
      `}</style>
      
      <style jsx global>{`
        @keyframes wiggle {
          0%, 100% { transform: translateY(0) rotate(-2deg); }
          25% { transform: translateY(-3px) rotate(2deg); }
          50% { transform: translateY(0) rotate(-2deg); }
          75% { transform: translateY(-3px) rotate(2deg); }
        }
        @keyframes nod {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-5px); }
        }
        @keyframes ear-flap {
          0%, 100% { transform: rotate(-20deg); }
          50% { transform: rotate(-35deg); }
        }
        @keyframes ear-flap-reverse {
          0%, 100% { transform: rotate(20deg); }
          50% { transform: rotate(35deg); }
        }
        @keyframes tongue {
          0%, 100% { transform: scaleY(1); }
          50% { transform: scaleY(1.2); }
        }
        @keyframes wag {
          0%, 100% { transform: rotate(-10deg); }
          50% { transform: rotate(20deg); }
        }
        @keyframes leg-left {
          0%, 100% { transform: translateY(0) rotate(5deg); }
          50% { transform: translateY(-3px) rotate(-5deg); }
        }
        @keyframes leg-right {
          0%, 100% { transform: translateY(-3px) rotate(-5deg); }
          50% { transform: translateY(0) rotate(5deg); }
        }
        @keyframes leg-back-left {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-2px); }
        }
        @keyframes leg-back-right {
          0%, 100% { transform: translateY(-2px); }
          50% { transform: translateY(0); }
        }
        .animate-wiggle { animation: wiggle 0.4s ease-in-out infinite; }
        .animate-nod { animation: nod 0.5s ease-in-out infinite; }
        .animate-ear-flap { animation: ear-flap 0.3s ease-in-out infinite; }
        .animate-ear-flap-reverse { animation: ear-flap-reverse 0.3s ease-in-out infinite; }
        .animate-tongue { animation: tongue 0.4s ease-in-out infinite; }
        .animate-wag { animation: wag 0.2s ease-in-out infinite; transform-origin: left center; }
        .animate-leg-left { animation: leg-left 0.3s ease-in-out infinite; transform-origin: top center; }
        .animate-leg-right { animation: leg-right 0.3s ease-in-out infinite; transform-origin: top center; }
        .animate-leg-back-left { animation: leg-back-left 0.3s ease-in-out infinite; }
        .animate-leg-back-right { animation: leg-back-right 0.3s ease-in-out infinite; }
      `}</style>
    </div>
  )
}
