"use client"

import React, { useState, useCallback, useEffect, useMemo, useRef } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { StarField } from "@/components/star-field"
import { PointsDisplay } from "@/components/points-display"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Home, Volume2, VolumeX, X, RefreshCw, Check, ChevronLeft, ArrowLeft, Play, MessageCircle } from "lucide-react"
import type { CustomButton, VoiceCharacter, Caregiver } from "@/lib/types"
import { cn } from "@/lib/utils"

// Two main modes: Potty (home) and Talk (conversations)
type ChildMode = "potty" | "talk"

// Potty action types
type PottyAction = "pee" | "poop" | "accident" | "diaper"

interface ChildModeTabsProps {
  childName: string
  totalPoints: number
  avatarUrl?: string | null
  childId: string
  userId: string
  caregiverId: string
  hasPendingRequest: boolean
  pendingRequestType?: "pee" | "poop" | "custom"
  pendingRequestId?: string
  pendingRequestCreatedAt?: string
  pendingCustomButtonId?: string
  customButtons: CustomButton[]
  voicePreference?: VoiceCharacter
  caregivers?: Caregiver[]
}

const REQUEST_TIMEOUT_MS = 60000

// Potty training buttons - space-themed colors, large, clear, child-friendly
const POTTY_ACTIONS: { 
  type: PottyAction
  label: string
  icon: string
  gradient: string
  shadowColor: string
  borderColor: string
  tts: string
  confirmTts: string // What to say when confirmed
}[] = [
  { 
    type: "pee", 
    label: "Pee", 
    icon: "/images/potty-pee.jpg",
    gradient: "linear-gradient(135deg, #22d3ee 0%, #0891b2 100%)", // Cyan - space cyan
    shadowColor: "rgba(34, 211, 238, 0.5)",
    borderColor: "#22d3ee",
    tts: "I need to go pee!",
    confirmTts: "Great job telling us! Someone will help you to the potty now."
  },
  { 
    type: "poop", 
    label: "Poop", 
    icon: "/images/potty-poop.jpg",
    gradient: "linear-gradient(135deg, #a78bfa 0%, #7c3aed 100%)", // Purple - space purple
    shadowColor: "rgba(167, 139, 250, 0.5)",
    borderColor: "#a78bfa",
    tts: "I need to go poop!",
    confirmTts: "Great job telling us! Someone will help you to the potty now."
  },
  { 
    type: "accident", 
    label: "Accident", 
    icon: "/images/potty-accident.jpg",
    gradient: "linear-gradient(135deg, #f472b6 0%, #db2777 100%)", // Pink - space pink
    shadowColor: "rgba(244, 114, 182, 0.5)",
    borderColor: "#f472b6",
    tts: "I had an accident.",
    confirmTts: "It is okay, accidents happen. Someone will come help you get cleaned up."
  },
  { 
    type: "diaper", 
    label: "Change Me", 
    icon: "/images/potty-diaper.jpg",
    gradient: "linear-gradient(135deg, #fbbf24 0%, #f59e0b 100%)", // Gold - star gold
    shadowColor: "rgba(251, 191, 36, 0.5)",
    borderColor: "#fbbf24",
    tts: "I need a diaper change.",
    confirmTts: "Good job asking! Someone will come change your diaper now."
  },
]

// Demo caregivers for when Supabase isn't connected
const DEMO_CAREGIVERS: Caregiver[] = [
  { id: "demo-1", profile_id: "demo", name: "Mom", email: null, phone: null, receive_notifications: true, push_subscription: null, user_id: null, is_admin: true, invite_id: null, created_at: "" },
  { id: "demo-2", profile_id: "demo", name: "Dad", email: null, phone: null, receive_notifications: true, push_subscription: null, user_id: null, is_admin: false, invite_id: null, created_at: "" },
]

// Conversation message type
interface ConversationMessage {
  id: string
  sender: "child" | "caregiver"
  text: string
  caregiverId?: string
  caregiverName?: string
  timestamp: Date
  isRead?: boolean
}

export function ChildModeTabs({
  childName,
  totalPoints,
  avatarUrl,
  childId,
  userId,
  caregiverId,
  hasPendingRequest,
  pendingRequestType,
  pendingRequestId: initialPendingRequestId,
  pendingRequestCreatedAt: initialPendingRequestCreatedAt,
  pendingCustomButtonId,
  customButtons,
  voicePreference = "female",
  caregivers: initialCaregivers = [],
}: ChildModeTabsProps) {
  const router = useRouter()
  const [currentMode, setCurrentMode] = useState<ChildMode>("potty")
  const [soundEnabled, setSoundEnabled] = useState(true)
  const [points, setPoints] = useState(totalPoints)
  
  // Potty request state
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [hasPending, setHasPending] = useState(hasPendingRequest)
  const [pendingType, setPendingType] = useState(pendingRequestType)
  const [pendingRequestId, setPendingRequestId] = useState(initialPendingRequestId)
  const [pendingCreatedAt, setPendingCreatedAt] = useState(initialPendingRequestCreatedAt)
  const [canResubmit, setCanResubmit] = useState(false)
  const [timeRemaining, setTimeRemaining] = useState<number | null>(null)
  
  // Potty flow state
  const [selectedPottyAction, setSelectedPottyAction] = useState<PottyAction | null>(null)
  const [pottySuccess, setPottySuccess] = useState(false)
  
  // Conversation state
  const [conversations, setConversations] = useState<Record<string, ConversationMessage[]>>({})
  const [activeConversation, setActiveConversation] = useState<string | null>(null)
  const [aiSuggestions, setAiSuggestions] = useState<{ text: string; emoji: string }[]>([])
  const [isLoadingSuggestions, setIsLoadingSuggestions] = useState(false)
  
  // Message cooldown state (3 minutes = 180000ms)
  const MESSAGE_COOLDOWN_MS = 180000 // 3 minutes
  const [lastMessageTime, setLastMessageTime] = useState<Record<string, number>>({})
  const [messageCooldowns, setMessageCooldowns] = useState<Record<string, number>>({})
  
  // Update cooldown timers
  useEffect(() => {
    const interval = setInterval(() => {
      const now = Date.now()
      const updatedCooldowns: Record<string, number> = {}
      
      for (const [caregiverId, lastTime] of Object.entries(lastMessageTime)) {
        const remaining = MESSAGE_COOLDOWN_MS - (now - lastTime)
        if (remaining > 0) {
          updatedCooldowns[caregiverId] = Math.ceil(remaining / 1000)
        }
      }
      
      setMessageCooldowns(updatedCooldowns)
    }, 1000)
    
    return () => clearInterval(interval)
  }, [lastMessageTime])
  
  const isDemo = childId === "demo-child-id" || childId.startsWith("demo-")

  // Fetch caregivers if not provided
  useEffect(() => {
    if (isDemo) {
      setCaregivers(DEMO_CAREGIVERS)
      return
    }
    
    if (initialCaregivers && initialCaregivers.length > 0) return

    const fetchCaregivers = async () => {
      const supabase = createClient()
      const { data } = await supabase
        .from("caregivers")
        .select("*")
        .eq("profile_id", userId)
        .eq("receive_notifications", true)
        .order("is_admin", { ascending: false })
      
      if (data && data.length > 0) {
        setCaregivers(data)
      } else {
        setCaregivers([{ 
          id: caregiverId, 
          profile_id: userId, 
          name: "Caregiver", 
          email: null, 
          phone: null, 
          receive_notifications: true, 
          push_subscription: null, 
          user_id: userId, 
          is_admin: true, 
          invite_id: null, 
          created_at: "" 
        }])
      }
    }
    
    fetchCaregivers()
  }, [userId, caregiverId, initialCaregivers, isDemo])

  const [caregivers, setCaregivers] = useState<Caregiver[]>(initialCaregivers)

  // Check timeout for resubmission
  useEffect(() => {
    if (!hasPending || !pendingCreatedAt) {
      setCanResubmit(false)
      setTimeRemaining(null)
      return
    }

    const checkTimeout = () => {
      const createdTime = new Date(pendingCreatedAt).getTime()
      const elapsed = Date.now() - createdTime
      const remaining = REQUEST_TIMEOUT_MS - elapsed

      if (remaining <= 0) {
        setCanResubmit(true)
        setTimeRemaining(0)
      } else {
        setCanResubmit(false)
        setTimeRemaining(Math.ceil(remaining / 1000))
      }
    }

    checkTimeout()
    const interval = setInterval(checkTimeout, 1000)
    return () => clearInterval(interval)
  }, [hasPending, pendingCreatedAt])

  // Browser-based text-to-speech with modern, natural-sounding voices
  const speak = useCallback((text: string, onComplete?: () => void) => {
    if (!soundEnabled) {
      onComplete?.()
      return
    }
    if (!("speechSynthesis" in window)) {
      onComplete?.()
      return
    }
    
    speechSynthesis.cancel()
    const voices = speechSynthesis.getVoices()
    
    // Find the best natural-sounding voice
    const findNaturalVoice = (genderNames: string[], fallbackNames: string[]) => {
      const englishVoices = voices.filter(v => v.lang.startsWith("en"))
      
      // Priority 1: Google voices (highest quality)
      for (const name of genderNames) {
        const googleVoice = englishVoices.find(v => 
          v.name.toLowerCase().includes("google") && 
          v.name.toLowerCase().includes(name.toLowerCase())
        )
        if (googleVoice) return googleVoice
      }
      
      // Priority 2: Natural/Neural voices
      for (const name of genderNames) {
        const naturalVoice = englishVoices.find(v => 
          (v.name.includes("Natural") || v.name.includes("Neural")) &&
          v.name.toLowerCase().includes(name.toLowerCase())
        )
        if (naturalVoice) return naturalVoice
      }
      
      // Priority 3: Premium remote voices
      for (const name of genderNames) {
        const premiumVoice = englishVoices.find(v => 
          v.name.includes(name) && v.localService === false
        )
        if (premiumVoice) return premiumVoice
      }
      
      // Priority 4: Named voices
      for (const name of [...genderNames, ...fallbackNames]) {
        const voice = englishVoices.find(v => v.name.includes(name))
        if (voice) return voice
      }
      
      const usVoice = englishVoices.find(v => v.lang === "en-US")
      return usVoice || englishVoices[0] || voices[0]
    }
    
    let selectedVoice: SpeechSynthesisVoice | null = null
    const isMale = voicePreference === "male"
    
    if (isMale) {
      selectedVoice = findNaturalVoice(
        ["James", "Guy", "Aaron", "Christopher", "Liam", "Matthew", "Ryan", "Brian", "Andrew"],
        ["Daniel", "David", "Alex", "Tom", "Oliver", "William"]
      )
    } else {
      selectedVoice = findNaturalVoice(
        ["Samantha", "Ava", "Allison", "Zoe", "Emma", "Lily", "Olivia", "Charlotte"],
        ["Jenny", "Aria", "Susan", "Karen", "Victoria", "Kate"]
      )
    }
    
    // Handle long text with chunking
    const maxChunkLength = 200
    if (text.length > maxChunkLength) {
      const sentences = text.match(/[^.!?]+[.!?]+/g) || [text]
      let currentChunk = ""
      const chunks: string[] = []
      
      for (const sentence of sentences) {
        if ((currentChunk + sentence).length > maxChunkLength && currentChunk) {
          chunks.push(currentChunk.trim())
          currentChunk = sentence
        } else {
          currentChunk += sentence
        }
      }
      if (currentChunk.trim()) chunks.push(currentChunk.trim())
      
      let chunkIndex = 0
      const speakNextChunk = () => {
        if (chunkIndex < chunks.length) {
          const chunkUtterance = new SpeechSynthesisUtterance(chunks[chunkIndex])
          chunkUtterance.volume = 1.0
          chunkUtterance.pitch = isMale ? 0.95 : 1.0
          chunkUtterance.rate = 0.95
          if (selectedVoice) chunkUtterance.voice = selectedVoice
          chunkUtterance.onend = () => {
            chunkIndex++
            if (chunkIndex < chunks.length) {
              speakNextChunk()
            } else {
              onComplete?.()
            }
          }
          speechSynthesis.speak(chunkUtterance)
        } else {
          onComplete?.()
        }
      }
      speakNextChunk()
    } else {
      const utterance = new SpeechSynthesisUtterance(text)
      utterance.volume = 1.0
      utterance.pitch = isMale ? 0.95 : 1.0
      utterance.rate = 0.95
      if (selectedVoice) utterance.voice = selectedVoice
      utterance.onend = () => onComplete?.()
      speechSynthesis.speak(utterance)
    }
  }, [soundEnabled, voicePreference])

  // Load voices
  useEffect(() => {
    if ("speechSynthesis" in window) {
      const loadVoices = () => speechSynthesis.getVoices()
      loadVoices()
      if (speechSynthesis.onvoiceschanged !== undefined) {
        speechSynthesis.onvoiceschanged = loadVoices
      }
    }
  }, [])

  // Real-time subscriptions
  useEffect(() => {
    if (isDemo) return
    const supabase = createClient()
    const channel = supabase
      .channel(`request-updates-${childId}`)
      .on("postgres_changes", {
        event: "*",
        schema: "public",
        table: "bathroom_requests",
        filter: `child_id=eq.${childId}`,
      }, () => router.refresh())
      .subscribe()
    return () => { supabase.removeChannel(channel) }
  }, [childId, router, isDemo])

  useEffect(() => {
    if (isDemo) return
    const supabase = createClient()
    const channel = supabase
      .channel(`points-updates-${childId}`)
      .on("postgres_changes", {
        event: "UPDATE",
        schema: "public",
        table: "children",
        filter: `id=eq.${childId}`,
      }, (payload) => {
        if (payload.new && typeof payload.new === "object" && "total_points" in payload.new) {
          setPoints(payload.new.total_points as number)
        }
      })
      .subscribe()
    return () => { supabase.removeChannel(channel) }
  }, [childId, isDemo])

  // Handle potty button tap
  const handlePottyTap = (action: PottyAction) => {
    if (hasPending || isSubmitting) return
    
    const actionInfo = POTTY_ACTIONS.find(a => a.type === action)
    if (!actionInfo) return
    
    // Speak the appropriate confirmation message based on action type
    speak(`${childName}, ${actionInfo.confirmTts}`)
    
    setSelectedPottyAction(action)
  }

  // Confirm potty selection - sends to ALL caregivers
  const handleConfirmPotty = async () => {
    if (!selectedPottyAction || isSubmitting) return
    
    const actionInfo = POTTY_ACTIONS.find(a => a.type === selectedPottyAction)
    if (!actionInfo) return
    
    setIsSubmitting(true)
    
    // Speak confirmation
    speak("Help is on the way!")

    if (isDemo) {
      setTimeout(() => {
        setPottySuccess(true)
        setHasPending(true)
        setPendingType(selectedPottyAction === "pee" || selectedPottyAction === "poop" ? selectedPottyAction : "custom")
        setPendingRequestId("demo-request-" + Date.now())
        setPendingCreatedAt(new Date().toISOString())
        setIsSubmitting(false)
        
        setTimeout(() => {
          setSelectedPottyAction(null)
          setPottySuccess(false)
        }, 2500)
      }, 500)
      return
    }

    const supabase = createClient()

    try {
      const requestType = selectedPottyAction === "pee" || selectedPottyAction === "poop" ? selectedPottyAction : "custom"
      
      const { data, error } = await supabase.from("bathroom_requests").insert({
        child_id: childId,
        profile_id: userId,
        request_type: requestType,
        status: "pending",
      }).select().single()

      if (error) throw error

      // Send push notifications to ALL caregivers
      for (const caregiver of caregivers) {
        if (caregiver.push_subscription) {
          try {
            await fetch("/api/send-ping-notification", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                subscription: caregiver.push_subscription,
                title: `${childName} needs to go potty!`,
                body: actionInfo.tts,
                data: { childId, requestId: data.id }
              })
            })
          } catch (e) {
            console.error("Failed to send push notification:", e)
          }
        }
      }

      setPottySuccess(true)
      setHasPending(true)
      setPendingType(requestType)
      setPendingRequestId(data.id)
      setPendingCreatedAt(data.created_at)

      setTimeout(() => {
        setSelectedPottyAction(null)
        setPottySuccess(false)
      }, 2500)

    } catch (error) {
      console.error("Failed to send potty request:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleCancelRequest = async () => {
    if (!pendingRequestId || isSubmitting) return
    setIsSubmitting(true)

    if (isDemo) {
      setTimeout(() => {
        setHasPending(false)
        setPendingType(undefined)
        setPendingRequestId(undefined)
        setPendingCreatedAt(undefined)
        setCanResubmit(false)
        setIsSubmitting(false)
      }, 200)
      return
    }

    const supabase = createClient()

    try {
      await supabase
        .from("bathroom_requests")
        .update({ status: "cancelled", completed_at: new Date().toISOString() })
        .eq("id", pendingRequestId)

      setHasPending(false)
      setPendingType(undefined)
      setPendingRequestId(undefined)
      setPendingCreatedAt(undefined)
      setCanResubmit(false)
    } catch (error) {
      console.error("Failed to cancel request:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  // Generate AI response suggestions based on received message
  const generateAiSuggestions = async (receivedMessage: string) => {
    setIsLoadingSuggestions(true)
    
    // For now, use smart defaults based on common message patterns
    // In production, this would call an AI endpoint
    const suggestions: { text: string; emoji: string }[] = []
    
    const lowerMsg = receivedMessage.toLowerCase()
    
    if (lowerMsg.includes("love") || lowerMsg.includes("miss")) {
      suggestions.push({ text: "I love you too!", emoji: "❤️" })
      suggestions.push({ text: "I miss you too!", emoji: "💕" })
      suggestions.push({ text: "Come home soon!", emoji: "🏠" })
    } else if (lowerMsg.includes("how are you") || lowerMsg.includes("how's")) {
      suggestions.push({ text: "I am good!", emoji: "😊" })
      suggestions.push({ text: "I am happy!", emoji: "🎉" })
      suggestions.push({ text: "I am tired", emoji: "😴" })
    } else if (lowerMsg.includes("?")) {
      suggestions.push({ text: "Yes!", emoji: "👍" })
      suggestions.push({ text: "No", emoji: "👎" })
      suggestions.push({ text: "Maybe", emoji: "🤔" })
    } else if (lowerMsg.includes("good") || lowerMsg.includes("great") || lowerMsg.includes("proud")) {
      suggestions.push({ text: "Thank you!", emoji: "🙏" })
      suggestions.push({ text: "Yay!", emoji: "🎉" })
      suggestions.push({ text: "I am happy!", emoji: "😊" })
    } else {
      // Default suggestions
      suggestions.push({ text: "Okay!", emoji: "👍" })
      suggestions.push({ text: "I love you!", emoji: "❤️" })
      suggestions.push({ text: "See you soon!", emoji: "👋" })
    }
    
    setAiSuggestions(suggestions)
    setIsLoadingSuggestions(false)
  }

  // Check if can send follow-up message (3 minute cooldown passed or first message)
  const canSendFollowUp = (caregiverId: string): boolean => {
    const lastTime = lastMessageTime[caregiverId]
    if (!lastTime) return true // First message, no cooldown
    return Date.now() - lastTime >= MESSAGE_COOLDOWN_MS
  }
  
  // Get cooldown remaining in seconds
  const getCooldownRemaining = (caregiverId: string): number => {
    return messageCooldowns[caregiverId] || 0
  }

  // Send a conversation message
  const sendConversationMessage = async (caregiver: Caregiver, text: string, isFollowUp: boolean = false) => {
    const newMessage: ConversationMessage = {
      id: `msg-${Date.now()}`,
      sender: "child",
      text,
      caregiverId: caregiver.id,
      caregiverName: caregiver.name,
      timestamp: new Date(),
    }
    
    // Add to conversations
    setConversations(prev => ({
      ...prev,
      [caregiver.id]: [...(prev[caregiver.id] || []), newMessage]
    }))
    
    // Track last message time for cooldown
    setLastMessageTime(prev => ({
      ...prev,
      [caregiver.id]: Date.now()
    }))
    
    // Speak confirmation
    speak(isFollowUp ? `Follow-up sent to ${caregiver.name}!` : `Sent to ${caregiver.name}!`)
    
    // Send notification to caregiver
    if (caregiver.push_subscription && !isDemo) {
      try {
        await fetch("/api/send-ping-notification", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            subscription: caregiver.push_subscription,
            title: `Message from ${childName}`,
            body: text,
            data: { childId, type: "conversation" }
          })
        })
      } catch (e) {
        console.error("Failed to send notification:", e)
      }
    }
    
    // Clear selection
    setActiveConversation(null)
  }

  // Simulate receiving a message (for demo)
  const simulateReply = (caregiverId: string, text: string) => {
    const caregiver = caregivers.find(c => c.id === caregiverId)
    const newMessage: ConversationMessage = {
      id: `msg-${Date.now()}`,
      sender: "caregiver",
      text,
      caregiverId,
      caregiverName: caregiver?.name || "Caregiver",
      timestamp: new Date(),
      isRead: false,
    }
    
    setConversations(prev => ({
      ...prev,
      [caregiverId]: [...(prev[caregiverId] || []), newMessage]
    }))
    
    // Auto-read new message
    speak(`${caregiver?.name || "Caregiver"} says: ${text}`)
    
    // Generate AI suggestions
    generateAiSuggestions(text)
  }

  const getInitials = (name: string) => {
    return name.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2)
  }

  // ===== POTTY TAB (HOME) =====
  const PottyTab = () => (
    <div className="relative z-10 flex flex-col h-full">
      {/* Header - Futuristic glassmorphism */}
      <header className="shrink-0 flex items-center justify-between px-4 py-3 glass border-b border-slate-700/50">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => router.push("/mode-select")}
          className="h-12 w-12 rounded-xl bg-slate-800/50 hover:bg-cyan-500/20 text-slate-200 hover:text-cyan-400 border border-slate-700/50 transition-all"
        >
          <Home className="h-6 w-6" />
        </Button>

        <button
          onClick={() => router.push(`/child/rewards?childId=${childId}`)}
          className="transition-transform hover:scale-105 active:scale-95"
        >
          <PointsDisplay points={points} size="lg" />
        </button>

        <Button
          variant="ghost"
          size="icon"
          onClick={() => setSoundEnabled(!soundEnabled)}
          className="h-12 w-12 rounded-xl bg-slate-800/50 hover:bg-cyan-500/20 text-slate-200 hover:text-cyan-400 border border-slate-700/50 transition-all"
        >
          {soundEnabled ? <Volume2 className="h-6 w-6" /> : <VolumeX className="h-6 w-6" />}
        </Button>
      </header>

      {/* Main Content */}
      <div className="flex-1 overflow-auto px-4 py-4 flex flex-col">
        {/* Avatar and Greeting */}
        <div className="text-center mb-4">
          {/* Child Profile Picture - Glowing cyan border */}
          {avatarUrl && (
            <div className="flex justify-center mb-3">
              <div className="h-20 w-20 rounded-full overflow-hidden border-4 border-cyan-400 shadow-lg shadow-cyan-500/40 animate-glow">
                <img 
                  src={avatarUrl || "/placeholder.svg"} 
                  alt={childName}
                  className="h-full w-full object-cover"
                />
              </div>
            </div>
          )}
          
          {/* Greeting / Status */}
          {hasPending ? (
            <>
              <h1 className="text-3xl font-bold text-slate-100 text-glow-cyan mb-2">Help is Coming!</h1>
              {timeRemaining !== null && timeRemaining > 0 && (
                <p className="text-lg text-slate-400">Someone will be there soon...</p>
              )}
            </>
          ) : (
            <>
              <h1 className="text-3xl font-bold text-slate-100 text-glow-cyan mb-2">Hi {childName}!</h1>
              <p className="text-lg text-slate-400">Do you need to go potty?</p>
            </>
          )}
        </div>
        


        {/* Pending Request Banner - Futuristic glassmorphism */}
        {hasPending && (
          <div className="mb-6 rounded-3xl glass-card border-2 border-cyan-500/30 p-6 glow-cyan">
            <div className="text-center mb-4">
              <div className="inline-block animate-bounce">
                <div className="w-20 h-20 rounded-full bg-slate-800/50 flex items-center justify-center overflow-hidden border-2 border-cyan-400/50">
                  <img 
                    src={POTTY_ACTIONS.find(a => a.type === pendingType)?.icon || "/images/potty-pee.jpg"} 
                    alt="Pending request"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
              <p className="text-xl font-bold text-cyan-400 text-glow-cyan mt-2">
                {POTTY_ACTIONS.find(a => a.type === pendingType)?.label || "Help"} - Someone is coming!
              </p>
            </div>
            <div className="flex gap-3">
              <button
                onClick={handleCancelRequest}
                disabled={isSubmitting}
                className="flex-1 flex items-center justify-center gap-2 h-16 rounded-2xl bg-slate-800/50 border border-slate-600/50 text-slate-200 font-bold text-lg transition-all active:scale-95 hover:border-slate-500"
              >
                <X className="h-6 w-6" /> Never mind
              </button>
              {canResubmit && (
                <button
                  onClick={() => {
                    speak("Sending again. Help is on the way!")
                  }}
                  disabled={isSubmitting}
                  className="flex-1 flex items-center justify-center gap-2 h-16 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-400 text-slate-900 font-bold text-lg transition-all active:scale-95 shadow-lg shadow-amber-500/30"
                >
                  <RefreshCw className="h-6 w-6" /> Call Again
                </button>
              )}
            </div>
          </div>
        )}

        {/* Potty Action Buttons - Futuristic glassmorphism cards */}
        {!hasPending && (
          <div className="grid grid-cols-2 gap-4 flex-1">
            {POTTY_ACTIONS.map((action) => (
              <button
                key={action.type}
                onClick={() => handlePottyTap(action.type)}
                disabled={isSubmitting}
                className={cn(
                  "relative flex flex-col items-center justify-center rounded-3xl transition-all active:scale-95 overflow-hidden",
                  "min-h-[160px] border-2 glass-card hover:border-opacity-80",
                  isSubmitting && "opacity-50"
                )}
                style={{ 
                  borderColor: action.borderColor,
                  boxShadow: `0 12px 40px ${action.shadowColor}`
                }}
              >
                {/* Background gradient glow effect */}
                <div 
                  className="absolute inset-0 opacity-40"
                  style={{
                    background: `radial-gradient(circle at 50% 30%, ${action.borderColor} 0%, transparent 70%)`
                  }}
                />
                
                {/* Animated ring effect */}
                <div 
                  className="absolute inset-0 rounded-3xl animate-border-glow"
                  style={{ borderColor: action.borderColor }}
                />
                
                {/* Image container with glow */}
                <div 
                  className="relative z-10 w-20 h-20 rounded-full bg-slate-800/60 backdrop-blur-sm flex items-center justify-center mb-3 border-2 overflow-hidden"
                  style={{ 
                    borderColor: action.borderColor,
                    boxShadow: `0 0 20px ${action.shadowColor}`
                  }}
                >
                  <img 
                    src={action.icon || "/placeholder.svg"} 
                    alt={action.label}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement
                      target.style.display = 'none'
                    }}
                  />
                </div>
                
                {/* Label with glassmorphism */}
                <span 
                  className="relative z-10 text-xl font-bold px-4 py-1.5 rounded-full"
                  style={{
                    background: 'rgba(15, 23, 42, 0.6)',
                    backdropFilter: 'blur(8px)',
                    color: action.borderColor,
                    textShadow: `0 0 10px ${action.shadowColor}`
                  }}
                >
                  {action.label}
                </span>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Potty Confirmation Overlay - Futuristic */}
      {selectedPottyAction && (
        <div className="absolute inset-0 z-40 flex flex-col bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900">
          <StarField />
          
          {pottySuccess ? (
            // Success state - Glowing cyan
            <div className="relative z-10 flex-1 flex flex-col items-center justify-center px-6">
              <div className="w-40 h-40 rounded-full bg-gradient-to-br from-emerald-500 to-emerald-400 flex items-center justify-center mb-6 animate-bounce shadow-2xl shadow-emerald-500/50">
                <Check className="h-20 w-20 text-slate-900" />
              </div>
              <h2 className="text-4xl font-bold text-slate-100 text-glow-cyan mb-2">Great Job!</h2>
              <p className="text-2xl text-slate-400">Help is on the way!</p>
            </div>
          ) : (
            // Confirmation state
            <>
              <header className="relative z-10 flex items-center justify-between p-4 shrink-0">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setSelectedPottyAction(null)}
                  className="h-14 w-14 rounded-2xl bg-slate-800/50 border border-slate-700/50 backdrop-blur-sm text-slate-200 hover:text-cyan-400 hover:border-cyan-500/50 transition-all"
                >
                  <ChevronLeft className="h-8 w-8" />
                </Button>
                <div className="w-14" />
              </header>

              <div className="relative z-10 flex-1 flex flex-col items-center justify-center px-6">
                {/* Selected action display - space themed with image */}
                <div 
                  className="w-40 h-40 rounded-full flex items-center justify-center mb-6 border-4 animate-pulse-glow overflow-hidden"
                  style={{ 
                    background: POTTY_ACTIONS.find(a => a.type === selectedPottyAction)?.gradient,
                    borderColor: POTTY_ACTIONS.find(a => a.type === selectedPottyAction)?.borderColor,
                    boxShadow: `0 0 60px ${POTTY_ACTIONS.find(a => a.type === selectedPottyAction)?.shadowColor}`
                  }}
                >
                  <img 
                    src={POTTY_ACTIONS.find(a => a.type === selectedPottyAction)?.icon || "/placeholder.svg"} 
                    alt={POTTY_ACTIONS.find(a => a.type === selectedPottyAction)?.label}
                    className="w-full h-full object-cover"
                  />
                </div>
                
                <h2 className="text-3xl font-bold text-slate-100 text-glow-cyan text-center mb-2">
                  {childName}, great job telling us!
                </h2>
                <p className="text-xl text-slate-400 text-center mb-8">
                  Which do you need?
                </p>

                {/* Confirm button - Futuristic glowing */}
                <button
                  onClick={handleConfirmPotty}
                  disabled={isSubmitting}
                  className="w-full max-w-md py-6 rounded-3xl font-bold text-2xl transition-all active:scale-95 flex items-center justify-center gap-3 border-2 border-emerald-400/50 bg-gradient-to-r from-emerald-500 to-emerald-400 shadow-2xl shadow-emerald-500/40 hover:shadow-emerald-500/60"
                >
                  <Check className="h-8 w-8 text-slate-900" />
                  <span className="text-slate-900">Yes, I need to {POTTY_ACTIONS.find(a => a.type === selectedPottyAction)?.label.toLowerCase()}!</span>
                </button>
              </div>
              
              <div className="h-[env(safe-area-inset-bottom)]" />
            </>
          )}
        </div>
      )}
    </div>
  )

  // LAMP-style word categories with pictures for child communication
  const LAMP_CATEGORIES = [
    { id: "feelings", name: "How I Feel", emoji: "😊", color: "#f472b6", words: [
      { text: "I am happy", emoji: "😊", img: "https://images.unsplash.com/photo-1489710437720-ebb67ec84dd2?w=100&h=100&fit=crop" },
      { text: "I am sad", emoji: "😢", img: "https://images.unsplash.com/photo-1534951009808-766178b47a4f?w=100&h=100&fit=crop" },
      { text: "I am tired", emoji: "😴", img: "https://images.unsplash.com/photo-1515894203077-9cd36032142f?w=100&h=100&fit=crop" },
      { text: "I am scared", emoji: "😨", img: null },
      { text: "I am excited", emoji: "🤩", img: null },
      { text: "I am bored", emoji: "😑", img: null },
    ]},
    { id: "needs", name: "I Need", emoji: "🙋", color: "#22d3ee", words: [
      { text: "I need help", emoji: "🆘", img: "https://images.unsplash.com/photo-1582213782179-e0d53f98f2ca?w=100&h=100&fit=crop" },
      { text: "I need a hug", emoji: "🤗", img: "https://images.unsplash.com/photo-1516589178581-6cd7833ae3b2?w=100&h=100&fit=crop" },
      { text: "I need food", emoji: "🍎", img: "https://images.unsplash.com/photo-1568702846914-96b305d2uj33?w=100&h=100&fit=crop" },
      { text: "I need water", emoji: "💧", img: null },
      { text: "I need to rest", emoji: "🛏️", img: null },
      { text: "I need a snack", emoji: "🍪", img: null },
    ]},
    { id: "love", name: "Love", emoji: "❤️", color: "#a78bfa", words: [
      { text: "I love you", emoji: "❤️", img: "https://images.unsplash.com/photo-1518199266791-5375a83190b7?w=100&h=100&fit=crop" },
      { text: "I miss you", emoji: "💕", img: "https://images.unsplash.com/photo-1516410529446-2c777cb7366d?w=100&h=100&fit=crop" },
      { text: "Thank you", emoji: "🙏", img: "https://images.unsplash.com/photo-1489710437720-ebb67ec84dd2?w=100&h=100&fit=crop" },
      { text: "Good job!", emoji: "👍", img: null },
      { text: "You are the best!", emoji: "🏆", img: null },
      { text: "Hugs and kisses!", emoji: "😘", img: null },
    ]},
    { id: "questions", name: "Questions", emoji: "❓", color: "#fbbf24", words: [
      { text: "When are you coming home?", emoji: "🏠", img: "https://images.unsplash.com/photo-1518780664697-55e3ad937233?w=100&h=100&fit=crop" },
      { text: "What are you doing?", emoji: "🤔", img: null },
      { text: "Can we play?", emoji: "🎮", img: "https://images.unsplash.com/photo-1493711662062-fa541f7f3d24?w=100&h=100&fit=crop" },
      { text: "Where are you?", emoji: "📍", img: null },
      { text: "Can I have a treat?", emoji: "🍬", img: null },
      { text: "Are you okay?", emoji: "🤷", img: null },
    ]},
    { id: "greetings", name: "Greetings", emoji: "👋", color: "#10b981", words: [
      { text: "Good morning!", emoji: "☀️", img: "https://images.unsplash.com/photo-1470252649378-9c29740c9fa8?w=100&h=100&fit=crop" },
      { text: "Good night!", emoji: "🌙", img: "https://images.unsplash.com/photo-1507400492013-162706c8c05e?w=100&h=100&fit=crop" },
      { text: "Hello!", emoji: "👋", img: null },
      { text: "Bye bye!", emoji: "✌️", img: null },
      { text: "See you soon!", emoji: "👀", img: null },
      { text: "Sweet dreams!", emoji: "💤", img: null },
    ]},
  ]

  // Track selected category for LAMP grid
  const [selectedCategory, setSelectedCategory] = useState<typeof LAMP_CATEGORIES[0] | null>(null)
  const [pendingMessage, setPendingMessage] = useState<{ text: string; emoji: string } | null>(null)
  const [showConfirmation, setShowConfirmation] = useState(false)

  // Greeting spoken on Talk tab open
  const talkTabGreetingRef = useRef(false)
  useEffect(() => {
    if (currentMode === "talk" && !talkTabGreetingRef.current && !activeConversation) {
      talkTabGreetingRef.current = true
      speak(`Hi ${childName}, who do you want to send a message to?`)
    }
    if (currentMode !== "talk") {
      talkTabGreetingRef.current = false
    }
  }, [currentMode, activeConversation, childName])

  // Handle message selection - read aloud and show confirmation
  const handleSelectMessage = (text: string, emoji: string) => {
    setPendingMessage({ text, emoji })
    speak(text, () => {
      setShowConfirmation(true)
      speak("Do you want to send this message?")
    })
  }

  // Confirm and send the message
  const handleConfirmSend = () => {
    if (!pendingMessage || !activeConversation) return
    const caregiver = caregivers.find(c => c.id === activeConversation)
    if (caregiver) {
      sendConversationMessage(caregiver, pendingMessage.text)
      speak(`Message sent to ${caregiver.name}!`)
    }
    setPendingMessage(null)
    setShowConfirmation(false)
    setSelectedCategory(null)
  }

  // Cancel the pending message
  const handleCancelMessage = () => {
    setPendingMessage(null)
    setShowConfirmation(false)
    speak("Message cancelled. Pick another one!")
  }

  // ===== TALK TAB (CONVERSATIONS) =====
  const TalkTab = () => {
    // Message confirmation overlay
    if (showConfirmation && pendingMessage) {
      return (
        <div className="relative z-10 flex flex-col h-full">
          <StarField />
          <div className="flex-1 flex flex-col items-center justify-center px-6">
            <div className="text-center mb-8">
              <span className="text-8xl mb-4 block">{pendingMessage.emoji}</span>
              <p className="text-2xl font-bold text-white mb-2">"{pendingMessage.text}"</p>
              <button
                onClick={() => speak(pendingMessage.text)}
                className="flex items-center justify-center gap-2 mx-auto px-4 py-2 rounded-xl bg-white/10 text-white/70"
              >
                <Play className="h-5 w-5" /> Tap to hear again
              </button>
            </div>
            
            <p className="text-xl text-white/80 mb-6">Send this message?</p>
            
            <div className="flex gap-4 w-full max-w-md">
              <button
                onClick={handleCancelMessage}
                className="flex-1 py-5 rounded-2xl bg-white/20 text-white font-bold text-xl transition-all active:scale-95 flex items-center justify-center gap-2"
              >
                <X className="h-6 w-6" /> No
              </button>
              <button
                onClick={handleConfirmSend}
                className="flex-1 py-5 rounded-2xl font-bold text-xl transition-all active:scale-95 flex items-center justify-center gap-2"
                style={{
                  background: "linear-gradient(135deg, #22c55e 0%, #16a34a 100%)",
                  boxShadow: "0 8px 32px rgba(34, 197, 94, 0.4)"
                }}
              >
                <Check className="h-6 w-6 text-white" /> <span className="text-white">Yes!</span>
              </button>
            </div>
          </div>
        </div>
      )
    }

    // LAMP word grid for selected category
    if (selectedCategory && activeConversation) {
      const caregiver = caregivers.find(c => c.id === activeConversation)
      
      return (
        <div className="relative z-10 flex flex-col h-full">
          <header className="shrink-0 flex items-center justify-between px-4 py-3 bg-black/20 backdrop-blur-sm">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setSelectedCategory(null)}
              className="h-12 w-12 rounded-xl bg-white/10 text-white"
            >
              <ArrowLeft className="h-6 w-6" />
            </Button>
            <div className="flex items-center gap-2">
              <span className="text-2xl">{selectedCategory.emoji}</span>
              <h1 className="text-lg font-bold text-white">{selectedCategory.name}</h1>
            </div>
            <Avatar className="h-10 w-10 border-2" style={{ borderColor: selectedCategory.color }}>
              <AvatarFallback 
                className="text-white font-bold"
                style={{ background: selectedCategory.color }}
              >
                {getInitials(caregiver?.name || "?")}
              </AvatarFallback>
            </Avatar>
          </header>

          {/* LAMP-style word grid with pictures */}
          <div className="flex-1 overflow-auto px-3 py-4">
            <div className="grid grid-cols-2 gap-3">
              {selectedCategory.words.map((word, i) => (
                <button
                  key={i}
                  onClick={() => handleSelectMessage(word.text, word.emoji)}
                  className="flex flex-col items-center justify-center rounded-2xl p-4 min-h-[120px] border-3 backdrop-blur-sm transition-all active:scale-95"
                  style={{
                    background: `linear-gradient(135deg, ${selectedCategory.color}30 0%, ${selectedCategory.color}10 100%)`,
                    borderColor: selectedCategory.color,
                    boxShadow: `0 4px 16px ${selectedCategory.color}30`
                  }}
                >
                  <span className="text-5xl mb-2">{word.emoji}</span>
                  <span className="text-base font-medium text-white text-center leading-tight">{word.text}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )
    }

    // Active conversation - show LAMP category grid
    if (activeConversation) {
      const caregiver = caregivers.find(c => c.id === activeConversation)
      const messages = conversations[activeConversation] || []
      
      return (
        <div className="relative z-10 flex flex-col h-full">
          <header className="shrink-0 flex items-center justify-between px-4 py-3 bg-black/20 backdrop-blur-sm">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => {
                setActiveConversation(null)
                setAiSuggestions([])
              }}
              className="h-12 w-12 rounded-xl bg-white/10 text-white"
            >
              <ArrowLeft className="h-6 w-6" />
            </Button>
            <div className="flex items-center gap-3">
              <Avatar className="h-10 w-10 border-2 border-white/30">
                <AvatarFallback className="bg-indigo-600 text-white font-bold">
                  {getInitials(caregiver?.name || "?")}
                </AvatarFallback>
              </Avatar>
              <span className="text-lg font-bold text-white">Message {caregiver?.name}</span>
            </div>
            <div className="w-12" />
          </header>

          {/* Recent messages (if any) */}
          {messages.length > 0 && (
            <div className="shrink-0 px-4 py-3 max-h-32 overflow-auto border-b border-white/10">
              {messages.slice(-3).map((msg) => (
                <div
                  key={msg.id}
                  className={cn(
                    "text-sm rounded-xl px-3 py-2 mb-2",
                    msg.sender === "child" 
                      ? "ml-auto bg-[var(--space-cyan)]/30 text-white w-fit max-w-[80%]" 
                      : "mr-auto bg-white/20 text-white w-fit max-w-[80%]"
                  )}
                >
                  {msg.text}
                </div>
              ))}
            </div>
          )}

          {/* AI Suggested responses if caregiver replied */}
          {aiSuggestions.length > 0 && (
            <div className="shrink-0 px-4 py-3 bg-[var(--space-purple)]/20 border-b border-white/10">
              <p className="text-sm text-[var(--space-cyan)] mb-2 font-medium">Quick replies:</p>
              <div className="flex flex-wrap gap-2">
                {aiSuggestions.map((suggestion, i) => (
                  <button
                    key={i}
                    onClick={() => handleSelectMessage(suggestion.text, suggestion.emoji)}
                    className="flex items-center gap-2 px-3 py-2 rounded-xl border-2 border-[var(--space-cyan)]/50 bg-white/10 text-white transition-all active:scale-95"
                  >
                    <span className="text-xl">{suggestion.emoji}</span>
                    <span className="text-sm font-medium">{suggestion.text}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* LAMP Category Grid */}
          <div className="flex-1 overflow-auto px-3 py-4">
            <p className="text-center text-white/70 mb-4">What do you want to say?</p>
            <div className="grid grid-cols-2 gap-3">
              {LAMP_CATEGORIES.map((category) => (
                <button
                  key={category.id}
                  onClick={() => {
                    setSelectedCategory(category)
                    speak(category.name)
                  }}
                  className="flex flex-col items-center justify-center rounded-2xl p-5 min-h-[130px] border-3 backdrop-blur-sm transition-all active:scale-95"
                  style={{
                    background: `linear-gradient(135deg, ${category.color}40 0%, ${category.color}20 100%)`,
                    borderColor: category.color,
                    boxShadow: `0 6px 24px ${category.color}30`
                  }}
                >
                  <span className="text-5xl mb-2">{category.emoji}</span>
                  <span className="text-lg font-bold text-white">{category.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Demo: Simulate caregiver reply */}
          {isDemo && messages.length > 0 && messages[messages.length - 1].sender === "child" && (
            <div className="shrink-0 px-4 pb-4">
              <button
                onClick={() => simulateReply(activeConversation, "I love you too! I'll be home soon.")}
                className="w-full py-3 rounded-xl bg-white/10 text-white/70 text-sm"
              >
                [Demo] Simulate reply from {caregiver?.name}
              </button>
            </div>
          )}
        </div>
      )
    }

    // Main Talk tab - Caregiver selection (first screen)
    return (
      <div className="relative z-10 flex flex-col h-full">
        <header className="shrink-0 flex items-center justify-between px-4 py-3 bg-black/20 backdrop-blur-sm">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => router.push("/mode-select")}
            className="h-12 w-12 rounded-xl bg-white/10 text-white"
          >
            <Home className="h-6 w-6" />
          </Button>
          <h1 className="text-lg font-bold text-white">Send a Message</h1>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setSoundEnabled(!soundEnabled)}
            className="h-12 w-12 rounded-xl bg-white/10 text-white"
          >
            {soundEnabled ? <Volume2 className="h-6 w-6" /> : <VolumeX className="h-6 w-6" />}
          </Button>
        </header>

        {/* Child greeting */}
        <div className="shrink-0 px-4 py-6 text-center">
          {avatarUrl && (
            <div className="flex justify-center mb-3">
              <div className="h-16 w-16 rounded-full overflow-hidden border-4 border-[var(--space-pink)] shadow-lg shadow-[var(--space-pink)]/30">
                <img src={avatarUrl || "/placeholder.svg"} alt={childName} className="h-full w-full object-cover" />
              </div>
            </div>
          )}
          <h2 className="text-2xl font-bold text-white mb-2">Hi {childName}!</h2>
          <p className="text-lg text-white/70">Who do you want to send a message to?</p>
        </div>

        {/* Caregiver grid with pictures */}
        <div className="flex-1 overflow-auto px-4 pb-4">
          <div className="grid grid-cols-2 gap-4">
            {caregivers.map((caregiver, i) => {
              const colors = [
                { gradient: "linear-gradient(135deg, #22d3ee 0%, #0891b2 100%)", border: "#22d3ee", shadow: "rgba(34, 211, 238, 0.4)" },
                { gradient: "linear-gradient(135deg, #a78bfa 0%, #7c3aed 100%)", border: "#a78bfa", shadow: "rgba(167, 139, 250, 0.4)" },
                { gradient: "linear-gradient(135deg, #f472b6 0%, #db2777 100%)", border: "#f472b6", shadow: "rgba(244, 114, 182, 0.4)" },
                { gradient: "linear-gradient(135deg, #fbbf24 0%, #f59e0b 100%)", border: "#fbbf24", shadow: "rgba(251, 191, 36, 0.4)" },
              ]
              const color = colors[i % colors.length]
              const unreadCount = (conversations[caregiver.id] || []).filter(m => m.sender === "caregiver" && !m.isRead).length
              
              return (
                <button
                  key={caregiver.id}
                  onClick={() => {
                    speak(`Message ${caregiver.name}`)
                    setActiveConversation(caregiver.id)
                  }}
                  className="relative flex flex-col items-center justify-center rounded-3xl p-6 min-h-[160px] border-4 backdrop-blur-sm transition-all active:scale-95"
                  style={{
                    background: `linear-gradient(135deg, rgba(255,255,255,0.15) 0%, rgba(255,255,255,0.05) 100%)`,
                    borderColor: color.border,
                    boxShadow: `0 8px 32px ${color.shadow}`
                  }}
                >
                  {/* Unread badge */}
                  {unreadCount > 0 && (
                    <div className="absolute top-2 right-2 w-6 h-6 rounded-full bg-red-500 text-white text-xs font-bold flex items-center justify-center animate-pulse">
                      {unreadCount}
                    </div>
                  )}
                  
                  <Avatar className="h-20 w-20 mb-3 border-4" style={{ borderColor: color.border }}>
                    <AvatarImage src={undefined || "/placeholder.svg"} />
                    <AvatarFallback 
                      className="text-white text-2xl font-bold"
                      style={{ background: color.gradient }}
                    >
                      {getInitials(caregiver.name)}
                    </AvatarFallback>
                  </Avatar>
                  <span className="text-xl font-bold text-white">{caregiver.name}</span>
                  
                  {/* Last message preview */}
                  {conversations[caregiver.id]?.length > 0 && (
                    <span className="text-xs text-white/50 mt-1 truncate max-w-full">
                      {conversations[caregiver.id][conversations[caregiver.id].length - 1].text.slice(0, 20)}...
                    </span>
                  )}
                </button>
              )
            })}
          </div>

          {/* Recent conversations header */}
          {Object.keys(conversations).length > 0 && (
            <div className="mt-6 mb-3">
              <h3 className="text-white/60 text-sm">Recent Messages</h3>
            </div>
          )}
        </div>
      </div>
    )
  }

  

  // Bottom Navigation - Futuristic glassmorphism
  const BottomNavBar = () => (
    <nav className="shrink-0 border-t border-slate-700/50 bg-slate-900/90 backdrop-blur-lg">
      <div className="flex items-stretch justify-around">
        {/* Potty Tab (Home) */}
        <button
          onClick={() => {
            setCurrentMode("potty")
            setSelectedPottyAction(null)
          }}
          className={cn(
            "flex flex-1 flex-col items-center justify-center gap-1 py-5 transition-all",
            currentMode === "potty"
              ? "text-cyan-400"
              : "text-slate-400 active:bg-slate-800/50"
          )}
          style={currentMode === "potty" ? {
            background: "linear-gradient(to top, rgba(34, 211, 238, 0.15), transparent)",
          } : undefined}
        >
          <span className="text-3xl">🚽</span>
          <span className="text-base font-bold">Potty</span>
        </button>

        {/* Talk Tab */}
        <button
          onClick={() => setCurrentMode("talk")}
          className={cn(
            "flex flex-1 flex-col items-center justify-center gap-1 py-5 transition-all",
            currentMode === "talk"
              ? "text-pink-400"
              : "text-slate-400 active:bg-slate-800/50"
          )}
          style={currentMode === "talk" ? {
            background: "linear-gradient(to top, rgba(244, 114, 182, 0.15), transparent)",
          } : undefined}
        >
          <MessageCircle className="h-7 w-7" />
          <span className="text-base font-bold">Talk</span>
        </button>
      </div>
      <div className="h-[env(safe-area-inset-bottom)]" />
    </nav>
  )

  return (
    <main className="relative flex flex-col h-svh overflow-hidden bg-slate-900">
      <StarField />
      
      {/* Main Content Area */}
      <div className="relative z-10 flex-1 overflow-hidden min-h-0">
        {currentMode === "potty" && <PottyTab />}
        {currentMode === "talk" && <TalkTab />}
      </div>

      {/* Bottom Navigation */}
      {!selectedPottyAction && <BottomNavBar />}
    </main>
  )
}
