"use client"

export function SpaceAstronaut({ className = "" }: { className?: string }) {
  return (
    <div className={`relative w-full max-w-md aspect-[16/9] ${className}`}>
      <svg
        viewBox="0 0 400 200"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full"
      >
        {/* Background gradient */}
        <defs>
          <linearGradient id="bgGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#1e1b4b" />
            <stop offset="50%" stopColor="#312e81" />
            <stop offset="100%" stopColor="#1e3a5f" />
          </linearGradient>
          <radialGradient id="planetGlow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#a78bfa" stopOpacity="0.6" />
            <stop offset="100%" stopColor="#7c3aed" stopOpacity="0" />
          </radialGradient>
          <linearGradient id="ringGradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#f97316" stopOpacity="0.8" />
            <stop offset="50%" stopColor="#fb923c" stopOpacity="1" />
            <stop offset="100%" stopColor="#f97316" stopOpacity="0.8" />
          </linearGradient>
        </defs>

        {/* Background */}
        <rect width="400" height="200" rx="16" fill="url(#bgGradient)" />

        {/* Stars */}
        <circle cx="30" cy="30" r="1.5" fill="white" opacity="0.8" />
        <circle cx="80" cy="60" r="1" fill="white" opacity="0.6" />
        <circle cx="120" cy="25" r="1.5" fill="white" opacity="0.7" />
        <circle cx="350" cy="40" r="1.5" fill="white" opacity="0.8" />
        <circle cx="370" cy="80" r="1" fill="white" opacity="0.6" />
        <circle cx="320" cy="30" r="1.2" fill="white" opacity="0.7" />
        <circle cx="50" cy="150" r="1" fill="white" opacity="0.5" />
        <circle cx="100" cy="170" r="1.5" fill="white" opacity="0.6" />
        <circle cx="150" cy="180" r="1" fill="white" opacity="0.4" />
        <circle cx="200" cy="30" r="1" fill="white" opacity="0.6" />
        <circle cx="250" cy="50" r="1.2" fill="white" opacity="0.5" />

        {/* Orbit ring (back) */}
        <ellipse
          cx="300"
          cy="90"
          rx="60"
          ry="15"
          fill="none"
          stroke="url(#ringGradient)"
          strokeWidth="3"
          strokeDasharray="5 3"
          opacity="0.4"
        />

        {/* Planet (Saturn-like) */}
        <circle cx="300" cy="80" r="35" fill="#7c3aed" />
        <circle cx="300" cy="80" r="35" fill="url(#planetGlow)" />
        <ellipse cx="300" cy="80" rx="25" ry="8" fill="#1e1b4b" opacity="0.3" />

        {/* Orbit ring (front) */}
        <ellipse
          cx="300"
          cy="90"
          rx="60"
          ry="15"
          fill="none"
          stroke="url(#ringGradient)"
          strokeWidth="4"
          strokeDasharray="120 60"
          opacity="0.9"
        />

        {/* Astronaut body */}
        <g transform="translate(180, 50)">
          {/* Backpack */}
          <rect x="0" y="30" width="25" height="50" rx="5" fill="#e5e7eb" />
          <rect x="3" y="35" width="19" height="10" rx="2" fill="#9ca3af" />
          <rect x="3" y="50" width="19" height="10" rx="2" fill="#9ca3af" />

          {/* Body/Suit */}
          <ellipse cx="40" cy="75" rx="30" ry="40" fill="#f3f4f6" />
          <ellipse cx="40" cy="75" rx="26" ry="36" fill="#e5e7eb" />

          {/* Helmet */}
          <circle cx="40" cy="25" r="28" fill="#e5e7eb" />
          <circle cx="40" cy="25" r="22" fill="#312e81" />
          <circle cx="40" cy="25" r="20" fill="#1e1b4b" />
          {/* Helmet reflection */}
          <ellipse cx="32" cy="18" rx="8" ry="5" fill="#6366f1" opacity="0.4" />

          {/* Arms */}
          <ellipse cx="5" cy="60" rx="10" ry="15" fill="#f3f4f6" transform="rotate(-20 5 60)" />
          <ellipse cx="75" cy="55" rx="10" ry="18" fill="#f3f4f6" transform="rotate(15 75 55)" />
          {/* Gloves */}
          <circle cx="-2" cy="72" r="8" fill="#e5e7eb" />
          <circle cx="82" cy="45" r="8" fill="#e5e7eb" />

          {/* Legs */}
          <ellipse cx="28" cy="110" rx="12" ry="20" fill="#f3f4f6" />
          <ellipse cx="52" cy="110" rx="12" ry="20" fill="#f3f4f6" />
          {/* Boots */}
          <ellipse cx="26" cy="128" rx="10" ry="8" fill="#374151" />
          <ellipse cx="54" cy="128" rx="10" ry="8" fill="#374151" />

          {/* Suit details */}
          <rect x="32" y="55" width="16" height="8" rx="2" fill="#22d3ee" opacity="0.8" />
          <circle cx="30" cy="70" r="3" fill="#22d3ee" opacity="0.6" />
          <circle cx="50" cy="70" r="3" fill="#22d3ee" opacity="0.6" />
        </g>

        {/* Small floating elements */}
        <circle cx="140" cy="100" r="4" fill="#06b6d4" opacity="0.6" />
        <circle cx="160" cy="130" r="3" fill="#8b5cf6" opacity="0.5" />
        <circle cx="100" cy="80" r="2" fill="#f97316" opacity="0.6" />

        {/* Wave/curve at bottom */}
        <path
          d="M0 180 Q100 160 200 175 T400 165 L400 200 L0 200 Z"
          fill="#1e3a5f"
          opacity="0.5"
        />
      </svg>
    </div>
  )
}
