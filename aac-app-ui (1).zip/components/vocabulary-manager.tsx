"use client"

import { useState, useEffect } from "react"
import { createBrowserClient } from "@supabase/ssr"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  MessageCircle, Plus, Trash2, Edit2, Bell, BellOff, Star, Loader2,
  Droplet, Heart, Sparkles, FolderPlus
} from "lucide-react"
import type { VocabularyCategory, VocabularyWord } from "@/lib/types"
import { DEFAULT_VOCABULARY_CATEGORIES, DEFAULT_VOCABULARY_WORDS } from "@/lib/types"

interface VocabularyManagerProps {
  childId: string
  caregiverId: string
}

const CATEGORY_ICONS = [
  { value: "message-circle", label: "Message", icon: MessageCircle },
  { value: "droplet", label: "Droplet", icon: Droplet },
  { value: "star", label: "Star", icon: Star },
  { value: "heart", label: "Heart", icon: Heart },
  { value: "sparkles", label: "Sparkles", icon: Sparkles },
]

const COLORS = [
  "#6366f1", "#8b5cf6", "#d946ef", "#ec4899", "#f43f5e",
  "#f97316", "#eab308", "#22c55e", "#14b8a6", "#06b6d4",
]

export function VocabularyManager({ childId, caregiverId }: VocabularyManagerProps) {
  const [categories, setCategories] = useState<VocabularyCategory[]>([])
  const [words, setWords] = useState<VocabularyWord[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [selectedCategory, setSelectedCategory] = useState<VocabularyCategory | null>(null)
  
  // New word form state
  const [showAddWord, setShowAddWord] = useState(false)
  const [newWord, setNewWord] = useState({ word: "", phrase: "", isPing: false })
  
  // New category form state
  const [showAddCategory, setShowAddCategory] = useState(false)
  const [newCategory, setNewCategory] = useState({ name: "", icon: "message-circle", color: "#6366f1" })

  const supabase = createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  )

  // Load vocabulary
  useEffect(() => {
    const loadVocabulary = async () => {
      setLoading(true)
      try {
        const { data: cats } = await supabase
          .from("vocabulary_categories")
          .select("*")
          .or(`child_id.eq.${childId},child_id.is.null`)
          .order("display_order")

        const { data: wrds } = await supabase
          .from("vocabulary_words")
          .select("*")
          .or(`child_id.eq.${childId},child_id.is.null`)
          .order("display_order")

        setCategories(cats || [])
        setWords(wrds || [])

        if (cats && cats.length > 0) {
          setSelectedCategory(cats[0])
        }
      } catch (error) {
        console.error("Error loading vocabulary:", error)
      } finally {
        setLoading(false)
      }
    }

    loadVocabulary()
  }, [childId, supabase])

  // Initialize default vocabulary
  const initializeDefaults = async () => {
    setSaving(true)
    try {
      // Create default categories
      for (let i = 0; i < DEFAULT_VOCABULARY_CATEGORIES.length; i++) {
        const cat = DEFAULT_VOCABULARY_CATEGORIES[i]
        const { data: newCat, error: catError } = await supabase
          .from("vocabulary_categories")
          .insert({
            caregiver_id: caregiverId,
            child_id: childId,
            name: cat.name,
            icon: cat.icon,
            color: cat.color,
            display_order: i,
            is_system: true,
          })
          .select()
          .single()

        if (catError) throw catError

        // Create words for this category
        const defaultWords = DEFAULT_VOCABULARY_WORDS[cat.name] || []
        for (let j = 0; j < defaultWords.length; j++) {
          const word = defaultWords[j]
          await supabase.from("vocabulary_words").insert({
            caregiver_id: caregiverId,
            category_id: newCat.id,
            child_id: childId,
            word: word.word,
            phrase: word.phrase || word.word,
            icon: word.icon,
            is_ping_enabled: word.isPing || false,
            display_order: j,
          })
        }
      }

      // Reload vocabulary
      const { data: cats } = await supabase
        .from("vocabulary_categories")
        .select("*")
        .or(`child_id.eq.${childId},child_id.is.null`)
        .order("display_order")

      const { data: wrds } = await supabase
        .from("vocabulary_words")
        .select("*")
        .or(`child_id.eq.${childId},child_id.is.null`)
        .order("display_order")

      setCategories(cats || [])
      setWords(wrds || [])
      if (cats && cats.length > 0) setSelectedCategory(cats[0])
    } catch (error) {
      console.error("Error initializing defaults:", error)
    } finally {
      setSaving(false)
    }
  }

  // Add new category
  const handleAddCategory = async () => {
    if (!newCategory.name.trim()) return
    setSaving(true)
    try {
      const { data, error } = await supabase
        .from("vocabulary_categories")
        .insert({
          caregiver_id: caregiverId,
          child_id: childId,
          name: newCategory.name,
          icon: newCategory.icon,
          color: newCategory.color,
          display_order: categories.length,
        })
        .select()
        .single()

      if (error) throw error
      setCategories([...categories, data])
      setSelectedCategory(data)
      setNewCategory({ name: "", icon: "message-circle", color: "#6366f1" })
      setShowAddCategory(false)
    } catch (error) {
      console.error("Error adding category:", error)
    } finally {
      setSaving(false)
    }
  }

  // Add new word
  const handleAddWord = async () => {
    if (!newWord.word.trim() || !selectedCategory) return
    setSaving(true)
    try {
      const categoryWords = words.filter(w => w.category_id === selectedCategory.id)
      const { data, error } = await supabase
        .from("vocabulary_words")
        .insert({
          caregiver_id: caregiverId,
          category_id: selectedCategory.id,
          child_id: childId,
          word: newWord.word,
          phrase: newWord.phrase || newWord.word,
          is_ping_enabled: newWord.isPing,
          display_order: categoryWords.length,
        })
        .select()
        .single()

      if (error) throw error
      setWords([...words, data])
      setNewWord({ word: "", phrase: "", isPing: false })
      setShowAddWord(false)
    } catch (error) {
      console.error("Error adding word:", error)
    } finally {
      setSaving(false)
    }
  }

  // Toggle word ping enabled
  const toggleWordPing = async (wordId: string, currentValue: boolean) => {
    try {
      await supabase
        .from("vocabulary_words")
        .update({ is_ping_enabled: !currentValue })
        .eq("id", wordId)

      setWords(words.map(w => w.id === wordId ? { ...w, is_ping_enabled: !currentValue } : w))
    } catch (error) {
      console.error("Error toggling ping:", error)
    }
  }

  // Delete word
  const deleteWord = async (wordId: string) => {
    try {
      await supabase.from("vocabulary_words").delete().eq("id", wordId)
      setWords(words.filter(w => w.id !== wordId))
    } catch (error) {
      console.error("Error deleting word:", error)
    }
  }

  // Get words for selected category
  const filteredWords = selectedCategory
    ? words.filter(w => w.category_id === selectedCategory.id)
    : []

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    )
  }

  // Show setup screen if no vocabulary
  if (categories.length === 0) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center justify-center p-8 text-center">
          <MessageCircle className="h-12 w-12 text-muted-foreground mb-4" />
          <h3 className="font-semibold text-lg mb-2">Set Up Vocabulary</h3>
          <p className="text-muted-foreground mb-4">
            Add words and phrases for your child to use for practice and communication.
          </p>
          <Button onClick={initializeDefaults} disabled={saving}>
            {saving ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Plus className="h-4 w-4 mr-2" />}
            Add Default Vocabulary
          </Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      {/* Category selector */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2">
        {categories.map((cat) => (
          <Button
            key={cat.id}
            variant={selectedCategory?.id === cat.id ? "default" : "outline"}
            size="sm"
            className="whitespace-nowrap"
            style={{
              backgroundColor: selectedCategory?.id === cat.id ? cat.color : undefined,
              borderColor: cat.color,
            }}
            onClick={() => setSelectedCategory(cat)}
          >
            {cat.name}
          </Button>
        ))}
        <Dialog open={showAddCategory} onOpenChange={setShowAddCategory}>
          <DialogTrigger asChild>
            <Button variant="outline" size="sm">
              <FolderPlus className="h-4 w-4" />
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Category</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Name</Label>
                <Input
                  value={newCategory.name}
                  onChange={(e) => setNewCategory({ ...newCategory, name: e.target.value })}
                  placeholder="Category name"
                />
              </div>
              <div>
                <Label>Color</Label>
                <div className="flex flex-wrap gap-2 mt-2">
                  {COLORS.map((color) => (
                    <button
                      key={color}
                      className={`w-8 h-8 rounded-full ${newCategory.color === color ? "ring-2 ring-offset-2 ring-primary" : ""}`}
                      style={{ backgroundColor: color }}
                      onClick={() => setNewCategory({ ...newCategory, color })}
                    />
                  ))}
                </div>
              </div>
              <Button onClick={handleAddCategory} disabled={saving || !newCategory.name.trim()}>
                {saving ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                Add Category
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Words list */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between py-3">
          <CardTitle className="text-base">
            {selectedCategory?.name || "Words"}
          </CardTitle>
          <Dialog open={showAddWord} onOpenChange={setShowAddWord}>
            <DialogTrigger asChild>
              <Button size="sm">
                <Plus className="h-4 w-4 mr-1" />
                Add Word
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add Word</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label>Word/Button Label</Label>
                  <Input
                    value={newWord.word}
                    onChange={(e) => setNewWord({ ...newWord, word: e.target.value })}
                    placeholder="e.g., Potty"
                  />
                </div>
                <div>
                  <Label>Phrase to Speak</Label>
                  <Input
                    value={newWord.phrase}
                    onChange={(e) => setNewWord({ ...newWord, phrase: e.target.value })}
                    placeholder="e.g., I need to go potty"
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Enable Caregiver Ping</Label>
                    <p className="text-xs text-muted-foreground">Sends notification when tapped</p>
                  </div>
                  <Switch
                    checked={newWord.isPing}
                    onCheckedChange={(checked) => setNewWord({ ...newWord, isPing: checked })}
                  />
                </div>
                <Button onClick={handleAddWord} disabled={saving || !newWord.word.trim()}>
                  {saving ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                  Add Word
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </CardHeader>
        <CardContent>
          {filteredWords.length === 0 ? (
            <p className="text-center text-muted-foreground py-4">
              No words in this category yet
            </p>
          ) : (
            <div className="space-y-2">
              {filteredWords.map((word) => (
                <div
                  key={word.id}
                  className="flex items-center justify-between p-3 rounded-lg border bg-muted/30"
                >
                  <div className="flex-1">
                    <div className="font-medium">{word.word}</div>
                    {word.phrase && word.phrase !== word.word && (
                      <div className="text-sm text-muted-foreground">{word.phrase}</div>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    {word.is_ping_enabled ? (
                      <Badge variant="secondary" className="bg-amber-100 text-amber-700">
                        <Bell className="h-3 w-3 mr-1" />
                        Ping
                      </Badge>
                    ) : null}
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => toggleWordPing(word.id, word.is_ping_enabled)}
                    >
                      {word.is_ping_enabled ? (
                        <BellOff className="h-4 w-4" />
                      ) : (
                        <Bell className="h-4 w-4" />
                      )}
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-destructive"
                      onClick={() => deleteWord(word.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
