"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { StarField } from "@/components/star-field"
import { ChildrenManager } from "@/components/children-manager"
import { AIAssistant } from "@/components/ai-assistant"
import { PingNotifications } from "@/components/ping-notifications"
import { PushNotificationSettings } from "@/components/push-notification-settings"
import { CelebrationTemplatesManager } from "@/components/celebration-templates-manager"
import { CaregiversManager } from "@/components/caregivers-manager"
import { AACProgress } from "@/components/aac-progress" // Import AACProgress
import { ActivityLog } from "@/components/activity-log" // Declare ActivityLog
import type { Profile, Child, BathroomRequest, Reward, Caregiver, CustomButton } from "@/lib/types"
import { Home, Bell, BarChart3, Users, Settings, Star, Sparkles, UserPlus, Lock, Check, Clock, Droplets, ThumbsUp, AlertCircle } from "lucide-react"

interface CaregiverDashboardProps {
  profile: Profile
  children: Child[]
  initialPendingRequests: BathroomRequest[]
  initialHistory: BathroomRequest[]
  initialRewards: Reward[]
  initialCaregivers: Caregiver[]
  initialCustomButtons: CustomButton[]
  currentUserId?: string
}

export function CaregiverDashboard({
  profile,
  children: initialChildren,
  initialPendingRequests,
  initialHistory,
  initialRewards,
  initialCaregivers,
  initialCustomButtons,
  currentUserId,
}: CaregiverDashboardProps) {
  const router = useRouter()
  // Ensure children is always an array
  const safeInitialChildren = initialChildren || []
  const [children, setChildren] = useState(safeInitialChildren)
  const [selectedChildId, setSelectedChildId] = useState<string>(safeInitialChildren[0]?.id || profile.id)
  const [activeTab, setActiveTab] = useState("children")
  const [rewards, setRewards] = useState(initialRewards)
  const [caregivers, setCaregivers] = useState(initialCaregivers)
  const [customButtons, setCustomButtons] = useState(initialCustomButtons)
  
  // Passcode state
  const [passcode, setPasscode] = useState(["", "", "", ""])
  const [isSavingPasscode, setIsSavingPasscode] = useState(false)
  const [savedMessage, setSavedMessage] = useState<string | null>(null)
  
  // Get selected child info
  const selectedChild = children.find(c => c.id === selectedChildId) || children[0]
  const [totalPoints, setTotalPoints] = useState(selectedChild?.total_points || profile.total_points)

  // Update points when selected child changes
  useEffect(() => {
    const child = children.find(c => c.id === selectedChildId)
    if (child) {
      setTotalPoints(child.total_points)
    }
  }, [selectedChildId, children])

  // Real-time updates for child points
  useEffect(() => {
    const supabase = createClient()

    const channel = supabase
      .channel(`caregiver-updates-${selectedChildId}`)
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          schema: "public",
          table: "children",
          filter: `id=eq.${selectedChildId}`,
        },
        (payload) => {
          if (payload.new && typeof payload.new === "object" && "total_points" in payload.new) {
            setTotalPoints(payload.new.total_points as number)
            setChildren(prev => prev.map(c => 
              c.id === selectedChildId ? { ...c, total_points: payload.new.total_points as number } : c
            ))
          }
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [selectedChildId])

  const handlePasscodeChange = (index: number, value: string) => {
    if (value.length <= 1 && /^\d*$/.test(value)) {
      const updated = [...passcode]
      updated[index] = value
      setPasscode(updated)

      if (value && index < 3) {
        const nextInput = document.getElementById(`settings-passcode-${index + 1}`)
        nextInput?.focus()
      }
    }
  }

  const handleChangePasscode = async () => {
    const newPasscode = passcode.join("")
    if (newPasscode.length !== 4) return

    setIsSavingPasscode(true)
    const supabase = createClient()

    try {
      await supabase.from("profiles").update({ caregiver_passcode: newPasscode }).eq("id", profile.id)

      setSavedMessage("Passcode changed!")
      setPasscode(["", "", "", ""])
      setTimeout(() => setSavedMessage(null), 2000)
    } catch (error) {
      console.error("Failed to change passcode:", error)
    } finally {
      setIsSavingPasscode(false)
    }
  }

  return (
    <main className="relative min-h-svh pb-20 bg-slate-900">
      <StarField />

      {/* Header - Glassmorphism */}
      <header className="sticky top-0 z-20 glass border-b border-slate-700/50 py-3 px-4">
        <div className="flex items-center justify-between">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => router.push("/mode-select")} 
            className="h-10 w-10 hover:bg-slate-800/50 hover:text-cyan-400 transition-colors"
          >
            <Home className="h-5 w-5" />
          </Button>
          <div className="text-center">
            <h1 className="text-lg font-bold text-glow-cyan">Caregiver Dashboard</h1>
            <p className="text-xs text-slate-400">{selectedChild?.child_name || profile.child_name}</p>
          </div>
          {/* Points Badge - Glowing */}
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-gradient-to-r from-cyan-500 to-cyan-400 text-slate-900 font-bold text-sm shadow-lg shadow-cyan-500/30">
            <Sparkles className="h-4 w-4" />
            <Star className="h-4 w-4 fill-current" />
            {totalPoints}
          </div>
        </div>
      </header>

      {/* Main Navigation Tabs */}
      <div className="relative z-10">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="w-full justify-start gap-0 h-12 bg-slate-900/50 backdrop-blur-sm rounded-none border-b border-slate-700/50 overflow-x-auto">
            <TabsTrigger 
              value="messages" 
              className="flex flex-col items-center gap-0.5 px-4 py-2 data-[state=active]:bg-cyan-500/10 data-[state=active]:text-cyan-400 data-[state=active]:border-b-2 data-[state=active]:border-cyan-400 rounded-none min-w-[70px] text-slate-400 hover:text-slate-200 transition-colors"
            >
              <Bell className="h-4 w-4" />
              <span className="text-[10px]">Messages</span>
            </TabsTrigger>
            <TabsTrigger 
              value="activity" 
              className="flex flex-col items-center gap-0.5 px-4 py-2 data-[state=active]:bg-cyan-500/10 data-[state=active]:text-cyan-400 data-[state=active]:border-b-2 data-[state=active]:border-cyan-400 rounded-none min-w-[70px] text-slate-400 hover:text-slate-200 transition-colors"
            >
              <BarChart3 className="h-4 w-4" />
              <span className="text-[10px]">Activity</span>
            </TabsTrigger>
            <TabsTrigger 
              value="children" 
              className="flex flex-col items-center gap-0.5 px-4 py-2 data-[state=active]:bg-cyan-500/10 data-[state=active]:text-cyan-400 data-[state=active]:border-b-2 data-[state=active]:border-cyan-400 rounded-none min-w-[70px] text-slate-400 hover:text-slate-200 transition-colors"
            >
              <Users className="h-4 w-4" />
              <span className="text-[10px]">Children</span>
            </TabsTrigger>
            <TabsTrigger 
              value="settings" 
              className="flex flex-col items-center gap-0.5 px-4 py-2 data-[state=active]:bg-cyan-500/10 data-[state=active]:text-cyan-400 data-[state=active]:border-b-2 data-[state=active]:border-cyan-400 rounded-none min-w-[70px] text-slate-400 hover:text-slate-200 transition-colors"
            >
              <Settings className="h-4 w-4" />
              <span className="text-[10px]">Settings</span>
            </TabsTrigger>
          </TabsList>

          {/* Messages Tab */}
          <TabsContent value="messages" className="p-4 space-y-4 mt-0">
            <PingNotifications caregiverId={profile.id} childId={selectedChildId} />
          </TabsContent>

          {/* Activity Log Tab */}
          <TabsContent value="activity" className="p-4 space-y-4 mt-0">
            <ActivityLog 
              childId={selectedChildId} 
              childName={selectedChild?.child_name || profile.child_name}
              history={initialHistory}
            />
          </TabsContent>

          {/* Children Tab */}
          <TabsContent value="children" className="p-4 space-y-4 mt-0">
            {/* Child Selector */}
            <div className="flex items-center justify-between mb-2">
              <h2 className="text-sm font-medium text-slate-200">Select Child</h2>
              <span className="text-xs text-slate-400">{(children || []).length} child{(children || []).length !== 1 ? "ren" : ""}</span>
            </div>
            
            <div className="flex gap-3 overflow-x-auto pb-2">
              {children.map((child) => (
                <button
                  key={child.id}
                  onClick={() => setSelectedChildId(child.id)}
                  className={`flex flex-col items-center min-w-[100px] p-3 rounded-xl transition-all ${
                    child.id === selectedChildId 
                      ? "glass-card border-cyan-500/50 shadow-lg shadow-cyan-500/20" 
                      : "bg-slate-800/30 border border-slate-700/50 hover:border-cyan-500/30"
                  }`}
                >
                  <div className="relative">
                    {child.avatar_url ? (
                      <img 
                        src={child.avatar_url || "/placeholder.svg"} 
                        alt={child.child_name}
                        className={`h-14 w-14 rounded-full object-cover border-2 ${child.id === selectedChildId ? "border-cyan-400" : "border-slate-600"}`}
                      />
                    ) : (
                      <div className={`h-14 w-14 rounded-full flex items-center justify-center text-xl font-bold ${child.id === selectedChildId ? "bg-cyan-500/20 text-cyan-400" : "bg-slate-700 text-slate-300"}`}>
                        {child.child_name.charAt(0)}
                      </div>
                    )}
                  </div>
                  <span className={`mt-2 text-sm font-medium ${child.id === selectedChildId ? "text-cyan-400" : "text-slate-200"}`}>{child.child_name}</span>
                  <span className="text-xs text-amber-400 flex items-center gap-1">
                    <Star className="h-3 w-3 fill-current" />
                    {child.total_points}
                  </span>
                </button>
              ))}
              
              {/* Add Child Button */}
              <button
                onClick={() => {
                  // This will be handled by the ChildrenManager
                  const addButton = document.querySelector('[data-add-child-trigger]') as HTMLButtonElement
                  addButton?.click()
                }}
                className="flex flex-col items-center justify-center min-w-[100px] p-3 rounded-xl bg-slate-800/30 border-2 border-dashed border-cyan-500/30 hover:border-cyan-400 hover:bg-cyan-500/5 transition-all"
              >
                <div className="h-14 w-14 rounded-full bg-gradient-to-br from-cyan-500 to-cyan-400 flex items-center justify-center shadow-lg shadow-cyan-500/30">
                  <UserPlus className="h-6 w-6 text-slate-900" />
                </div>
                <span className="mt-2 text-sm font-medium text-cyan-400">Add Child</span>
              </button>
            </div>

            {/* Children Manager (Profile, Buttons, Rewards tabs) */}
            <ChildrenManager
              profile={profile}
              children={children}
              customButtons={customButtons}
              rewards={rewards}
              onChildrenChange={setChildren}
              onCustomButtonsChange={setCustomButtons}
              onRewardsChange={setRewards}
              selectedChildId={selectedChildId}
              onSelectChild={setSelectedChildId}
              hideChildSelector
            />
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings" className="p-4 space-y-4 mt-0">
            {/* AI Assistant info card */}
            <Card className="glass-card border-slate-700/50">
              <CardContent className="p-4">
                <h3 className="font-medium mb-2 flex items-center gap-2 text-cyan-400">
                  <Sparkles className="h-4 w-4" />
                  Meet Luca
                </h3>
                <p className="text-sm text-slate-400 mb-3">
                  Your smart potty training companion. Tap the chat button in the corner to ask questions, get tips, or send celebrations!
                </p>
                <div className="flex items-center gap-2 text-xs text-slate-500">
                  <div className="h-6 w-6 rounded-full bg-gradient-to-br from-cyan-400 to-cyan-600 flex items-center justify-center">
                    <span className="text-[10px] font-bold text-slate-900">L</span>
                  </div>
                  <span>Available 24/7 to help with your questions</span>
                </div>
              </CardContent>
            </Card>

            {/* Celebration Templates */}
            <CelebrationTemplatesManager profileId={profile.id} />

            {/* Push Notification Settings */}
            <PushNotificationSettings caregiverId={profile.id} />

            {/* Team/Caregivers */}
            <CaregiversManager caregivers={caregivers} profileId={profile.id} onCaregiversChange={setCaregivers} currentUserId={currentUserId} />
            
            {/* Passcode */}
            <Card className="glass-card border-slate-700/50">
              <CardContent className="p-4 space-y-4">
                {savedMessage && (
                  <div className="flex items-center justify-center gap-2 rounded-lg bg-emerald-500/20 border border-emerald-500/30 p-3 text-emerald-400">
                    <Check className="h-4 w-4" />
                    <span className="text-sm">{savedMessage}</span>
                  </div>
                )}
                <div className="flex items-center gap-2">
                  <Lock className="h-4 w-4 text-cyan-400" />
                  <div>
                    <h3 className="font-medium text-slate-200">Caregiver Passcode</h3>
                    <p className="text-xs text-slate-400">Enter a new 4-digit passcode</p>
                  </div>
                </div>
                <div className="flex justify-center gap-3">
                  {passcode.map((digit, index) => (
                    <Input
                      key={index}
                      id={`settings-passcode-${index}`}
                      type="text"
                      inputMode="numeric"
                      maxLength={1}
                      value={digit}
                      onChange={(e) => handlePasscodeChange(index, e.target.value)}
                      className="h-12 w-12 text-center text-xl font-bold bg-slate-800/50 border-slate-700/50 focus:border-cyan-500/50 focus:ring-cyan-500/20"
                    />
                  ))}
                </div>
                <Button
                  onClick={handleChangePasscode}
                  disabled={isSavingPasscode || passcode.join("").length !== 4}
                  className="w-full bg-gradient-to-r from-cyan-500 to-cyan-400 hover:from-cyan-400 hover:to-cyan-300 text-slate-900 font-medium shadow-lg shadow-cyan-500/20"
                >
                  {isSavingPasscode ? "Saving..." : "Change Passcode"}
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
      
      {/* Floating AI Assistant - available from any tab */}
      <AIAssistant 
        childId={selectedChildId} 
        childName={selectedChild?.child_name || profile.child_name}
        profileId={profile.id}
      />
    </main>
  )
}
