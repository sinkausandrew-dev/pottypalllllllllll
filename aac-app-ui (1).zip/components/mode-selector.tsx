"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { createClient } from "@/lib/supabase/client"
import { Gamepad2, Settings, Plus, User, Edit2, Pencil, Trash2, AlertTriangle } from "lucide-react"
import type { Child, Profile } from "@/lib/types"
import { PottyPalLogo } from "@/components/pottypal-logo"

interface ModeSelectorProps {
  profile: Profile | null
  children: Child[]
}

export function ModeSelector({ profile, children: initialChildren }: ModeSelectorProps) {
  const router = useRouter()
  const [showPasscode, setShowPasscode] = useState(false)
  const [passcode, setPasscode] = useState(["", "", "", ""])
  const [error, setError] = useState<string | null>(null)
  const [isVerifying, setIsVerifying] = useState(false)
  const safeInitialChildren = initialChildren || []
  const [children, setChildren] = useState(safeInitialChildren)
  const [caregiverDisplayName, setCaregiverDisplayName] = useState("Caregiver Dashboard")
  const [editingChildId, setEditingChildId] = useState<string | null>(null)
  const [editingChildName, setEditingChildName] = useState("")
  const [isEditingCaregiverName, setIsEditingCaregiverName] = useState(false)
  const [tempCaregiverName, setTempCaregiverName] = useState("Caregiver Dashboard")
  const [isSaving, setIsSaving] = useState(false)
  const [deletingChildId, setDeletingChildId] = useState<string | null>(null)
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false)

  const handlePasscodeChange = (index: number, value: string) => {
    if (value.length <= 1 && /^\d*$/.test(value)) {
      const updated = [...passcode]
      updated[index] = value
      setPasscode(updated)

      if (value && index < 3) {
        const nextInput = document.getElementById(`verify-passcode-${index + 1}`)
        nextInput?.focus()
      }
    }
  }

  const handlePasscodeKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === "Backspace" && !passcode[index] && index > 0) {
      const prevInput = document.getElementById(`verify-passcode-${index - 1}`)
      prevInput?.focus()
    }
  }

  // Load children and caregiver display name on mount
  useEffect(() => {
    const loadData = async () => {
      const supabase = createClient()
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) return

      // Load children
      const { data: childrenData } = await supabase
        .from("children")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: true })

      if (childrenData && childrenData.length > 0) {
        setChildren(childrenData)
      }

      // Load caregiver display name from profile
      if (profile) {
        try {
          const { data: profileData } = await supabase
            .from("profiles")
            .select("caregiver_display_name")
            .eq("id", user.id)
            .maybeSingle()

          if (profileData?.caregiver_display_name) {
            setCaregiverDisplayName(profileData.caregiver_display_name)
            setTempCaregiverName(profileData.caregiver_display_name)
          }
        } catch (error) {
          // Column might not exist yet, use default
          console.log("caregiver_display_name column may not exist yet")
        }
      }
    }
    loadData()
  }, [profile])

  const verifyPasscode = async () => {
    setIsVerifying(true)
    setError(null)

    const supabase = createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      setError("Not authenticated")
      setIsVerifying(false)
      return
    }

    const { data: profileData } = await supabase
      .from("profiles")
      .select("caregiver_passcode")
      .eq("id", user.id)
      .maybeSingle()

    if (profileData?.caregiver_passcode === passcode.join("")) {
      router.push("/caregiver")
    } else {
      setError("Incorrect passcode")
      setPasscode(["", "", "", ""])
      document.getElementById("verify-passcode-0")?.focus()
    }

    setIsVerifying(false)
  }

  const handleChildSelect = (childId: string) => {
    router.push(`/child?childId=${childId}`)
  }

  const handleAddChild = () => {
    router.push("/onboarding?addChild=true")
  }

  const handleEditChildName = async (childId: string) => {
    if (!editingChildName.trim()) return
    setIsSaving(true)

    const supabase = createClient()
    try {
      await supabase
        .from("children")
        .update({ child_name: editingChildName.trim() })
        .eq("id", childId)

      setChildren(children.map((c) => (c.id === childId ? { ...c, child_name: editingChildName.trim() } : c)))
      setEditingChildId(null)
      setEditingChildName("")
    } catch (error) {
      console.error("Failed to update child name:", error)
    } finally {
      setIsSaving(false)
    }
  }

  const handleDeleteChild = async (childId: string) => {
    if (children.length <= 1) {
      alert("You must have at least one child profile.")
      return
    }
    
    setIsSaving(true)
    const supabase = createClient()

    try {
      // Delete associated data first
      await supabase.from("bathroom_requests").delete().eq("child_id", childId)
      await supabase.from("rewards").delete().eq("child_id", childId)
      await supabase.from("redeemed_rewards").delete().eq("child_id", childId)
      
      // Delete the child
      const { error } = await supabase.from("children").delete().eq("id", childId)
      
      if (error) throw error

      setChildren(children.filter((c) => c.id !== childId))
      setShowDeleteConfirm(false)
      setDeletingChildId(null)
    } catch (error) {
      console.error("Failed to delete child:", error)
      alert("Failed to delete child profile. Please try again.")
    } finally {
      setIsSaving(false)
    }
  }

  const handleSaveCaregiverName = async () => {
    if (!tempCaregiverName.trim()) return
    setIsSaving(true)

    const supabase = createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user || !profile) {
      setIsSaving(false)
      return
    }

    try {
      const { error } = await supabase
        .from("profiles")
        .update({ caregiver_display_name: tempCaregiverName.trim() })
        .eq("id", user.id)

      if (error) {
        // If column doesn't exist, inform user they need to run migration
        if (error.message?.includes("column") || error.code === "42703") {
          console.error("caregiver_display_name column does not exist. Please run migration script 004-add-caregiver-display-name.sql")
          alert("Please run the database migration to enable this feature. See scripts/004-add-caregiver-display-name.sql")
          return
        }
        throw error
      }

      setCaregiverDisplayName(tempCaregiverName.trim())
      setIsEditingCaregiverName(false)
    } catch (error) {
      console.error("Failed to update caregiver name:", error)
    } finally {
      setIsSaving(false)
    }
  }

  if (showPasscode) {
    return (
      <Card className="glass-card border-slate-700/50">
        <CardHeader className="text-center">
          <CardTitle className="text-xl text-slate-100 text-glow-cyan">Enter Caregiver Passcode</CardTitle>
        </CardHeader>
        <CardContent className="space-y-5">
          <div className="flex justify-center gap-3">
            {passcode.map((digit, index) => (
              <Input
                key={index}
                id={`verify-passcode-${index}`}
                type="text"
                inputMode="numeric"
                maxLength={1}
                value={digit}
                onChange={(e) => handlePasscodeChange(index, e.target.value)}
                onKeyDown={(e) => handlePasscodeKeyDown(index, e)}
                className="h-14 w-14 text-center text-2xl font-bold bg-slate-800/50 border-slate-700/50 focus:border-cyan-500/50 focus:ring-cyan-500/20 text-slate-100"
              />
            ))}
          </div>

          {error && <p className="text-center text-sm text-red-400">{error}</p>}

          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={() => {
                setShowPasscode(false)
                setPasscode(["", "", "", ""])
                setError(null)
              }}
              className="h-12 flex-1 border-slate-700/50 bg-slate-800/50 text-slate-200 hover:bg-slate-700/50 hover:text-cyan-400"
            >
              Cancel
            </Button>
            <Button
              onClick={verifyPasscode}
              disabled={isVerifying || passcode.some((d) => !d)}
              className="h-12 flex-1 bg-gradient-to-r from-cyan-500 to-cyan-400 text-slate-900 font-medium hover:from-cyan-400 hover:to-cyan-300 shadow-lg shadow-cyan-500/20"
            >
              {isVerifying ? "Verifying..." : "Continue"}
            </Button>
          </div>
        </CardContent>
      </Card>
    )
  }

  // Determine which children to show
  // If children table has entries, use those. Otherwise fall back to profile.
  const displayChildren = children.length > 0 
    ? children 
    : profile 
      ? [{ id: profile.id, child_name: profile.child_name, user_id: profile.id, child_age: profile.child_age, total_points: profile.total_points, created_at: "", updated_at: "" } as Child]
      : []

  return (
    <div className="flex flex-col gap-6">
      <div className="text-center">
        <PottyPalLogo size="lg" showText={true} className="mb-4" />
        <p className="mt-2 text-slate-400">Who's using the app?</p>
      </div>

      <div className="flex flex-col gap-4">
        {/* Child Mode Buttons - Multiple children support */}
        {displayChildren.map((child) => (
          <div key={child.id} className="relative group">
            <Button
              onClick={() => handleChildSelect(child.id)}
              className="h-28 w-full flex-col gap-2 bg-gradient-to-br from-cyan-500 to-cyan-400 text-slate-900 hover:from-cyan-400 hover:to-cyan-300 transition-all shadow-xl shadow-cyan-500/30 border-0"
            >
              <Gamepad2 className="h-10 w-10" />
              {editingChildId === child.id ? (
                <div className="flex items-center gap-2 w-full px-4">
                  <Input
                    value={editingChildName}
                    onChange={(e) => setEditingChildName(e.target.value)}
                    onClick={(e) => e.stopPropagation()}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        e.preventDefault()
                        handleEditChildName(child.id)
                      } else if (e.key === "Escape") {
                        setEditingChildId(null)
                        setEditingChildName("")
                      }
                    }}
                    className="h-8 text-center font-bold bg-background/90"
                    autoFocus
                  />
                </div>
              ) : (
                <>
                  <span className="text-lg font-bold">{child.child_name}</span>
                  {child.total_points > 0 && (
                    <span className="text-sm opacity-90">{child.total_points} points</span>
                  )}
                </>
              )}
            </Button>
            <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 bg-background/80 hover:bg-background"
                onClick={(e) => {
                  e.stopPropagation()
                  setEditingChildId(child.id)
                  setEditingChildName(child.child_name)
                }}
              >
                <Pencil className="h-4 w-4" />
              </Button>
              {children.length > 1 && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 bg-background/80 hover:bg-destructive/90 hover:text-white"
                  onClick={(e) => {
                    e.stopPropagation()
                    setDeletingChildId(child.id)
                    setShowDeleteConfirm(true)
                  }}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              )}
            </div>
            {editingChildId === child.id && (
              <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex gap-2">
                <Button
                  size="sm"
                  variant="default"
                  onClick={(e) => {
                    e.stopPropagation()
                    handleEditChildName(child.id)
                  }}
                  disabled={isSaving || !editingChildName.trim()}
                  className="h-7 text-xs"
                >
                  Save
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={(e) => {
                    e.stopPropagation()
                    setEditingChildId(null)
                    setEditingChildName("")
                  }}
                  className="h-7 text-xs"
                >
                  Cancel
                </Button>
              </div>
            )}
          </div>
        ))}

        {/* Add Child Button - Always show for authenticated users */}
        <Button
          variant="outline"
          onClick={handleAddChild}
          className="h-20 flex-col gap-2 border-dashed border-2 border-slate-600/50 hover:border-cyan-500/50 hover:bg-cyan-500/5 bg-slate-800/30 text-slate-300 hover:text-cyan-400 transition-all"
        >
          <Plus className="h-6 w-6" />
          <span className="text-sm">Add Another Child</span>
        </Button>

        {/* Caregiver Mode Button */}
        <div className="relative group">
          <Button
            variant="outline"
            onClick={() => setShowPasscode(true)}
            className="h-20 w-full flex-col gap-2 glass-card border-slate-700/50 text-slate-200 hover:border-cyan-500/30 hover:bg-cyan-500/5 transition-all"
          >
            <Settings className="h-8 w-8" />
            {isEditingCaregiverName ? (
              <Input
                value={tempCaregiverName}
                onChange={(e) => setTempCaregiverName(e.target.value)}
                onClick={(e) => e.stopPropagation()}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault()
                    handleSaveCaregiverName()
                  } else if (e.key === "Escape") {
                    setIsEditingCaregiverName(false)
                    setTempCaregiverName(caregiverDisplayName)
                  }
                }}
                className="h-8 text-center font-bold bg-background/90 w-48"
                autoFocus
              />
            ) : (
              <span className="text-base">{caregiverDisplayName}</span>
            )}
          </Button>
          {!isEditingCaregiverName && (
            <Button
              variant="ghost"
              size="icon"
              className="absolute top-2 right-2 h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity bg-background/80 hover:bg-background"
              onClick={(e) => {
                e.stopPropagation()
                setIsEditingCaregiverName(true)
              }}
            >
              <Pencil className="h-4 w-4" />
            </Button>
          )}
          {isEditingCaregiverName && (
            <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex gap-2">
              <Button
                size="sm"
                variant="default"
                onClick={(e) => {
                  e.stopPropagation()
                  handleSaveCaregiverName()
                }}
                disabled={isSaving || !tempCaregiverName.trim()}
                className="h-7 text-xs"
              >
                Save
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={(e) => {
                  e.stopPropagation()
                  setIsEditingCaregiverName(false)
                  setTempCaregiverName(caregiverDisplayName)
                }}
                className="h-7 text-xs"
              >
                Cancel
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* Delete Confirmation Dialog */}
      <Dialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-destructive">
              <AlertTriangle className="h-5 w-5" />
              Delete Child Profile
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-muted-foreground">
              Are you sure you want to delete{" "}
              <strong>{children.find((c) => c.id === deletingChildId)?.child_name}</strong>'s profile?
            </p>
            <p className="text-sm text-destructive/80">
              This will permanently remove all their progress, points, rewards, and history. This action cannot be undone.
            </p>
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => {
                  setShowDeleteConfirm(false)
                  setDeletingChildId(null)
                }}
                className="flex-1"
                disabled={isSaving}
              >
                Cancel
              </Button>
              <Button
                variant="destructive"
                onClick={() => deletingChildId && handleDeleteChild(deletingChildId)}
                className="flex-1"
                disabled={isSaving}
              >
                {isSaving ? "Deleting..." : "Delete Profile"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
