"use client"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  BarChart3, TrendingUp, Grid3X3, List, 
  Download, MessageCircle, Volume2, Loader2,
  Calendar, Sparkles, Heart, Star
} from "lucide-react"
import type { ChildAACSettings, LayoutMode } from "@/lib/types"

interface AACProgressProps {
  childId: string
  childName: string
}

interface SimpleMetrics {
  totalUtterances: number
  totalWords: number
  uniqueWords: number
  avgUtteranceLength: number
  favoriteWords: Array<{ word: string; count: number }>
  recentUtterances: Array<{ text: string; createdAt: string }>
  streakDays: number
  lastActiveDate: string | null
}

export function AACProgress({ childId, childName }: AACProgressProps) {
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [settings, setSettings] = useState<ChildAACSettings | null>(null)
  const [metrics, setMetrics] = useState<SimpleMetrics | null>(null)
  const [dateRange, setDateRange] = useState<'7d' | '14d' | '30d'>('14d')

  const supabase = createClient()

  useEffect(() => {
    loadData()
  }, [childId, dateRange])

  const loadData = async () => {
    setLoading(true)
    try {
      // Load or create child settings
      let { data: settingsData } = await supabase
        .from("child_aac_settings")
        .select("*")
        .eq("child_id", childId)
        .single()

      if (!settingsData) {
        // Create default settings
        const { data: newSettings } = await supabase
          .from("child_aac_settings")
          .insert({
            child_id: childId,
            tier_locked: true, // Lock tier - we're not using tier system for comparisons
            layout_mode: 'category_tabs',
            grid_size: 20,
            sound_enabled_default: true,
            show_grammar_helpers: false,
          })
          .select("*")
          .single()
        settingsData = newSettings
      }

      // Calculate personal metrics
      const metricsData = await calculateMetrics(childId, dateRange)

      setSettings(settingsData)
      setMetrics(metricsData)
    } catch (error) {
      console.error("Error loading AAC data:", error)
    } finally {
      setLoading(false)
    }
  }

  const calculateMetrics = async (childId: string, range: '7d' | '14d' | '30d'): Promise<SimpleMetrics> => {
    const days = range === '7d' ? 7 : range === '14d' ? 14 : 30
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - days)

    try {
      // Get all events in range
      const { data: events } = await supabase
        .from("aac_utterance_events")
        .select("*")
        .eq("child_id", childId)
        .gte("created_at", startDate.toISOString())
        .order("created_at", { ascending: false })

      if (!events || events.length === 0) {
        return {
          totalUtterances: 0,
          totalWords: 0,
          uniqueWords: 0,
          avgUtteranceLength: 0,
          favoriteWords: [],
          recentUtterances: [],
          streakDays: 0,
          lastActiveDate: null,
        }
      }

      // Count utterances (speak/send events)
      const utteranceEvents = events.filter(e => 
        e.event_type === 'speak_utterance' || e.event_type === 'send_ping'
      )

      // Calculate average utterance length
      const utteranceLengths = utteranceEvents
        .filter(e => e.utterance_word_ids && e.utterance_word_ids.length > 0)
        .map(e => e.utterance_word_ids.length)
      
      const avgUtteranceLength = utteranceLengths.length > 0
        ? utteranceLengths.reduce((a, b) => a + b, 0) / utteranceLengths.length
        : 0

      // Count unique words
      const wordCounts = new Map<string, number>()
      const uniqueWordIds = new Set<string>()
      
      for (const event of events) {
        if (event.word_id) {
          uniqueWordIds.add(event.word_id)
          wordCounts.set(event.word_id, (wordCounts.get(event.word_id) || 0) + 1)
        }
        if (event.utterance_word_ids) {
          for (const id of event.utterance_word_ids) {
            uniqueWordIds.add(id)
          }
        }
      }

      // Get word texts for favorites (would need to join with vocabulary_words)
      // For now, just count by ID
      const sortedWordCounts = Array.from(wordCounts.entries())
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5)
        .map(([wordId, count]) => ({ word: wordId, count }))

      // Recent utterances
      const recentUtterances = utteranceEvents
        .filter(e => e.utterance_text)
        .slice(0, 10)
        .map(e => ({
          text: e.utterance_text || '',
          createdAt: e.created_at,
        }))

      // Calculate streak (days in a row with activity)
      const activeDates = new Set(
        events.map(e => new Date(e.created_at).toDateString())
      )
      
      let streakDays = 0
      const today = new Date()
      for (let i = 0; i < days; i++) {
        const checkDate = new Date(today)
        checkDate.setDate(checkDate.getDate() - i)
        if (activeDates.has(checkDate.toDateString())) {
          streakDays++
        } else if (i > 0) {
          break // Streak broken
        }
      }

      const lastActiveDate = events.length > 0 ? events[0].created_at : null

      return {
        totalUtterances: utteranceEvents.length,
        totalWords: events.filter(e => e.event_type === 'tap_word' || e.event_type === 'add_to_utterance').length,
        uniqueWords: uniqueWordIds.size,
        avgUtteranceLength: Math.round(avgUtteranceLength * 10) / 10,
        favoriteWords: sortedWordCounts,
        recentUtterances,
        streakDays,
        lastActiveDate,
      }
    } catch (error) {
      console.error("Error calculating metrics:", error)
      return {
        totalUtterances: 0,
        totalWords: 0,
        uniqueWords: 0,
        avgUtteranceLength: 0,
        favoriteWords: [],
        recentUtterances: [],
        streakDays: 0,
        lastActiveDate: null,
      }
    }
  }

  const updateSettings = async (updates: Partial<ChildAACSettings>) => {
    if (!settings) return

    setSaving(true)
    try {
      const { error } = await supabase
        .from("child_aac_settings")
        .update({ ...updates, updated_at: new Date().toISOString() })
        .eq("child_id", childId)

      if (error) throw error

      setSettings({ ...settings, ...updates })
    } catch (error) {
      console.error("Error updating settings:", error)
    } finally {
      setSaving(false)
    }
  }

  const handleExportSummary = () => {
    if (!metrics) return

    const summary = `
Communication Progress for ${childName}
Generated: ${new Date().toLocaleDateString()}
Time Period: Last ${dateRange === '7d' ? '7' : dateRange === '14d' ? '14' : '30'} days

COMMUNICATION HIGHLIGHTS:
- Total Messages Spoken: ${metrics.totalUtterances}
- Total Words Used: ${metrics.totalWords}
- Different Words Used: ${metrics.uniqueWords}
- Average Message Length: ${metrics.avgUtteranceLength} words
- Practice Streak: ${metrics.streakDays} days

RECENT MESSAGES:
${metrics.recentUtterances.slice(0, 5).map(u => `- "${u.text}" (${new Date(u.createdAt).toLocaleDateString()})`).join('\n') || 'No recent messages'}

---
This summary celebrates ${childName}'s communication progress.
    `.trim()

    const blob = new Blob([summary], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${childName.replace(/\s+/g, '_')}_communication_${new Date().toISOString().split('T')[0]}.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[300px]">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <Card className="border-border/50 bg-card/80">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-primary" />
                Communication Progress
              </CardTitle>
              <CardDescription>
                Celebrating {childName}&apos;s communication journey
              </CardDescription>
            </div>
            <Select value={dateRange} onValueChange={(v) => setDateRange(v as '7d' | '14d' | '30d')}>
              <SelectTrigger className="w-[120px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7d">Last 7 days</SelectItem>
                <SelectItem value="14d">Last 14 days</SelectItem>
                <SelectItem value="30d">Last 30 days</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
      </Card>

      {/* Celebration Stats */}
      {metrics && (
        <div className="grid grid-cols-2 gap-3">
          {/* Messages Spoken */}
          <Card className="border-border/50 bg-gradient-to-br from-blue-500/10 to-blue-600/5">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-blue-500/20 flex items-center justify-center">
                  <MessageCircle className="h-5 w-5 text-blue-500" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{metrics.totalUtterances}</p>
                  <p className="text-xs text-muted-foreground">Messages Spoken</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Words Used */}
          <Card className="border-border/50 bg-gradient-to-br from-green-500/10 to-green-600/5">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-green-500/20 flex items-center justify-center">
                  <Volume2 className="h-5 w-5 text-green-500" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{metrics.totalWords}</p>
                  <p className="text-xs text-muted-foreground">Words Used</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Different Words */}
          <Card className="border-border/50 bg-gradient-to-br from-purple-500/10 to-purple-600/5">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-purple-500/20 flex items-center justify-center">
                  <Sparkles className="h-5 w-5 text-purple-500" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{metrics.uniqueWords}</p>
                  <p className="text-xs text-muted-foreground">Different Words</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Practice Streak */}
          <Card className="border-border/50 bg-gradient-to-br from-amber-500/10 to-amber-600/5">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-amber-500/20 flex items-center justify-center">
                  <Star className="h-5 w-5 text-amber-500" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{metrics.streakDays}</p>
                  <p className="text-xs text-muted-foreground">Day Streak</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Message Length Progress */}
      {metrics && metrics.avgUtteranceLength > 0 && (
        <Card className="border-border/50 bg-card/80">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-primary" />
              Average Message Length
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-3xl font-bold">{metrics.avgUtteranceLength}</span>
                <span className="text-sm text-muted-foreground">words per message</span>
              </div>
              <Progress value={Math.min(metrics.avgUtteranceLength * 20, 100)} className="h-2" />
              <p className="text-xs text-muted-foreground">
                {metrics.avgUtteranceLength >= 3 
                  ? "Building longer sentences - great progress!" 
                  : metrics.avgUtteranceLength >= 2
                  ? "Combining words nicely!"
                  : "Every word counts!"}
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Recent Messages */}
      {metrics && metrics.recentUtterances.length > 0 && (
        <Card className="border-border/50 bg-card/80">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Calendar className="h-4 w-4 text-primary" />
              Recent Messages
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="max-h-[200px]">
              <div className="space-y-2">
                {metrics.recentUtterances.map((utterance, idx) => (
                  <div 
                    key={idx} 
                    className="flex items-start gap-3 p-2 rounded-lg bg-muted/30"
                  >
                    <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <Heart className="h-4 w-4 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">
                        &ldquo;{utterance.text}&rdquo;
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(utterance.createdAt).toLocaleDateString(undefined, {
                          weekday: 'short',
                          month: 'short',
                          day: 'numeric',
                          hour: 'numeric',
                          minute: '2-digit',
                        })}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      )}

      {/* Settings */}
      <Card className="border-border/50 bg-card/80">
        <CardHeader className="pb-2">
          <CardTitle className="text-base">Communication Settings</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <Label htmlFor="grammar-helpers" className="flex items-center gap-2">
              <Sparkles className="h-4 w-4" />
              Show word suggestions
            </Label>
            <Switch
              id="grammar-helpers"
              checked={settings?.show_grammar_helpers || false}
              onCheckedChange={(checked) => updateSettings({ show_grammar_helpers: checked })}
              disabled={saving}
            />
          </div>

          <div className="flex items-center justify-between">
            <Label className="flex items-center gap-2">
              {settings?.layout_mode === 'lamp_grid' ? (
                <><Grid3X3 className="h-4 w-4" /> Grid View</>
              ) : (
                <><List className="h-4 w-4" /> Category View</>
              )}
            </Label>
            <Select 
              value={settings?.layout_mode || 'category_tabs'} 
              onValueChange={(v) => updateSettings({ layout_mode: v as LayoutMode })}
              disabled={saving}
            >
              <SelectTrigger className="w-[140px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="category_tabs">Categories</SelectItem>
                <SelectItem value="lamp_grid">Grid</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center justify-between">
            <Label className="flex items-center gap-2">
              <Volume2 className="h-4 w-4" />
              Sound enabled
            </Label>
            <Switch
              checked={settings?.sound_enabled_default || true}
              onCheckedChange={(checked) => updateSettings({ sound_enabled_default: checked })}
              disabled={saving}
            />
          </div>
        </CardContent>
      </Card>

      {/* Export Button */}
      <Button
        variant="outline"
        onClick={handleExportSummary}
        disabled={!metrics}
        className="w-full min-h-[44px] bg-transparent"
      >
        <Download className="h-4 w-4 mr-2" />
        Download Progress Summary
      </Button>
    </div>
  )
}
