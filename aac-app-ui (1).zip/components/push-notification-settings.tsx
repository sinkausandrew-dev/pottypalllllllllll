"use client"

import { Bell, BellOff, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { usePushNotifications } from "@/hooks/use-push-notifications"

interface PushNotificationSettingsProps {
  caregiverId: string
}

export function PushNotificationSettings({ caregiverId }: PushNotificationSettingsProps) {
  const {
    isSupported,
    isSubscribed,
    permission,
    loading,
    subscribe,
    unsubscribe,
  } = usePushNotifications({ caregiverId })

  if (!isSupported) {
    return (
      <Card className="border-border/50 bg-card/80">
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <BellOff className="h-5 w-5 text-muted-foreground" />
            <div>
              <h3 className="font-medium">Push Notifications</h3>
              <p className="text-sm text-muted-foreground">
                Your browser does not support push notifications
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (loading) {
    return (
      <Card className="border-border/50 bg-card/80">
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
            <span className="text-muted-foreground">Loading notification settings...</span>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="border-border/50 bg-card/80">
      <CardContent className="p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Bell className="h-5 w-5 text-muted-foreground" />
            <div>
              <h3 className="font-medium">Push Notifications</h3>
              <p className="text-sm text-muted-foreground">
                {isSubscribed
                  ? "You will receive alerts when your child needs you"
                  : "Enable to receive alerts on this device"}
              </p>
            </div>
          </div>
        </div>

        {permission === "denied" ? (
          <div className="rounded-lg bg-destructive/10 p-3 text-sm text-destructive">
            Notifications are blocked. Please enable them in your browser settings.
          </div>
        ) : (
          <Button
            onClick={isSubscribed ? unsubscribe : subscribe}
            variant={isSubscribed ? "outline" : "default"}
            className={isSubscribed ? "w-full bg-transparent" : "w-full"}
          >
            {isSubscribed ? (
              <>
                <BellOff className="mr-2 h-4 w-4" />
                Disable Notifications
              </>
            ) : (
              <>
                <Bell className="mr-2 h-4 w-4" />
                Enable Notifications
              </>
            )}
          </Button>
        )}

        {isSubscribed && (
          <p className="text-xs text-center text-muted-foreground">
            Notifications enabled on this device
          </p>
        )}
      </CardContent>
    </Card>
  )
}
