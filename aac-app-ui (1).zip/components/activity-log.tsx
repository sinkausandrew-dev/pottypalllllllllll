"use client"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import type { BathroomRequest } from "@/lib/types"
import { Clock, Droplets, ThumbsUp, AlertCircle, CheckCircle2, XCircle, RefreshCw, Calendar, Filter } from "lucide-react"
import { cn } from "@/lib/utils"

interface ActivityLogProps {
  childId: string
  childName: string
  history: BathroomRequest[]
}

type FilterType = "all" | "pee" | "poop" | "completed" | "cancelled"

const REQUEST_TYPE_CONFIG = {
  pee: {
    icon: Droplets,
    label: "Pee",
    color: "text-cyan-400",
    bgColor: "bg-cyan-500/20",
    borderColor: "border-cyan-500/30",
  },
  poop: {
    icon: Droplets,
    label: "Poop", 
    color: "text-purple-400",
    bgColor: "bg-purple-500/20",
    borderColor: "border-purple-500/30",
  },
  custom: {
    icon: AlertCircle,
    label: "Custom",
    color: "text-amber-400",
    bgColor: "bg-amber-500/20",
    borderColor: "border-amber-500/30",
  },
}

const STATUS_CONFIG = {
  pending: {
    icon: Clock,
    label: "Pending",
    color: "text-yellow-400",
  },
  completed: {
    icon: CheckCircle2,
    label: "Completed",
    color: "text-green-400",
  },
  cancelled: {
    icon: XCircle,
    label: "Cancelled",
    color: "text-red-400",
  },
}

export function ActivityLog({ childId, childName, history: initialHistory }: ActivityLogProps) {
  const [activities, setActivities] = useState<BathroomRequest[]>(initialHistory)
  const [filter, setFilter] = useState<FilterType>("all")
  const [isLoading, setIsLoading] = useState(false)
  const [showFilters, setShowFilters] = useState(false)

  // Fetch fresh data
  const refreshData = async () => {
    setIsLoading(true)
    const supabase = createClient()
    
    const { data, error } = await supabase
      .from("bathroom_requests")
      .select("*")
      .eq("child_id", childId)
      .order("created_at", { ascending: false })
      .limit(50)

    if (!error && data) {
      setActivities(data)
    }
    setIsLoading(false)
  }

  // Real-time subscription
  useEffect(() => {
    const supabase = createClient()
    
    const channel = supabase
      .channel(`activity-log-${childId}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "bathroom_requests",
          filter: `child_id=eq.${childId}`,
        },
        () => {
          refreshData()
        }
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [childId])

  // Filter activities
  const filteredActivities = activities.filter(activity => {
    if (filter === "all") return true
    if (filter === "pee") return activity.request_type === "pee"
    if (filter === "poop") return activity.request_type === "poop"
    if (filter === "completed") return activity.status === "completed"
    if (filter === "cancelled") return activity.status === "cancelled"
    return true
  })

  // Group by date
  const groupedActivities = filteredActivities.reduce((groups, activity) => {
    const date = new Date(activity.created_at).toLocaleDateString("en-US", {
      weekday: "long",
      month: "short",
      day: "numeric",
    })
    if (!groups[date]) {
      groups[date] = []
    }
    groups[date].push(activity)
    return groups
  }, {} as Record<string, BathroomRequest[]>)

  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString("en-US", {
      hour: "numeric",
      minute: "2-digit",
      hour12: true,
    })
  }

  const getTimeDiff = (start: string, end: string | null) => {
    if (!end) return null
    const diff = new Date(end).getTime() - new Date(start).getTime()
    const minutes = Math.round(diff / 60000)
    if (minutes < 1) return "< 1 min"
    if (minutes === 1) return "1 min"
    return `${minutes} mins`
  }

  // Stats for today
  const today = new Date().toDateString()
  const todayActivities = activities.filter(a => new Date(a.created_at).toDateString() === today)
  const completedToday = todayActivities.filter(a => a.status === "completed").length
  const pointsToday = todayActivities.reduce((sum, a) => sum + (a.points_awarded || 0), 0)

  return (
    <div className="space-y-4">
      {/* Header with Stats */}
      <Card className="glass-card border-slate-700/50">
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-semibold text-lg text-slate-100">{childName}'s Activity</h3>
              <p className="text-sm text-slate-400">Track potty training progress</p>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={refreshData}
              disabled={isLoading}
              className="h-10 w-10 hover:bg-slate-800/50 hover:text-cyan-400"
            >
              <RefreshCw className={cn("h-5 w-5", isLoading && "animate-spin")} />
            </Button>
          </div>

          {/* Today's Stats */}
          <div className="grid grid-cols-3 gap-3">
            <div className="text-center p-3 rounded-xl bg-slate-800/50 border border-slate-700/50">
              <p className="text-2xl font-bold text-cyan-400">{todayActivities.length}</p>
              <p className="text-xs text-slate-400">Today</p>
            </div>
            <div className="text-center p-3 rounded-xl bg-slate-800/50 border border-slate-700/50">
              <p className="text-2xl font-bold text-emerald-400">{completedToday}</p>
              <p className="text-xs text-slate-400">Completed</p>
            </div>
            <div className="text-center p-3 rounded-xl bg-slate-800/50 border border-slate-700/50">
              <p className="text-2xl font-bold text-amber-400">{pointsToday}</p>
              <p className="text-xs text-slate-400">Points</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Filters */}
      <div className="flex items-center gap-2">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setShowFilters(!showFilters)}
          className={cn("h-9 text-slate-300 hover:text-cyan-400 hover:bg-slate-800/50", showFilters && "bg-slate-800/50 text-cyan-400")}
        >
          <Filter className="h-4 w-4 mr-2" />
          Filter
        </Button>
        {showFilters && (
          <div className="flex gap-1 overflow-x-auto">
            {(["all", "pee", "poop", "completed", "cancelled"] as FilterType[]).map((f) => (
              <Button
                key={f}
                variant={filter === f ? "default" : "outline"}
                size="sm"
                onClick={() => setFilter(f)}
                className={cn(
                  "h-8 text-xs capitalize",
                  filter === f 
                    ? "bg-cyan-500 text-slate-900 hover:bg-cyan-400" 
                    : "border-slate-700/50 bg-slate-800/30 text-slate-300 hover:border-cyan-500/50 hover:text-cyan-400"
                )}
              >
                {f}
              </Button>
            ))}
          </div>
        )}
      </div>

      {/* Activity List */}
      {Object.keys(groupedActivities).length === 0 ? (
        <Card className="glass-card border-slate-700/50">
          <CardContent className="p-8 text-center">
            <Calendar className="h-12 w-12 mx-auto text-slate-500 mb-3" />
            <h3 className="font-medium mb-1 text-slate-200">No Activity Yet</h3>
            <p className="text-sm text-slate-400">
              {childName}'s potty training activity will appear here.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {Object.entries(groupedActivities).map(([date, dayActivities]) => (
            <div key={date}>
              {/* Date Header */}
              <div className="flex items-center gap-2 mb-2">
                <Calendar className="h-4 w-4 text-slate-500" />
                <span className="text-sm font-medium text-slate-400">{date}</span>
                <span className="text-xs text-slate-500">({dayActivities.length} events)</span>
              </div>

              {/* Activities for this day */}
              <div className="space-y-2">
                {dayActivities.map((activity) => {
                  const typeConfig = REQUEST_TYPE_CONFIG[activity.request_type] || REQUEST_TYPE_CONFIG.custom
                  const statusConfig = STATUS_CONFIG[activity.status]
                  const TypeIcon = typeConfig.icon
                  const StatusIcon = statusConfig.icon
                  const responseDuration = getTimeDiff(activity.created_at, activity.completed_at)

                  return (
                    <Card 
                      key={activity.id} 
                      className={cn(
                        "glass-card border-slate-700/50 overflow-hidden",
                        activity.status === "completed" && "border-l-4 border-l-emerald-500"
                      )}
                    >
                      <CardContent className="p-3">
                        <div className="flex items-center gap-3">
                          {/* Type Icon */}
                          <div className={cn("h-10 w-10 rounded-full flex items-center justify-center", typeConfig.bgColor)}>
                            <TypeIcon className={cn("h-5 w-5", typeConfig.color)} />
                          </div>

                          {/* Details */}
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <span className="font-medium text-slate-200">{typeConfig.label}</span>
                              <span className={cn("text-xs flex items-center gap-1", statusConfig.color)}>
                                <StatusIcon className="h-3 w-3" />
                                {statusConfig.label}
                              </span>
                            </div>
                            <div className="flex items-center gap-2 text-xs text-slate-400">
                              <Clock className="h-3 w-3" />
                              {formatTime(activity.created_at)}
                              {responseDuration && (
                                <span className="text-emerald-400">
                                  (responded in {responseDuration})
                                </span>
                              )}
                            </div>
                          </div>

                          {/* Points */}
                          {activity.points_awarded > 0 && (
                            <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-amber-500/20 text-amber-400 text-sm font-medium">
                              <ThumbsUp className="h-3 w-3" />
                              +{activity.points_awarded}
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
