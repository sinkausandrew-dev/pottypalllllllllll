"use client"

import type React from "react"
import { useState, useRef } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import type { CustomButton } from "@/lib/types"
import { Plus, Trash2, ImageIcon, X, Camera, Pencil, Volume2, Zap } from "lucide-react"

interface CustomButtonsManagerProps {
  customButtons: CustomButton[]
  childId: string
  onButtonsChange: (buttons: CustomButton[]) => void
}

const COLOR_PRESETS = [
  { name: "Purple", value: "#9333ea" },
  { name: "Blue", value: "#3b82f6" },
  { name: "Cyan", value: "#06b6d4" },
  { name: "Green", value: "#22c55e" },
  { name: "Yellow", value: "#eab308" },
  { name: "Orange", value: "#f97316" },
  { name: "Red", value: "#ef4444" },
  { name: "Pink", value: "#ec4899" },
]

export function CustomButtonsManager({ customButtons, childId, onButtonsChange }: CustomButtonsManagerProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [isUploading, setIsUploading] = useState(false)
  const [imagePreview, setImagePreview] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  
  const [newButton, setNewButton] = useState({
    name: "",
    tts_message: "",
    color: "#9333ea",
    icon_url: "",
  })

  const [editingButton, setEditingButton] = useState<CustomButton | null>(null)
  const [editButton, setEditButton] = useState({
    name: "",
    tts_message: "",
    color: "#9333ea",
    icon_url: "",
  })
  const [editImagePreview, setEditImagePreview] = useState<string | null>(null)
  const editFileInputRef = useRef<HTMLInputElement>(null)

  const resetForm = () => {
    setNewButton({ name: "", tts_message: "", color: "#9333ea", icon_url: "" })
    setImagePreview(null)
  }

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onloadend = () => {
      setImagePreview(reader.result as string)
    }
    reader.readAsDataURL(file)

    setIsUploading(true)
    try {
      const formData = new FormData()
      formData.append("file", file)

      const response = await fetch("/api/upload-reward-image", {
        method: "POST",
        body: formData,
      })

      const data = await response.json()
      if (data.url) {
        setNewButton({ ...newButton, icon_url: data.url })
      }
    } catch (error) {
      console.error("Failed to upload image:", error)
      setImagePreview(null)
    } finally {
      setIsUploading(false)
    }
  }

  const clearImage = () => {
    setImagePreview(null)
    setNewButton({ ...newButton, icon_url: "" })
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const handleAddButton = async () => {
    if (!newButton.name.trim() || !newButton.tts_message.trim()) return
    setIsLoading(true)

    const supabase = createClient()

    try {
      const { data, error } = await supabase
        .from("custom_buttons")
        .insert({
          child_id: childId,
          name: newButton.name,
          tts_message: newButton.tts_message,
          color: newButton.color,
          icon_url: newButton.icon_url || null,
          display_order: customButtons.length,
        })
        .select()
        .single()

      if (error) throw error

      onButtonsChange([...customButtons, data])
      resetForm()
      setIsOpen(false)
    } catch (error) {
      console.error("Failed to add button:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleToggleActive = async (button: CustomButton) => {
    const supabase = createClient()

    try {
      await supabase.from("custom_buttons").update({ is_active: !button.is_active }).eq("id", button.id)
      onButtonsChange(customButtons.map((b) => (b.id === button.id ? { ...b, is_active: !b.is_active } : b)))
    } catch (error) {
      console.error("Failed to toggle button:", error)
    }
  }

  const handleDeleteButton = async (buttonId: string) => {
    const supabase = createClient()

    try {
      await supabase.from("custom_buttons").delete().eq("id", buttonId)
      onButtonsChange(customButtons.filter((b) => b.id !== buttonId))
    } catch (error) {
      console.error("Failed to delete button:", error)
    }
  }

  const handleEditButton = (button: CustomButton) => {
    setEditingButton(button)
    setEditButton({
      name: button.name,
      tts_message: button.tts_message,
      color: button.color,
      icon_url: button.icon_url || "",
    })
    setEditImagePreview(button.icon_url || null)
  }

  const handleEditImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onloadend = () => {
      setEditImagePreview(reader.result as string)
    }
    reader.readAsDataURL(file)

    setIsUploading(true)
    try {
      const formData = new FormData()
      formData.append("file", file)

      const response = await fetch("/api/upload-reward-image", {
        method: "POST",
        body: formData,
      })

      const data = await response.json()
      if (data.url) {
        setEditButton({ ...editButton, icon_url: data.url })
      }
    } catch (error) {
      console.error("Failed to upload image:", error)
      setEditImagePreview(null)
    } finally {
      setIsUploading(false)
    }
  }

  const clearEditImage = () => {
    setEditImagePreview(null)
    setEditButton({ ...editButton, icon_url: "" })
    if (editFileInputRef.current) {
      editFileInputRef.current.value = ""
    }
  }

  const handleUpdateButton = async () => {
    if (!editingButton || !editButton.name.trim() || !editButton.tts_message.trim()) return
    setIsLoading(true)

    const supabase = createClient()

    try {
      const { data, error } = await supabase
        .from("custom_buttons")
        .update({
          name: editButton.name,
          tts_message: editButton.tts_message,
          color: editButton.color,
          icon_url: editButton.icon_url || null,
        })
        .eq("id", editingButton.id)
        .select()
        .single()

      if (error) throw error

      onButtonsChange(customButtons.map((b) => (b.id === editingButton.id ? data : b)))
      setEditingButton(null)
      setEditButton({ name: "", tts_message: "", color: "#9333ea", icon_url: "" })
      setEditImagePreview(null)
    } catch (error) {
      console.error("Failed to update button:", error)
    } finally {
      setIsLoading(false)
    }
  }

  // Test TTS
  const testTTS = (message: string) => {
    if ("speechSynthesis" in window) {
      speechSynthesis.cancel()
      const utterance = new SpeechSynthesisUtterance(message)
      utterance.rate = 0.9
      utterance.pitch = 1.15
      speechSynthesis.speak(utterance)
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold">Custom Buttons</h2>
          <p className="text-sm text-muted-foreground">Add custom call-to-action buttons for your child</p>
        </div>
        <Dialog
          open={isOpen}
          onOpenChange={(open) => {
            setIsOpen(open)
            if (!open) resetForm()
          }}
        >
          <DialogTrigger asChild>
            <Button size="sm" className="bg-gradient-to-r from-[var(--space-purple)] to-[var(--space-blue)]">
              <Plus className="mr-1 h-4 w-4" />
              Add Button
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Create Custom Button</DialogTitle>
            </DialogHeader>

            <div className="space-y-4 py-4">
              {/* Button Name */}
              <div className="space-y-2">
                <Label htmlFor="name">Button Name (shown to child)</Label>
                <Input
                  id="name"
                  placeholder="e.g., HELP, WATER, SNACK"
                  value={newButton.name}
                  onChange={(e) => setNewButton({ ...newButton, name: e.target.value })}
                  className="h-12 text-base uppercase"
                  maxLength={12}
                />
                <p className="text-xs text-muted-foreground">Keep it short - max 12 characters</p>
              </div>

              {/* TTS Message */}
              <div className="space-y-2">
                <Label htmlFor="tts_message" className="flex items-center gap-2">
                  <Volume2 className="h-4 w-4" />
                  Voice Message
                </Label>
                <div className="flex gap-2">
                  <Input
                    id="tts_message"
                    placeholder="e.g., Great job! Someone is coming to help!"
                    value={newButton.tts_message}
                    onChange={(e) => setNewButton({ ...newButton, tts_message: e.target.value })}
                    className="flex-1"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    size="icon"
                    onClick={() => testTTS(newButton.tts_message)}
                    disabled={!newButton.tts_message}
                    className="bg-transparent"
                  >
                    <Volume2 className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">This message plays when your child presses the button</p>
              </div>

              {/* Color Picker */}
              <div className="space-y-2">
                <Label>Button Color</Label>
                <div className="grid grid-cols-4 gap-2">
                  {COLOR_PRESETS.map((preset) => (
                    <button
                      key={preset.value}
                      type="button"
                      onClick={() => setNewButton({ ...newButton, color: preset.value })}
                      className={`h-12 rounded-xl transition-all ${
                        newButton.color === preset.value 
                          ? "ring-2 ring-white ring-offset-2 ring-offset-background scale-105" 
                          : "hover:scale-105"
                      }`}
                      style={{ backgroundColor: preset.value }}
                    >
                      <span className="sr-only">{preset.name}</span>
                    </button>
                  ))}
                </div>
                <div className="flex items-center gap-2 mt-2">
                  <Label htmlFor="custom-color" className="text-xs">Custom:</Label>
                  <input
                    id="custom-color"
                    type="color"
                    value={newButton.color}
                    onChange={(e) => setNewButton({ ...newButton, color: e.target.value })}
                    className="w-12 h-8 rounded cursor-pointer"
                  />
                </div>
              </div>

              {/* Image Upload */}
              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  <Camera className="h-4 w-4" />
                  Button Icon (optional)
                </Label>
                {imagePreview ? (
                  <div className="relative w-24 h-24 mx-auto rounded-xl overflow-hidden border border-border">
                    <img
                      src={imagePreview || "/placeholder.svg"}
                      alt="Button icon preview"
                      className="w-full h-full object-cover"
                    />
                    <Button
                      type="button"
                      variant="destructive"
                      size="icon"
                      className="absolute top-1 right-1 h-6 w-6"
                      onClick={clearImage}
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isUploading}
                    className="flex flex-col items-center justify-center w-24 h-24 mx-auto rounded-xl border-2 border-dashed border-border hover:border-[var(--space-purple)] transition-colors bg-muted/30"
                  >
                    {isUploading ? (
                      <div className="animate-spin h-6 w-6 border-2 border-[var(--space-purple)] border-t-transparent rounded-full" />
                    ) : (
                      <>
                        <ImageIcon className="h-8 w-8 text-muted-foreground mb-1" />
                        <span className="text-xs text-muted-foreground">Add icon</span>
                      </>
                    )}
                  </button>
                )}
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
              </div>

              {/* Preview */}
              <div className="space-y-2">
                <Label>Preview</Label>
                <div className="flex justify-center">
                  <div
                    className="w-32 h-24 rounded-2xl flex flex-col items-center justify-center gap-2 text-white font-bold"
                    style={{ 
                      backgroundColor: newButton.color,
                      boxShadow: `0 8px 24px ${newButton.color}60`
                    }}
                  >
                    {imagePreview ? (
                      <img src={imagePreview || "/placeholder.svg"} alt="" className="h-10 w-10 object-contain" />
                    ) : (
                      <Zap className="h-10 w-10" />
                    )}
                    <span className="text-sm uppercase">{newButton.name || "NAME"}</span>
                  </div>
                </div>
              </div>

              <Button
                onClick={handleAddButton}
                disabled={isLoading || !newButton.name.trim() || !newButton.tts_message.trim() || isUploading}
                className="w-full bg-gradient-to-r from-[var(--space-purple)] to-[var(--space-blue)]"
              >
                {isLoading ? "Creating..." : "Create Button"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Edit Button Dialog */}
      <Dialog open={!!editingButton} onOpenChange={(open) => !open && setEditingButton(null)}>
        <DialogContent className="sm:max-w-md max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Button</DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-4">
            {/* Button Name */}
            <div className="space-y-2">
              <Label htmlFor="edit-name">Button Name</Label>
              <Input
                id="edit-name"
                placeholder="e.g., HELP"
                value={editButton.name}
                onChange={(e) => setEditButton({ ...editButton, name: e.target.value })}
                className="h-12 text-base uppercase"
                maxLength={12}
              />
            </div>

            {/* TTS Message */}
            <div className="space-y-2">
              <Label htmlFor="edit-tts" className="flex items-center gap-2">
                <Volume2 className="h-4 w-4" />
                Voice Message
              </Label>
              <div className="flex gap-2">
                <Input
                  id="edit-tts"
                  placeholder="e.g., Great job! Someone is coming to help!"
                  value={editButton.tts_message}
                  onChange={(e) => setEditButton({ ...editButton, tts_message: e.target.value })}
                  className="flex-1"
                />
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  onClick={() => testTTS(editButton.tts_message)}
                  disabled={!editButton.tts_message}
                  className="bg-transparent"
                >
                  <Volume2 className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Color Picker */}
            <div className="space-y-2">
              <Label>Button Color</Label>
              <div className="grid grid-cols-4 gap-2">
                {COLOR_PRESETS.map((preset) => (
                  <button
                    key={preset.value}
                    type="button"
                    onClick={() => setEditButton({ ...editButton, color: preset.value })}
                    className={`h-12 rounded-xl transition-all ${
                      editButton.color === preset.value 
                        ? "ring-2 ring-white ring-offset-2 ring-offset-background scale-105" 
                        : "hover:scale-105"
                    }`}
                    style={{ backgroundColor: preset.value }}
                  >
                    <span className="sr-only">{preset.name}</span>
                  </button>
                ))}
              </div>
              <div className="flex items-center gap-2 mt-2">
                <Label htmlFor="edit-custom-color" className="text-xs">Custom:</Label>
                <input
                  id="edit-custom-color"
                  type="color"
                  value={editButton.color}
                  onChange={(e) => setEditButton({ ...editButton, color: e.target.value })}
                  className="w-12 h-8 rounded cursor-pointer"
                />
              </div>
            </div>

            {/* Image Upload */}
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <Camera className="h-4 w-4" />
                Button Icon (optional)
              </Label>
              {editImagePreview ? (
                <div className="relative w-24 h-24 mx-auto rounded-xl overflow-hidden border border-border">
                  <img
                    src={editImagePreview || "/placeholder.svg"}
                    alt="Button icon preview"
                    className="w-full h-full object-cover"
                  />
                  <Button
                    type="button"
                    variant="destructive"
                    size="icon"
                    className="absolute top-1 right-1 h-6 w-6"
                    onClick={clearEditImage}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => editFileInputRef.current?.click()}
                  disabled={isUploading}
                  className="flex flex-col items-center justify-center w-24 h-24 mx-auto rounded-xl border-2 border-dashed border-border hover:border-[var(--space-purple)] transition-colors bg-muted/30"
                >
                  {isUploading ? (
                    <div className="animate-spin h-6 w-6 border-2 border-[var(--space-purple)] border-t-transparent rounded-full" />
                  ) : (
                    <>
                      <ImageIcon className="h-8 w-8 text-muted-foreground mb-1" />
                      <span className="text-xs text-muted-foreground">Add icon</span>
                    </>
                  )}
                </button>
              )}
              <input
                ref={editFileInputRef}
                type="file"
                accept="image/*"
                onChange={handleEditImageUpload}
                className="hidden"
              />
            </div>

            <div className="flex gap-3 pt-2">
              <Button
                variant="outline"
                onClick={() => setEditingButton(null)}
                className="flex-1 bg-transparent"
              >
                Cancel
              </Button>
              <Button
                onClick={handleUpdateButton}
                disabled={isLoading || !editButton.name.trim() || !editButton.tts_message.trim() || isUploading}
                className="flex-1 bg-gradient-to-r from-[var(--space-purple)] to-[var(--space-blue)]"
              >
                {isLoading ? "Saving..." : "Save Changes"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Buttons List */}
      {customButtons.length === 0 ? (
        <Card className="border-border/50 bg-card/80">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Zap className="h-12 w-12 text-muted-foreground/50" />
            <p className="mt-4 text-center text-muted-foreground">No custom buttons yet</p>
            <p className="text-center text-sm text-muted-foreground/70">
              Add custom buttons for things like "Water", "Snack", or "Help"
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {customButtons.map((button) => (
            <Card key={button.id} className={`border-border/50 ${button.is_active ? "bg-card/80" : "bg-card/40 opacity-60"}`}>
              <CardContent className="p-4">
                <div className="flex items-center gap-4">
                  {/* Color preview */}
                  <div
                    className="flex h-14 w-14 items-center justify-center rounded-xl flex-shrink-0"
                    style={{ backgroundColor: button.color }}
                  >
                    {button.icon_url ? (
                      <img src={button.icon_url || "/placeholder.svg"} alt="" className="h-8 w-8 object-contain" />
                    ) : (
                      <Zap className="h-7 w-7 text-white" />
                    )}
                  </div>

                  <div className="flex-1 min-w-0">
                    <p className="font-bold uppercase truncate">{button.name}</p>
                    <p className="text-xs text-muted-foreground truncate">{button.tts_message}</p>
                  </div>

                  <div className="flex items-center gap-2 flex-shrink-0">
                    <Switch
                      checked={button.is_active}
                      onCheckedChange={() => handleToggleActive(button)}
                      aria-label={button.is_active ? "Disable button" : "Enable button"}
                    />
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleEditButton(button)}
                      className="h-9 w-9"
                    >
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleDeleteButton(button.id)}
                      className="h-9 w-9 text-destructive hover:text-destructive hover:bg-destructive/10"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
