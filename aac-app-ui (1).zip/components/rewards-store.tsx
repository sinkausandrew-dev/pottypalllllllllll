"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { StarField } from "@/components/star-field"
import { PointsDisplay } from "@/components/points-display"
import type { Reward } from "@/lib/types"
import { ArrowLeft, Gift, Star, Lock, Sparkles, Trophy } from "lucide-react"

interface RewardsStoreProps {
  childName: string
  totalPoints: number
  rewards: Reward[]
  childId: string
  userId: string
}

export function RewardsStore({ childName, totalPoints, rewards, childId, userId }: RewardsStoreProps) {
  const router = useRouter()
  const [points, setPoints] = useState(totalPoints)
  const [isRedeeming, setIsRedeeming] = useState(false)
  const [showCelebration, setShowCelebration] = useState(false)
  const [redeemedReward, setRedeemedReward] = useState<Reward | null>(null)
  // Sound toggle removed - no TTS in rewards

  // TTS removed - no narration for rewards navigation

  // Real-time points updates - subscribe to children table
  useEffect(() => {
    const supabase = createClient()

    const channel = supabase
      .channel(`points-updates-store-${childId}`)
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          schema: "public",
          table: "children",
          filter: `id=eq.${childId}`,
        },
        (payload) => {
          if (payload.new && typeof payload.new === "object" && "total_points" in payload.new) {
            setPoints(payload.new.total_points as number)
          }
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [childId])

  const handleRedeem = async (reward: Reward) => {
    if (points < reward.points_cost || isRedeeming) return

    setIsRedeeming(true)
    const supabase = createClient()

    try {
      await supabase.from("redeemed_rewards").insert({
        child_id: childId,
        profile_id: userId, // Keep for backward compatibility
        reward_id: reward.id,
        points_spent: reward.points_cost,
      })

      // Update points in children table
      await supabase
        .from("children")
        .update({ total_points: points - reward.points_cost })
        .eq("id", childId)

      setPoints(points - reward.points_cost)
      setRedeemedReward(reward)
      setShowCelebration(true)
      // No TTS - celebration is visual only
    } catch (error) {
      console.error("Failed to redeem reward:", error)
    } finally {
      setIsRedeeming(false)
    }
  }

  // Sort rewards by points (tier system)
  const sortedRewards = [...rewards].sort((a, b) => a.points_cost - b.points_cost)

  // Celebration screen - Futuristic theme
  if (showCelebration && redeemedReward) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900">
        <StarField />
        <div className="relative z-10 flex flex-col items-center gap-8 p-8 text-center">
          <div className="animate-bounce">
            {redeemedReward.image_url ? (
              <div className="h-40 w-40 rounded-3xl overflow-hidden border-4 border-cyan-400 shadow-2xl shadow-cyan-500/40">
                <img
                  src={redeemedReward.image_url || "/placeholder.svg"}
                  alt={redeemedReward.name}
                  className="h-full w-full object-cover"
                />
              </div>
            ) : (
              <div className="flex h-40 w-40 items-center justify-center rounded-3xl bg-gradient-to-br from-cyan-500 to-cyan-400 shadow-2xl shadow-cyan-500/40">
                <Trophy className="h-20 w-20 text-slate-900" />
              </div>
            )}
          </div>
          <div className="space-y-3">
            <h1 className="text-5xl font-bold text-cyan-400 text-glow-cyan">YOU GOT IT!</h1>
            <p className="text-3xl font-bold text-slate-100">{redeemedReward.name}</p>
            {redeemedReward.description && (
              <p className="text-xl text-slate-400">{redeemedReward.description}</p>
            )}
          </div>
          <Button
            onClick={() => {
              setShowCelebration(false)
              setRedeemedReward(null)
            }}
            className="h-16 w-full max-w-xs text-xl font-bold bg-gradient-to-r from-cyan-500 to-cyan-400 text-slate-900 hover:from-cyan-400 hover:to-cyan-300 shadow-xl shadow-cyan-500/30"
          >
            AWESOME!
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div>
      <main className="relative min-h-svh pb-8 bg-slate-900">
        <StarField />

        {/* Header - Glassmorphism */}
        <header className="sticky top-0 z-20 glass border-b border-slate-700/50">
          <div className="flex items-center justify-between p-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => router.push(`/child?childId=${childId}`)}
              className="h-14 w-14 rounded-2xl bg-slate-800/50 border border-slate-700/50 hover:border-cyan-500/50 hover:text-cyan-400 transition-all"
            >
              <ArrowLeft className="h-7 w-7" />
              <span className="sr-only">Go back</span>
            </Button>

            <h1 className="text-2xl font-bold flex items-center gap-2 text-slate-100">
              <Trophy className="h-7 w-7 text-cyan-400" />
              My Rewards
            </h1>
          </div>
        </header>

        {/* Points Banner - Glassmorphism */}
        <div className="relative z-10 flex justify-center p-6">
          <div className="flex flex-col items-center gap-2 rounded-3xl glass-card px-8 py-5 glow-cyan">
            <span className="text-lg text-slate-400 font-medium">Your Points</span>
            <PointsDisplay points={points} size="lg" />
          </div>
        </div>

        {/* Rewards List */}
        <div className="relative z-10 px-4 space-y-4">
          {sortedRewards.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <Gift className="h-24 w-24 text-slate-600 mb-4" />
              <p className="text-2xl font-bold text-slate-400">No Rewards Yet</p>
              <p className="text-lg text-slate-500 mt-2">Ask a grown-up to add some!</p>
            </div>
          ) : (
            sortedRewards.map((reward, index) => {
              const canAfford = points >= reward.points_cost
              const progress = Math.min((points / reward.points_cost) * 100, 100)
              const pointsNeeded = reward.points_cost - points

              return (
                <button
                  key={reward.id}
                  onClick={() => canAfford && handleRedeem(reward)}
                  disabled={!canAfford || isRedeeming}
                  className={`relative w-full rounded-3xl p-5 text-left transition-all duration-200 ${
                    canAfford
                      ? "glass-card border-2 border-cyan-500/50 hover:scale-[1.02] active:scale-[0.98] glow-cyan"
                      : "bg-slate-800/30 border border-slate-700/50 opacity-80"
                  }`}
                >
                  <div className="flex items-center gap-5">
                    {/* Reward Image/Icon */}
                    <div className={`relative flex-shrink-0 ${canAfford ? "" : "grayscale"}`}>
                      {reward.image_url ? (
                        <div className={`h-24 w-24 rounded-2xl overflow-hidden border-2 ${canAfford ? "border-cyan-500/50" : "border-slate-700/50"}`}>
                          <img
                            src={reward.image_url || "/placeholder.svg"}
                            alt={reward.name}
                            className="h-full w-full object-cover"
                          />
                        </div>
                      ) : (
                        <div
                          className={`flex h-24 w-24 items-center justify-center rounded-2xl ${
                            canAfford ? "bg-gradient-to-br from-cyan-500 to-cyan-400" : "bg-slate-800"
                          }`}
                        >
                          <Gift className={`h-12 w-12 ${canAfford ? "text-slate-900" : "text-slate-500"}`} />
                        </div>
                      )}

                      {/* Lock icon if can't afford */}
                      {!canAfford && (
                        <div className="absolute inset-0 flex items-center justify-center rounded-2xl bg-slate-900/60">
                          <Lock className="h-10 w-10 text-slate-400" />
                        </div>
                      )}

                      {/* Sparkle if can afford */}
                      {canAfford && (
                        <Sparkles className="absolute -top-2 -right-2 h-8 w-8 text-cyan-400 animate-pulse" />
                      )}
                    </div>

                    {/* Reward Info */}
                    <div className="flex-1 min-w-0">
                      <h3 className="text-2xl font-bold truncate text-slate-100">{reward.name}</h3>
                      {reward.description && (
                        <p className="text-base text-slate-400 truncate mt-1">{reward.description}</p>
                      )}

                      {/* Points Cost */}
                      <div className="flex items-center gap-2 mt-3">
                        <Star className="h-6 w-6 text-cyan-400 fill-current" />
                        <span className="text-xl font-bold text-cyan-400">{reward.points_cost}</span>
                        <span className="text-base text-slate-400">points</span>
                      </div>

                      {/* Progress Bar */}
                      {!canAfford && (
                        <div className="mt-3">
                          <div className="h-3 w-full rounded-full bg-slate-800 overflow-hidden">
                            <div
                              className="h-full rounded-full bg-gradient-to-r from-cyan-500 to-cyan-400 transition-all duration-500"
                              style={{ width: `${progress}%` }}
                            />
                          </div>
                          <p className="text-sm text-slate-400 mt-1">Need {pointsNeeded} more!</p>
                        </div>
                      )}
                    </div>

                    {/* Get Button */}
                    {canAfford && (
                      <div className="flex-shrink-0">
                        <div className="h-16 w-16 rounded-2xl bg-gradient-to-br from-cyan-500 to-cyan-400 flex items-center justify-center text-slate-900 font-bold text-lg shadow-lg shadow-cyan-500/30">
                          GET!
                        </div>
                      </div>
                    )}
                  </div>
                </button>
              )
            })
          )}
        </div>
      </main>
    </div>
  )
}
