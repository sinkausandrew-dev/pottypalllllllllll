"use client"

import { Button } from "@/components/ui/button"
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area"
import type { AACGrammarHelper, TierKey } from "@/lib/types"

interface GrammarHelpersProps {
  helpers: AACGrammarHelper[]
  currentTierKey: TierKey
  onHelperSelect: (helper: AACGrammarHelper) => void
  disabled?: boolean
}

// Compare tier keys for unlocking
const TIER_ORDER: TierKey[] = ['T0', 'T1', 'T2', 'T3', 'T4', 'T5']

function isTierUnlocked(currentTier: TierKey, requiredTier: TierKey): boolean {
  return TIER_ORDER.indexOf(currentTier) >= TIER_ORDER.indexOf(requiredTier)
}

// Group helpers by type for display
function groupHelpersByType(helpers: AACGrammarHelper[]) {
  const groups: Record<string, AACGrammarHelper[]> = {
    frame: [],
    connector: [],
    suffix: [],
    prefix: [],
  }
  
  for (const helper of helpers) {
    if (groups[helper.helper_type]) {
      groups[helper.helper_type].push(helper)
    }
  }
  
  return groups
}

export function GrammarHelpers({
  helpers,
  currentTierKey,
  onHelperSelect,
  disabled = false,
}: GrammarHelpersProps) {
  // Filter to only show unlocked helpers
  const unlockedHelpers = helpers.filter(h => 
    h.is_active && isTierUnlocked(currentTierKey, h.min_tier_key)
  )

  if (unlockedHelpers.length === 0) {
    return null
  }

  const grouped = groupHelpersByType(unlockedHelpers)

  // Color mapping for helper types
  const typeColors: Record<string, string> = {
    frame: "bg-blue-500 hover:bg-blue-600",
    connector: "bg-emerald-500 hover:bg-emerald-600",
    suffix: "bg-purple-500 hover:bg-purple-600",
    prefix: "bg-pink-500 hover:bg-pink-600",
  }

  return (
    <div className="bg-muted/30 border-b border-border px-3 py-2">
      <ScrollArea className="w-full">
        <div className="flex gap-2 pb-1">
          {/* Frames first (I want, I feel, etc.) */}
          {grouped.frame.map((helper) => (
            <Button
              key={helper.id}
              variant="secondary"
              size="sm"
              onClick={() => onHelperSelect(helper)}
              disabled={disabled}
              className={`
                min-h-[36px] px-3 text-white whitespace-nowrap
                ${typeColors.frame}
              `}
            >
              {helper.display_name}
            </Button>
          ))}

          {/* Connectors (because, and, then) */}
          {grouped.connector.map((helper) => (
            <Button
              key={helper.id}
              variant="secondary"
              size="sm"
              onClick={() => onHelperSelect(helper)}
              disabled={disabled}
              className={`
                min-h-[36px] px-3 text-white whitespace-nowrap
                ${typeColors.connector}
              `}
            >
              {helper.display_name}
            </Button>
          ))}

          {/* Suffixes (-ed, +s) */}
          {grouped.suffix.map((helper) => (
            <Button
              key={helper.id}
              variant="secondary"
              size="sm"
              onClick={() => onHelperSelect(helper)}
              disabled={disabled}
              className={`
                min-h-[36px] px-3 text-white whitespace-nowrap
                ${typeColors.suffix}
              `}
            >
              {helper.display_name}
            </Button>
          ))}

          {/* Prefixes */}
          {grouped.prefix.map((helper) => (
            <Button
              key={helper.id}
              variant="secondary"
              size="sm"
              onClick={() => onHelperSelect(helper)}
              disabled={disabled}
              className={`
                min-h-[36px] px-3 text-white whitespace-nowrap
                ${typeColors.prefix}
              `}
            >
              {helper.display_name}
            </Button>
          ))}
        </div>
        <ScrollBar orientation="horizontal" />
      </ScrollArea>
    </div>
  )
}
