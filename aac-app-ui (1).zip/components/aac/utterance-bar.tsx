"use client"

import { Button } from "@/components/ui/button"
import { Volume2, Trash2, Delete, Send } from "lucide-react"
import type { UtteranceToken } from "@/lib/types"

interface UtteranceBarProps {
  tokens: UtteranceToken[]
  onSpeak: () => void
  onClear: () => void
  onBackspace: () => void
  onSend?: () => void // Optional for communicate mode
  onRemoveToken?: (tokenId: string) => void
  isSpeaking?: boolean
  isSending?: boolean
  showSendButton?: boolean
  disabled?: boolean
}

export function UtteranceBar({
  tokens,
  onSpeak,
  onClear,
  onBackspace,
  onSend,
  onRemoveToken,
  isSpeaking = false,
  isSending = false,
  showSendButton = false,
  disabled = false,
}: UtteranceBarProps) {
  const utteranceText = tokens.map(t => t.text).join(" ")
  const hasTokens = tokens.length > 0

  return (
    <div className="bg-background/95 backdrop-blur-sm border-b border-border p-3 space-y-2">
      {/* Token display area */}
      <div 
        className="min-h-[52px] bg-muted/50 rounded-lg p-2 flex flex-wrap gap-1.5 items-center"
        role="textbox"
        aria-label="Utterance being built"
      >
        {tokens.length === 0 ? (
          <span className="text-muted-foreground text-sm px-2">
            Tap words to build a sentence...
          </span>
        ) : (
          tokens.map((token) => (
            <button
              key={token.id}
              onClick={() => onRemoveToken?.(token.id)}
              className={`
                px-3 py-1.5 rounded-full text-sm font-medium transition-all
                hover:opacity-80 active:scale-95
                ${token.is_grammar_helper 
                  ? "bg-amber-500 text-white" 
                  : "bg-primary text-primary-foreground"
                }
              `}
              aria-label={`Remove ${token.text}`}
            >
              {token.text}
            </button>
          ))
        )}
      </div>

      {/* Action buttons */}
      <div className="flex gap-2">
        {/* Clear button */}
        <Button
          variant="outline"
          size="sm"
          onClick={onClear}
          disabled={!hasTokens || disabled}
          className="bg-transparent min-h-[44px] px-3"
          aria-label="Clear all"
        >
          <Trash2 className="h-4 w-4" />
        </Button>

        {/* Backspace button */}
        <Button
          variant="outline"
          size="sm"
          onClick={onBackspace}
          disabled={!hasTokens || disabled}
          className="bg-transparent min-h-[44px] px-3"
          aria-label="Remove last word"
        >
          <Delete className="h-4 w-4" />
        </Button>

        {/* Spacer */}
        <div className="flex-1" />

        {/* Speak button */}
        <Button
          variant="default"
          size="sm"
          onClick={onSpeak}
          disabled={!hasTokens || disabled || isSpeaking}
          className={`min-h-[44px] px-6 ${isSpeaking ? "animate-pulse" : ""}`}
          aria-label="Speak utterance"
        >
          <Volume2 className={`h-4 w-4 mr-2 ${isSpeaking ? "animate-bounce" : ""}`} />
          {isSpeaking ? "Speaking..." : "Speak"}
        </Button>

        {/* Send button (for communicate mode) */}
        {showSendButton && onSend && (
          <Button
            variant="default"
            size="sm"
            onClick={onSend}
            disabled={!hasTokens || disabled || isSending}
            className="min-h-[44px] px-6 bg-amber-500 hover:bg-amber-600"
            aria-label="Send to caregiver"
          >
            <Send className={`h-4 w-4 mr-2 ${isSending ? "animate-pulse" : ""}`} />
            {isSending ? "Sending..." : "Send"}
          </Button>
        )}
      </div>

      {/* Screen reader announcement */}
      <div className="sr-only" aria-live="polite">
        {utteranceText || "Utterance is empty"}
      </div>
    </div>
  )
}
