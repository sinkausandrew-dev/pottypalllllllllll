"use client"

import React, { useState, useEffect, useMemo } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { 
  MessageCircle, Droplet, Star, Heart, Hand, LifeBuoy, 
  AlertCircle, Droplets, Sparkles, AlertTriangle, Thermometer,
  Volume2, X, Folder, Home as HomeIcon, Lightbulb, ArrowLeft,
  Smile, Frown, Moon, Flame, ThumbsUp, ThumbsDown, CheckCircle,
  PlusCircle, Octagon, ArrowRight, RefreshCw, Trophy, Award,
  PartyPopper, Utensils, CloudRain, Check, Circle
} from "lucide-react"
import type { VocabularyWord, VocabularyCategory, UtteranceToken, GridSize } from "@/lib/types"
import { getPredictedWords, getQuickPhrases, type PredictedWord } from "@/lib/aac-word-predictions"

// Expanded icon mapping
const ICON_MAP: Record<string, React.ComponentType<{ className?: string }>> = {
  "message-circle": MessageCircle,
  "droplet": Droplet,
  "droplets": Droplets,
  "star": Star,
  "heart": Heart,
  "hand": Hand,
  "life-buoy": LifeBuoy,
  "alert-circle": AlertCircle,
  "sparkles": Sparkles,
  "alert-triangle": AlertTriangle,
  "thermometer": Thermometer,
  "folder": Folder,
  "home": HomeIcon,
  "smile": Smile,
  "frown": Frown,
  "moon": Moon,
  "flame": Flame,
  "thumbs-up": ThumbsUp,
  "thumbs-down": ThumbsDown,
  "check-circle": CheckCircle,
  "plus-circle": PlusCircle,
  "octagon": Octagon,
  "arrow-right": ArrowRight,
  "refresh-cw": RefreshCw,
  "trophy": Trophy,
  "award": Award,
  "party-popper": PartyPopper,
  "utensils": Utensils,
  "cloud-rain": CloudRain,
  "check": Check,
  "circle": Circle,
}

interface LAMPGridProps {
  words: VocabularyWord[]
  categories: VocabularyCategory[]
  gridSize: GridSize
  currentUtterance: UtteranceToken[]
  onWordTap: (word: VocabularyWord) => void
  onWordLongPress?: (word: VocabularyWord) => void
  onQuickPhraseTap?: (wordIds: string[]) => void
  speakingWordId?: string | null
  recentlyUsedWordIds?: string[]
  showPredictions?: boolean
}

export function LAMPGrid({
  words,
  categories,
  gridSize,
  currentUtterance,
  onWordTap,
  onWordLongPress,
  onQuickPhraseTap,
  speakingWordId,
  recentlyUsedWordIds = [],
  showPredictions = true,
}: LAMPGridProps) {
  const [selectedCategory, setSelectedCategory] = useState<VocabularyCategory | null>(null)
  const [longPressTimer, setLongPressTimer] = useState<NodeJS.Timeout | null>(null)
  const [showQuickPhrases, setShowQuickPhrases] = useState(false)

  // Calculate grid columns based on size
  const gridCols = gridSize <= 20 ? 4 : gridSize <= 28 ? 4 : gridSize <= 40 ? 5 : 6

  // Get predicted words based on current utterance
  const predictions = useMemo(() => {
    if (!showPredictions) return []
    
    const tokens = currentUtterance.map(t => ({ 
      text: t.text, 
      word_id: t.word_id 
    }))
    
    return getPredictedWords(tokens, words, recentlyUsedWordIds, 6)
  }, [currentUtterance, words, recentlyUsedWordIds, showPredictions])

  // Get quick phrases
  const quickPhrases = useMemo(() => {
    return getQuickPhrases(words)
  }, [words])

  // Handle touch start for long press
  const handleTouchStart = (word: VocabularyWord) => {
    if (onWordLongPress) {
      const timer = setTimeout(() => {
        onWordLongPress(word)
      }, 500)
      setLongPressTimer(timer)
    }
  }

  // Handle touch end
  const handleTouchEnd = () => {
    if (longPressTimer) {
      clearTimeout(longPressTimer)
      setLongPressTimer(null)
    }
  }

  // Get words for current view
  const getDisplayWords = (): VocabularyWord[] => {
    if (selectedCategory) {
      return words.filter(w => w.category_id === selectedCategory.id)
    }
    // Show all words for home view, sorted by display order
    return words.sort((a, b) => a.display_order - b.display_order)
  }

  // Render a word button
  const renderWordButton = (
    word: VocabularyWord, 
    size: 'normal' | 'small' | 'prediction' = 'normal',
    isPrediction: boolean = false,
    predictionReason?: string
  ) => {
    const isSpeaking = speakingWordId === word.id
    const IconComponent = word.icon ? ICON_MAP[word.icon] : MessageCircle

    const sizeClasses = {
      normal: "aspect-square min-h-[72px]",
      small: "aspect-square min-h-[60px]",
      prediction: "h-16 px-3 min-w-[80px]",
    }

    return (
      <Card
        key={word.id}
        className={`
          cursor-pointer transition-all duration-150
          hover:scale-105 active:scale-95 relative
          ${sizeClasses[size]}
          ${isSpeaking ? "ring-4 ring-foreground ring-offset-2 scale-105" : ""}
          ${isPrediction ? "border-2 border-dashed border-foreground/30" : ""}
        `}
        style={{ backgroundColor: word.color || "#6366f1" }}
        onClick={() => onWordTap(word)}
        onTouchStart={() => handleTouchStart(word)}
        onTouchEnd={handleTouchEnd}
        onMouseDown={() => handleTouchStart(word)}
        onMouseUp={handleTouchEnd}
        onMouseLeave={handleTouchEnd}
      >
        <div className="h-full flex flex-col items-center justify-center text-white p-1.5 relative">
          {IconComponent && (
            <IconComponent className={size === 'prediction' ? "h-5 w-5 mb-0.5" : "h-6 w-6 mb-1"} />
          )}
          <span className={`font-semibold text-center leading-tight line-clamp-2 ${
            size === 'prediction' ? 'text-xs' : 'text-sm'
          }`}>
            {word.word}
          </span>
          
          {/* Prediction indicator */}
          {isPrediction && predictionReason && (
            <div className="absolute -top-1 -right-1">
              <div className="bg-amber-400 rounded-full p-0.5">
                <Lightbulb className="h-3 w-3 text-amber-900" />
              </div>
            </div>
          )}
          
          {/* Speaking indicator */}
          {isSpeaking && (
            <div className="absolute inset-0 bg-white/20 rounded-lg flex items-center justify-center">
              <Volume2 className="h-6 w-6 text-white animate-pulse" />
            </div>
          )}
          
          {/* Ping indicator */}
          {word.is_ping_enabled && !isPrediction && (
            <div className="absolute bottom-1 right-1">
              <div className="h-2 w-2 bg-amber-400 rounded-full" />
            </div>
          )}
        </div>
      </Card>
    )
  }

  // Render a category button
  const renderCategoryButton = (category: VocabularyCategory) => {
    const IconComponent = ICON_MAP[category.icon] || Folder
    const wordCount = words.filter(w => w.category_id === category.id).length

    return (
      <Card
        key={category.id}
        className="aspect-square cursor-pointer transition-all duration-150 hover:scale-105 active:scale-95 min-h-[72px]"
        style={{ backgroundColor: category.color }}
        onClick={() => setSelectedCategory(category)}
      >
        <div className="h-full flex flex-col items-center justify-center text-white p-1.5">
          <IconComponent className="h-6 w-6 mb-1" />
          <span className="text-sm font-semibold text-center leading-tight line-clamp-1">
            {category.name}
          </span>
          <span className="text-xs opacity-80 mt-0.5">{wordCount} words</span>
        </div>
      </Card>
    )
  }

  const displayWords = getDisplayWords()

  return (
    <div className="flex flex-col h-full">
      {/* Predictions Row - Shows suggested next words */}
      {showPredictions && predictions.length > 0 && (
        <div className="bg-muted/30 border-b px-3 py-2">
          <div className="flex items-center gap-2 mb-2">
            <Lightbulb className="h-4 w-4 text-amber-500" />
            <span className="text-xs font-medium text-muted-foreground">
              {currentUtterance.length === 0 ? "Start with..." : "Next word..."}
            </span>
          </div>
          <ScrollArea className="w-full" orientation="horizontal">
            <div className="flex gap-2 pb-1">
              {predictions.map((pred) => (
                <div key={pred.word.id} className="flex-shrink-0">
                  {renderWordButton(pred.word, 'prediction', true, pred.reason)}
                </div>
              ))}
            </div>
          </ScrollArea>
        </div>
      )}

      {/* Quick Phrases Toggle (when utterance is empty) */}
      {currentUtterance.length === 0 && quickPhrases.length > 0 && (
        <div className="px-3 py-2 border-b">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowQuickPhrases(!showQuickPhrases)}
            className="text-xs w-full justify-start"
          >
            <Sparkles className="h-3 w-3 mr-2" />
            {showQuickPhrases ? "Hide" : "Show"} quick phrases
          </Button>
          
          {showQuickPhrases && (
            <div className="grid grid-cols-2 gap-2 mt-2">
              {quickPhrases.slice(0, 6).map((qp, idx) => (
                <Button
                  key={idx}
                  variant="outline"
                  size="sm"
                  onClick={() => onQuickPhraseTap?.(qp.wordIds)}
                  className="text-xs h-auto py-2 justify-start bg-transparent"
                >
                  {qp.phrase}
                </Button>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Category Header (when in a category) */}
      {selectedCategory && (
        <div 
          className="flex items-center gap-2 px-3 py-2 border-b"
          style={{ backgroundColor: `${selectedCategory.color}20` }}
        >
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setSelectedCategory(null)}
            className="h-8 w-8 p-0"
          >
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div className="flex items-center gap-2">
            {(() => {
              const IconComponent = ICON_MAP[selectedCategory.icon] || Folder
              return <IconComponent className="h-5 w-5" style={{ color: selectedCategory.color }} />
            })()}
            <span className="font-semibold">{selectedCategory.name}</span>
          </div>
          <Badge variant="secondary" className="ml-auto">
            {displayWords.length} words
          </Badge>
        </div>
      )}

      {/* Main Grid */}
      <ScrollArea className="flex-1">
        <div className="p-3">
          {!selectedCategory ? (
            // Home view: Categories + Core words mixed
            <div className="space-y-4">
              {/* Categories */}
              <div>
                <h3 className="text-xs font-semibold text-muted-foreground mb-2 px-1">
                  CATEGORIES
                </h3>
                <div 
                  className="grid gap-2"
                  style={{ gridTemplateColumns: `repeat(${Math.min(gridCols, 4)}, 1fr)` }}
                >
                  {categories.filter(c => c.is_active).map((category) =>
                    renderCategoryButton(category)
                  )}
                </div>
              </div>

              {/* Core/Favorite Words */}
              {words.filter(w => w.is_favorite).length > 0 && (
                <div>
                  <h3 className="text-xs font-semibold text-muted-foreground mb-2 px-1">
                    FAVORITES
                  </h3>
                  <div 
                    className="grid gap-2"
                    style={{ gridTemplateColumns: `repeat(${gridCols}, 1fr)` }}
                  >
                    {words.filter(w => w.is_favorite && w.is_active).map((word) =>
                      renderWordButton(word)
                    )}
                  </div>
                </div>
              )}

              {/* Recently Used */}
              {recentlyUsedWordIds.length > 0 && (
                <div>
                  <h3 className="text-xs font-semibold text-muted-foreground mb-2 px-1">
                    RECENTLY USED
                  </h3>
                  <div 
                    className="grid gap-2"
                    style={{ gridTemplateColumns: `repeat(${gridCols}, 1fr)` }}
                  >
                    {recentlyUsedWordIds.slice(0, 8).map((wordId) => {
                      const word = words.find(w => w.id === wordId)
                      if (!word) return null
                      return renderWordButton(word, 'small')
                    })}
                  </div>
                </div>
              )}
            </div>
          ) : (
            // Category view: All words in category
            <div 
              className="grid gap-2"
              style={{ gridTemplateColumns: `repeat(${gridCols}, 1fr)` }}
            >
              {displayWords.filter(w => w.is_active).map((word) =>
                renderWordButton(word)
              )}
            </div>
          )}
        </div>
      </ScrollArea>

      {/* Home Button (when in category) */}
      {selectedCategory && (
        <div className="p-3 border-t bg-muted/30">
          <Button
            variant="outline"
            size="lg"
            onClick={() => setSelectedCategory(null)}
            className="w-full min-h-[48px] bg-transparent"
          >
            <HomeIcon className="h-5 w-5 mr-2" />
            Back to Home
          </Button>
        </div>
      )}
    </div>
  )
}
