"use client"

import React from "react"
import { useState, useRef, useEffect, useCallback } from "react"
import { useChat } from "@ai-sdk/react"
import { DefaultChatTransport, type UIMessage } from "ai"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { 
  Send, X, Loader2, 
  Lightbulb, HelpCircle, Heart, BookOpen, PartyPopper, CheckCircle2,
  MessageCircle, Trash2, Sparkles
} from "lucide-react"

const SUGGESTED_QUESTIONS = [
  { icon: HelpCircle, text: "When is my child ready for potty training?" },
  { icon: Lightbulb, text: "Tips for dealing with accidents" },
  { icon: Heart, text: "How to stay patient during setbacks" },
  { icon: BookOpen, text: "Best reward strategies for toddlers" },
]

const CELEBRATION_PROMPTS = [
  { icon: PartyPopper, text: "Send a celebration for using the potty!" },
  { icon: PartyPopper, text: "Celebrate staying dry all morning!" },
]

interface AIAssistantProps {
  childId?: string
  childName?: string
  profileId: string
}

// Local storage key for chat history
const getChatStorageKey = (profileId: string) => `luca-chat-${profileId}`

export function AIAssistant({ childId, childName, profileId }: AIAssistantProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [input, setInput] = useState("")
  const scrollRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  
  // Load saved messages from localStorage
  const loadSavedMessages = useCallback(() => {
    if (typeof window === "undefined") return []
    try {
      const saved = localStorage.getItem(getChatStorageKey(profileId))
      if (saved) {
        return JSON.parse(saved) as UIMessage[]
      }
    } catch {
      // Invalid saved data
    }
    return []
  }, [profileId])
  
  const { messages, sendMessage, status, setMessages } = useChat({
    transport: new DefaultChatTransport({ 
      api: "/api/ai-assistant",
      prepareSendMessagesRequest: ({ id, messages }) => ({
        body: {
          messages,
          id,
          childId,
          childName,
        },
      }),
    }),
    initialMessages: loadSavedMessages(),
  })

  const isLoading = status === "streaming" || status === "submitted"

  // Save messages to localStorage when they change
  useEffect(() => {
    if (messages.length > 0) {
      try {
        localStorage.setItem(getChatStorageKey(profileId), JSON.stringify(messages))
      } catch {
        // Storage full or unavailable
      }
    }
  }, [messages, profileId])

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTo({
        top: scrollRef.current.scrollHeight,
        behavior: "smooth"
      })
    }
  }, [messages])
  
  // Focus input when opened
  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus()
    }
  }, [isOpen])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim() || isLoading) return
    sendMessage({ text: input })
    setInput("")
  }

  const handleSuggestedQuestion = (question: string) => {
    sendMessage({ text: question })
  }
  
  const handleClearHistory = () => {
    setMessages([])
    localStorage.removeItem(getChatStorageKey(profileId))
  }
  
  // Extract text from message parts
  const getMessageText = (message: UIMessage): string => {
    if (!message.parts || !Array.isArray(message.parts)) return ""
    return message.parts
      .filter((p): p is { type: "text"; text: string } => p.type === "text")
      .map((p) => p.text)
      .join("")
  }

  if (!isOpen) {
    return (
      <Button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-4 right-4 h-14 px-4 rounded-full shadow-lg bg-gradient-to-r from-cyan-500 to-cyan-400 hover:from-cyan-400 hover:to-cyan-300 text-slate-900 font-semibold z-50 flex items-center gap-2"
      >
        <div className="relative">
          <MessageCircle className="h-5 w-5" />
          <Sparkles className="h-3 w-3 absolute -top-1 -right-1 text-amber-400" />
        </div>
        <span>Ask Luca</span>
      </Button>
    )
  }

  return (
    <Card className="fixed inset-x-2 bottom-2 sm:inset-auto sm:bottom-4 sm:right-4 sm:w-[380px] h-[70vh] max-h-[520px] shadow-2xl border-slate-700/50 bg-slate-900/95 backdrop-blur-sm z-50 flex flex-col overflow-hidden rounded-2xl">
      <CardHeader className="pb-2 flex-shrink-0 border-b border-slate-800 bg-slate-900">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-gradient-to-br from-cyan-400 to-cyan-600 flex items-center justify-center shadow-lg shadow-cyan-500/30">
              <span className="text-lg font-bold text-slate-900">L</span>
            </div>
            <div>
              <h3 className="text-base font-semibold text-slate-100 flex items-center gap-1.5">
                Luca
                <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-400 font-medium">
                  Smart Helper
                </span>
              </h3>
              <p className="text-xs text-slate-400">Your potty training companion</p>
            </div>
          </div>
          <div className="flex items-center gap-1">
            {messages.length > 0 && (
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={handleClearHistory} 
                className="h-8 w-8 text-slate-400 hover:text-red-400 hover:bg-red-500/10"
                title="Clear chat history"
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            )}
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => setIsOpen(false)} 
              className="h-8 w-8 text-slate-400 hover:text-slate-200"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="flex-1 flex flex-col p-0 min-h-0">
        <div 
          ref={scrollRef}
          className="flex-1 overflow-y-auto px-4 scrollbar-thin scrollbar-thumb-slate-700 scrollbar-track-transparent"
        >
          <div className="space-y-4 py-4">
            {messages.length === 0 ? (
              <div className="space-y-4">
                <div className="text-center py-6">
                  <div className="h-16 w-16 rounded-full bg-gradient-to-br from-cyan-400 to-cyan-600 flex items-center justify-center mx-auto mb-3 shadow-lg shadow-cyan-500/30">
                    <span className="text-2xl font-bold text-slate-900">L</span>
                  </div>
                  <h3 className="font-semibold text-slate-100">Hey there! I&apos;m Luca</h3>
                  <p className="text-sm text-slate-400 mt-1 max-w-[280px] mx-auto">
                    Your friendly guide for all things potty training. Ask me anything!
                  </p>
                </div>
                
                {/* Celebration quick actions when child is selected */}
                {childId && childName && (
                  <div className="space-y-2 mb-4">
                    <p className="text-xs text-slate-500 font-medium px-1">Quick celebrations for {childName}:</p>
                    {CELEBRATION_PROMPTS.map((q, i) => (
                      <button
                        key={`celebration-${i}`}
                        type="button"
                        onClick={() => handleSuggestedQuestion(q.text)}
                        className="w-full flex items-center gap-2 p-3 text-left text-sm rounded-lg bg-gradient-to-r from-amber-500/10 to-orange-500/10 border border-amber-500/20 hover:border-amber-500/40 text-slate-200 transition-colors"
                      >
                        <q.icon className="h-4 w-4 text-amber-400 flex-shrink-0" />
                        <span>{q.text}</span>
                      </button>
                    ))}
                  </div>
                )}
                
                <div className="space-y-2">
                  <p className="text-xs text-slate-500 font-medium px-1">Popular questions:</p>
                  {SUGGESTED_QUESTIONS.map((q, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => handleSuggestedQuestion(q.text)}
                      className="w-full flex items-center gap-2 p-3 text-left text-sm rounded-lg bg-slate-800/50 border border-slate-700/50 hover:border-cyan-500/30 hover:bg-slate-800 text-slate-300 transition-colors"
                    >
                      <q.icon className="h-4 w-4 text-slate-500 flex-shrink-0" />
                      <span>{q.text}</span>
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  {message.role === "assistant" && (
                    <div className="h-7 w-7 rounded-full bg-gradient-to-br from-cyan-400 to-cyan-600 flex items-center justify-center mr-2 mt-1 flex-shrink-0">
                      <span className="text-xs font-bold text-slate-900">L</span>
                    </div>
                  )}
                  <div
                    className={`max-w-[80%] rounded-2xl px-4 py-2.5 ${
                      message.role === "user"
                        ? "bg-cyan-500 text-slate-900"
                        : "bg-slate-800 text-slate-200"
                    }`}
                  >
                    {message.parts?.map((part, index) => {
                      if (part.type === "text") {
                        return (
                          <p key={index} className="text-sm whitespace-pre-wrap leading-relaxed">
                            {part.text}
                          </p>
                        )
                      }
                      // Render tool invocations
                      if (part.type === "tool-invocation") {
                        const { toolInvocation } = part
                        if (toolInvocation.toolName === "scheduleCelebration") {
                          if (toolInvocation.state === "output-available") {
                            const output = toolInvocation.output as { success: boolean; message?: string }
                            return (
                              <div key={index} className="flex items-center gap-2 py-2 px-3 my-1 rounded-lg bg-emerald-500/20 text-emerald-400">
                                <CheckCircle2 className="h-4 w-4 flex-shrink-0" />
                                <span className="text-xs">{output.message || "Celebration scheduled!"}</span>
                              </div>
                            )
                          }
                          return (
                            <div key={index} className="flex items-center gap-2 py-2 px-3 my-1 rounded-lg bg-amber-500/20 text-amber-400">
                              <PartyPopper className="h-4 w-4 flex-shrink-0 animate-pulse" />
                              <span className="text-xs">Scheduling celebration...</span>
                            </div>
                          )
                        }
                        // Generic tool loading state
                        if (toolInvocation.state !== "output-available") {
                          return (
                            <div key={index} className="flex items-center gap-2 py-2 my-1">
                              <Loader2 className="h-4 w-4 animate-spin text-slate-400" />
                              <span className="text-xs text-slate-400">Working on it...</span>
                            </div>
                          )
                        }
                      }
                      return null
                    })}
                  </div>
                </div>
              ))
            )}
            
            {isLoading && messages.length > 0 && messages[messages.length - 1]?.role === "user" && (
              <div className="flex justify-start">
                <div className="h-7 w-7 rounded-full bg-gradient-to-br from-cyan-400 to-cyan-600 flex items-center justify-center mr-2 flex-shrink-0">
                  <span className="text-xs font-bold text-slate-900">L</span>
                </div>
                <div className="bg-slate-800 rounded-2xl px-4 py-2.5">
                  <div className="flex items-center gap-2">
                    <Loader2 className="h-4 w-4 animate-spin text-cyan-400" />
                    <span className="text-sm text-slate-400">Thinking...</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Input */}
        <form onSubmit={handleSubmit} className="p-4 border-t border-slate-800 flex-shrink-0 bg-slate-900/80">
          <div className="flex gap-2">
            <input
              ref={inputRef}
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask Luca anything..."
              disabled={isLoading}
              className="flex-1 h-11 px-4 rounded-full bg-slate-800 border border-slate-700 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-500/50"
            />
            <Button
              type="submit"
              disabled={isLoading || !input.trim()}
              size="icon"
              className="h-11 w-11 rounded-full bg-cyan-500 hover:bg-cyan-400 text-slate-900 disabled:opacity-50"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
