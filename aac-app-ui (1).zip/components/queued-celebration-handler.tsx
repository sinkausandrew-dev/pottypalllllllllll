"use client"

import { useEffect, useState, useCallback } from "react"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Star, Sparkles, Rocket, PartyPopper } from "lucide-react"

interface QueuedCelebration {
  id: string
  celebration_type: string
  message: string
  animation_type: string
  points_awarded: number
  sound_effect: string
}

interface QueuedCelebrationHandlerProps {
  childId: string
  childName: string
}

// Helper to speak text with best available voice
function speak(text: string, onEnd?: () => void) {
  if (!('speechSynthesis' in window)) {
    onEnd?.()
    return
  }
  
  speechSynthesis.cancel()
  const utterance = new SpeechSynthesisUtterance(text)
  utterance.volume = 1.0
  utterance.rate = 0.9
  utterance.pitch = 1.0
  
  const voices = speechSynthesis.getVoices()
  const preferredVoices = ["Samantha", "Ava", "Allison", "Karen", "Natural", "Neural", "Premium"]
  for (const pref of preferredVoices) {
    const voice = voices.find(v => v.name.includes(pref) && v.lang.startsWith("en"))
    if (voice) {
      utterance.voice = voice
      break
    }
  }
  
  if (onEnd) {
    utterance.onend = onEnd
  }
  
  speechSynthesis.speak(utterance)
}

// Play celebration sound effect
function playSoundEffect(effect: string) {
  if (typeof window === "undefined") return
  
  try {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext
    if (!AudioContextClass) return
    
    const audioContext = new AudioContextClass()
    
    const playNote = (freq: number, startTime: number, duration: number, gain = 0.3) => {
      const oscillator = audioContext.createOscillator()
      const gainNode = audioContext.createGain()
      
      oscillator.connect(gainNode)
      gainNode.connect(audioContext.destination)
      
      oscillator.frequency.value = freq
      oscillator.type = "sine"
      
      gainNode.gain.setValueAtTime(gain, audioContext.currentTime + startTime)
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + startTime + duration)
      
      oscillator.start(audioContext.currentTime + startTime)
      oscillator.stop(audioContext.currentTime + startTime + duration)
    }
    
    // Different melodies for different effects
    if (effect === "fanfare") {
      playNote(523.25, 0, 0.2)
      playNote(659.25, 0.2, 0.2)
      playNote(783.99, 0.4, 0.2)
      playNote(1046.50, 0.6, 0.4)
    } else if (effect === "magic") {
      playNote(880, 0, 0.15)
      playNote(1175, 0.1, 0.15)
      playNote(1318, 0.2, 0.15)
      playNote(1568, 0.3, 0.3)
    } else if (effect === "woohoo") {
      playNote(392, 0, 0.1)
      playNote(523, 0.1, 0.1)
      playNote(659, 0.2, 0.1)
      playNote(784, 0.3, 0.1)
      playNote(1047, 0.4, 0.3)
    } else {
      // Default cheer
      playNote(523, 0, 0.15)
      playNote(659, 0.15, 0.15)
      playNote(784, 0.3, 0.15)
      playNote(1047, 0.45, 0.35)
    }
    
    setTimeout(() => {
      if (audioContext.state !== "closed") {
        audioContext.close().catch(() => {})
      }
    }, 2000)
  } catch {
    // Audio not supported
  }
}

// Animation configurations
const ANIMATIONS = {
  confetti: { icon: PartyPopper, colors: ["#f472b6", "#22d3ee", "#fbbf24", "#a78bfa", "#fff"] },
  stars: { icon: Star, colors: ["#fbbf24", "#f472b6", "#22d3ee", "#fff"] },
  rockets: { icon: Rocket, colors: ["#22d3ee", "#a78bfa", "#f472b6"] },
  rainbow: { icon: Sparkles, colors: ["#ef4444", "#f97316", "#fbbf24", "#22c55e", "#3b82f6", "#8b5cf6"] },
  fireworks: { icon: Sparkles, colors: ["#fbbf24", "#f472b6", "#22d3ee", "#a78bfa", "#ef4444"] },
}

export function QueuedCelebrationHandler({ childId, childName }: QueuedCelebrationHandlerProps) {
  const router = useRouter()
  const supabase = createClient()
  const [currentCelebration, setCurrentCelebration] = useState<QueuedCelebration | null>(null)
  const [confetti, setConfetti] = useState<Array<{ id: number; x: number; delay: number; color: string; size: number }>>([])
  const [showContent, setShowContent] = useState(false)

  // Poll for queued celebrations
  const checkForCelebrations = useCallback(async () => {
    const { data, error } = await supabase
      .from("queued_celebrations")
      .select("*")
      .eq("child_id", childId)
      .eq("status", "pending")
      .order("created_at", { ascending: true })
      .limit(1)
      .maybeSingle()

    if (!error && data) {
      setCurrentCelebration(data)
      
      // Mark as playing
      await supabase
        .from("queued_celebrations")
        .update({ status: "playing" })
        .eq("id", data.id)
    }
  }, [childId, supabase])

  // Poll every 3 seconds
  useEffect(() => {
    checkForCelebrations()
    const interval = setInterval(checkForCelebrations, 3000)
    return () => clearInterval(interval)
  }, [checkForCelebrations])

  // Handle celebration display
  useEffect(() => {
    if (!currentCelebration) return

    // Generate confetti
    const animConfig = ANIMATIONS[currentCelebration.animation_type as keyof typeof ANIMATIONS] || ANIMATIONS.confetti
    const newConfetti = Array.from({ length: 50 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      delay: Math.random() * 2,
      color: animConfig.colors[Math.floor(Math.random() * animConfig.colors.length)],
      size: Math.random() * 12 + 6,
    }))
    setConfetti(newConfetti)

    // Show content with animation
    setTimeout(() => setShowContent(true), 200)

    // Play sound effect
    playSoundEffect(currentCelebration.sound_effect)

    // Speak the message
    setTimeout(() => {
      let fullMessage = currentCelebration.message
      if (currentCelebration.points_awarded > 0) {
        fullMessage += ` You earned ${currentCelebration.points_awarded} stars!`
      }
      speak(fullMessage)
    }, 500)
  }, [currentCelebration])

  // Dismiss celebration
  const dismissCelebration = async () => {
    if (!currentCelebration) return

    // Mark as completed and record in history
    await supabase
      .from("queued_celebrations")
      .update({ status: "completed" })
      .eq("id", currentCelebration.id)

    // Record in history
    await supabase
      .from("celebration_history")
      .insert({
        child_id: childId,
        celebration_type: currentCelebration.celebration_type,
        message: currentCelebration.message,
        animation_type: currentCelebration.animation_type,
        points_awarded: currentCelebration.points_awarded,
        triggered_by: null, // We don't have this from the queue
      })

    setCurrentCelebration(null)
    setShowContent(false)
    setConfetti([])
    
    // Refresh to update points
    router.refresh()
  }

  if (!currentCelebration) return null

  const AnimIcon = ANIMATIONS[currentCelebration.animation_type as keyof typeof ANIMATIONS]?.icon || PartyPopper

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-background overflow-hidden">
      {/* Radial glow background */}
      <div
        className="absolute inset-0"
        style={{
          background: "radial-gradient(circle at 50% 40%, oklch(0.65 0.25 280 / 0.3), transparent 60%)",
        }}
      />

      {/* Confetti */}
      {confetti.map((piece) => (
        <div
          key={piece.id}
          className="pointer-events-none absolute rounded-full"
          style={{
            left: `${piece.x}%`,
            width: `${piece.size}px`,
            height: `${piece.size}px`,
            backgroundColor: piece.color,
            animation: `queued-confetti-fall 3s ease-out ${piece.delay}s forwards`,
          }}
        />
      ))}

      {/* Floating animation icons */}
      <AnimIcon className="absolute top-20 left-10 h-12 w-12 text-[var(--space-cyan)] animate-bounce opacity-60" />
      <AnimIcon
        className="absolute top-32 right-16 h-10 w-10 text-[var(--space-pink)] animate-bounce opacity-60"
        style={{ animationDelay: "0.5s" }}
      />

      {/* Content */}
      <div
        className={`relative z-10 flex flex-col items-center gap-6 p-8 text-center transition-all duration-500 ${
          showContent ? "opacity-100 scale-100" : "opacity-0 scale-90"
        }`}
      >
        {/* Big animated icon */}
        <div className="relative animate-bounce">
          <div
            className="flex h-28 w-28 items-center justify-center rounded-full bg-gradient-to-br from-[var(--space-pink)] to-[var(--space-purple)]"
            style={{
              boxShadow: "0 0 60px oklch(0.65 0.25 330 / 0.6)",
            }}
          >
            <AnimIcon className="h-16 w-16 text-white" />
          </div>
          <Sparkles className="absolute -right-4 -top-4 h-10 w-10 text-[var(--star-gold)] animate-pulse" />
          <Sparkles
            className="absolute -bottom-2 -left-4 h-8 w-8 text-[var(--space-cyan)] animate-pulse"
            style={{ animationDelay: "0.3s" }}
          />
        </div>

        {/* Celebration text */}
        <div className="space-y-3">
          <h1 className="text-4xl font-extrabold text-[var(--star-gold)] tracking-wide">
            {currentCelebration.celebration_type === "potty_success" ? "AMAZING!" : 
             currentCelebration.celebration_type === "milestone" ? "MILESTONE!" :
             currentCelebration.celebration_type === "encouragement" ? "YOU GOT THIS!" : "CELEBRATION!"}
          </h1>
          <p className="text-2xl text-foreground font-medium max-w-xs leading-relaxed">
            {currentCelebration.message}
          </p>
        </div>

        {/* Points earned (if any) */}
        {currentCelebration.points_awarded > 0 && (
          <div
            className="flex items-center gap-4 rounded-3xl bg-gradient-to-r from-[var(--star-gold)] to-[oklch(0.75_0.18_60)] px-10 py-5"
            style={{
              boxShadow: "0 8px 32px oklch(0.85 0.15 90 / 0.5)",
            }}
          >
            <Star className="h-12 w-12 fill-[oklch(0.15_0.02_60)] text-[oklch(0.15_0.02_60)]" />
            <span className="text-5xl font-extrabold text-[oklch(0.15_0.02_60)]">+{currentCelebration.points_awarded}</span>
          </div>
        )}

        <Button
          onClick={dismissCelebration}
          className="h-16 w-full max-w-xs text-xl font-bold bg-gradient-to-r from-[var(--space-purple)] to-[var(--space-blue)] mt-4"
          style={{
            boxShadow: "0 8px 24px oklch(0.65 0.25 280 / 0.4)",
          }}
        >
          AWESOME!
        </Button>
      </div>

      <style jsx>{`
        @keyframes queued-confetti-fall {
          0% {
            transform: translateY(-100vh) rotate(0deg);
            opacity: 1;
          }
          100% {
            transform: translateY(100vh) rotate(720deg);
            opacity: 0;
          }
        }
      `}</style>
    </div>
  )
}
