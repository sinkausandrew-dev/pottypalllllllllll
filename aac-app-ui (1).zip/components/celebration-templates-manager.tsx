"use client"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { 
  Plus, Trash2, PartyPopper, Star, Rocket, Sparkles, 
  Edit2, Check, X, Volume2
} from "lucide-react"

interface CelebrationTemplate {
  id: string
  name: string
  celebration_type: string
  message: string
  animation_type: string
  sound_effect: string
  default_points: number
  use_count: number
  is_active: boolean
}

const ANIMATION_OPTIONS = [
  { value: "confetti", label: "Confetti", icon: PartyPopper },
  { value: "stars", label: "Stars", icon: Star },
  { value: "rockets", label: "Rockets", icon: Rocket },
  { value: "rainbow", label: "Rainbow", icon: Sparkles },
  { value: "fireworks", label: "Fireworks", icon: Sparkles },
]

const SOUND_OPTIONS = [
  { value: "cheer", label: "Cheer" },
  { value: "fanfare", label: "Fanfare" },
  { value: "magic", label: "Magic" },
  { value: "woohoo", label: "Woohoo" },
]

const CELEBRATION_TYPES = [
  { value: "potty_success", label: "Potty Success" },
  { value: "milestone", label: "Milestone" },
  { value: "encouragement", label: "Encouragement" },
  { value: "custom", label: "Custom" },
]

interface CelebrationTemplatesManagerProps {
  profileId: string
}

export function CelebrationTemplatesManager({ profileId }: CelebrationTemplatesManagerProps) {
  const [templates, setTemplates] = useState<CelebrationTemplate[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isCreating, setIsCreating] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  
  // New template form state
  const [newTemplate, setNewTemplate] = useState({
    name: "",
    celebration_type: "potty_success",
    message: "",
    animation_type: "confetti",
    sound_effect: "cheer",
    default_points: 5,
  })

  const supabase = createClient()

  useEffect(() => {
    fetchTemplates()
  }, [])

  const fetchTemplates = async () => {
    const { data, error } = await supabase
      .from("celebration_templates")
      .select("*")
      .eq("user_id", profileId)
      .order("use_count", { ascending: false })

    if (!error && data) {
      setTemplates(data)
    }
    setIsLoading(false)
  }

  const createTemplate = async () => {
    if (!newTemplate.name || !newTemplate.message) return

    const { data, error } = await supabase
      .from("celebration_templates")
      .insert({
        user_id: profileId,
        ...newTemplate,
      })
      .select()
      .single()

    if (!error && data) {
      setTemplates([data, ...templates])
      setNewTemplate({
        name: "",
        celebration_type: "potty_success",
        message: "",
        animation_type: "confetti",
        sound_effect: "cheer",
        default_points: 5,
      })
      setIsCreating(false)
    }
  }

  const deleteTemplate = async (id: string) => {
    const { error } = await supabase
      .from("celebration_templates")
      .delete()
      .eq("id", id)

    if (!error) {
      setTemplates(templates.filter(t => t.id !== id))
    }
  }

  const toggleActive = async (id: string, isActive: boolean) => {
    const { error } = await supabase
      .from("celebration_templates")
      .update({ is_active: !isActive })
      .eq("id", id)

    if (!error) {
      setTemplates(templates.map(t => t.id === id ? { ...t, is_active: !isActive } : t))
    }
  }

  // Preview TTS
  const previewMessage = (message: string) => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(message)
      utterance.rate = 0.9
      speechSynthesis.speak(utterance)
    }
  }

  if (isLoading) {
    return (
      <Card className="border-border/50 bg-card/80">
        <CardContent className="p-4">
          <div className="animate-pulse space-y-3">
            <div className="h-4 bg-muted rounded w-1/3"></div>
            <div className="h-20 bg-muted rounded"></div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="border-border/50 bg-card/80">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <PartyPopper className="h-4 w-4 text-[var(--space-pink)]" />
            Celebration Templates
          </CardTitle>
          {!isCreating && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsCreating(true)}
              className="bg-transparent"
            >
              <Plus className="h-4 w-4 mr-1" />
              New
            </Button>
          )}
        </div>
        <p className="text-xs text-muted-foreground">
          Create reusable celebration messages for the AI assistant
        </p>
      </CardHeader>
      
      <CardContent className="space-y-3">
        {/* Create new template form */}
        {isCreating && (
          <div className="p-4 rounded-lg border border-[var(--space-pink)]/30 bg-[var(--space-pink)]/5 space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">Template Name</Label>
                <Input
                  placeholder="e.g., Big Success"
                  value={newTemplate.name}
                  onChange={(e) => setNewTemplate({ ...newTemplate, name: e.target.value })}
                  className="h-9 text-sm bg-background/50"
                />
              </div>
              <div>
                <Label className="text-xs">Type</Label>
                <select
                  value={newTemplate.celebration_type}
                  onChange={(e) => setNewTemplate({ ...newTemplate, celebration_type: e.target.value })}
                  className="w-full h-9 px-3 rounded-md border border-input bg-background/50 text-sm"
                >
                  {CELEBRATION_TYPES.map(type => (
                    <option key={type.value} value={type.value}>{type.label}</option>
                  ))}
                </select>
              </div>
            </div>
            
            <div>
              <Label className="text-xs">Message (spoken aloud)</Label>
              <div className="flex gap-2">
                <Input
                  placeholder="Amazing job! You did it!"
                  value={newTemplate.message}
                  onChange={(e) => setNewTemplate({ ...newTemplate, message: e.target.value })}
                  className="h-9 text-sm bg-background/50"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() => previewMessage(newTemplate.message)}
                  disabled={!newTemplate.message}
                  className="h-9 w-9"
                >
                  <Volume2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
            
            <div className="grid grid-cols-3 gap-3">
              <div>
                <Label className="text-xs">Animation</Label>
                <select
                  value={newTemplate.animation_type}
                  onChange={(e) => setNewTemplate({ ...newTemplate, animation_type: e.target.value })}
                  className="w-full h-9 px-3 rounded-md border border-input bg-background/50 text-sm"
                >
                  {ANIMATION_OPTIONS.map(anim => (
                    <option key={anim.value} value={anim.value}>{anim.label}</option>
                  ))}
                </select>
              </div>
              <div>
                <Label className="text-xs">Sound</Label>
                <select
                  value={newTemplate.sound_effect}
                  onChange={(e) => setNewTemplate({ ...newTemplate, sound_effect: e.target.value })}
                  className="w-full h-9 px-3 rounded-md border border-input bg-background/50 text-sm"
                >
                  {SOUND_OPTIONS.map(sound => (
                    <option key={sound.value} value={sound.value}>{sound.label}</option>
                  ))}
                </select>
              </div>
              <div>
                <Label className="text-xs">Points</Label>
                <Input
                  type="number"
                  min={0}
                  max={100}
                  value={newTemplate.default_points}
                  onChange={(e) => setNewTemplate({ ...newTemplate, default_points: parseInt(e.target.value) || 0 })}
                  className="h-9 text-sm bg-background/50"
                />
              </div>
            </div>
            
            <div className="flex gap-2 justify-end">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsCreating(false)}
              >
                <X className="h-4 w-4 mr-1" />
                Cancel
              </Button>
              <Button
                size="sm"
                onClick={createTemplate}
                disabled={!newTemplate.name || !newTemplate.message}
                className="bg-[var(--space-pink)] hover:bg-[var(--space-pink)]/90"
              >
                <Check className="h-4 w-4 mr-1" />
                Create
              </Button>
            </div>
          </div>
        )}

        {/* Template list */}
        {templates.length === 0 && !isCreating ? (
          <div className="text-center py-6 text-muted-foreground">
            <PartyPopper className="h-8 w-8 mx-auto mb-2 opacity-50" />
            <p className="text-sm">No templates yet</p>
            <p className="text-xs">Create templates for quick celebrations</p>
          </div>
        ) : (
          <div className="space-y-2">
            {templates.map((template) => (
              <div
                key={template.id}
                className={`flex items-center gap-3 p-3 rounded-lg border transition-colors ${
                  template.is_active 
                    ? "border-border/50 bg-muted/30" 
                    : "border-border/30 bg-muted/10 opacity-60"
                }`}
              >
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-sm truncate">{template.name}</span>
                    <span className="text-xs px-1.5 py-0.5 rounded bg-muted text-muted-foreground">
                      {template.celebration_type.replace("_", " ")}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground truncate mt-0.5">
                    "{template.message}"
                  </p>
                  <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                    <span>{template.animation_type}</span>
                    <span>•</span>
                    <span>{template.default_points} pts</span>
                    <span>•</span>
                    <span>Used {template.use_count}x</span>
                  </div>
                </div>
                
                <div className="flex items-center gap-1">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => previewMessage(template.message)}
                  >
                    <Volume2 className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => toggleActive(template.id, template.is_active)}
                  >
                    {template.is_active ? (
                      <Check className="h-4 w-4 text-green-500" />
                    ) : (
                      <X className="h-4 w-4 text-muted-foreground" />
                    )}
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-destructive hover:text-destructive"
                    onClick={() => deleteTemplate(template.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
