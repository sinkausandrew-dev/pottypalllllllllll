"use client"

import { useState, useEffect, useCallback } from "react"
import { createBrowserClient } from "@supabase/ssr"

interface UsePushNotificationsProps {
  caregiverId: string
}

export function usePushNotifications({ caregiverId }: UsePushNotificationsProps) {
  const [isSupported, setIsSupported] = useState(false)
  const [isSubscribed, setIsSubscribed] = useState(false)
  const [subscription, setSubscription] = useState<PushSubscription | null>(null)
  const [permission, setPermission] = useState<NotificationPermission>("default")
  const [loading, setLoading] = useState(true)

  const supabase = createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  )

  // Check if push notifications are supported
  useEffect(() => {
    const checkSupport = () => {
      const supported = "serviceWorker" in navigator && "PushManager" in window && "Notification" in window
      setIsSupported(supported)

      if (supported) {
        setPermission(Notification.permission)
      }
    }

    checkSupport()
  }, [])

  // Register service worker and check existing subscription
  useEffect(() => {
    const initServiceWorker = async () => {
      if (!isSupported) {
        setLoading(false)
        return
      }

      try {
        // Check for existing service worker first
        const existingReg = await navigator.serviceWorker.getRegistration()
        if (existingReg) {
          const existingSub = await existingReg.pushManager.getSubscription()
          if (existingSub) {
            setSubscription(existingSub)
            setIsSubscribed(true)
          }
          setLoading(false)
          return
        }

        // Verify sw.js exists before registering (prevents errors in preview environments)
        const swCheck = await fetch("/sw.js", { method: "HEAD" }).catch(() => null)
        if (!swCheck?.ok || swCheck.headers.get("content-type")?.includes("text/html")) {
          // sw.js not available - push notifications not supported in this environment
          setIsSupported(false)
          setLoading(false)
          return
        }

        const registration = await navigator.serviceWorker.register("/sw.js")

        // Check for existing subscription
        const existingSub = await registration.pushManager.getSubscription()
        if (existingSub) {
          setSubscription(existingSub)
          setIsSubscribed(true)
        }
      } catch {
        // Service worker not available - mark as unsupported
        setIsSupported(false)
      } finally {
        setLoading(false)
      }
    }

    initServiceWorker()
  }, [isSupported])

  // Subscribe to push notifications
  const subscribe = useCallback(async () => {
    if (!isSupported) return false

    try {
      // Request notification permission
      const perm = await Notification.requestPermission()
      setPermission(perm)

      if (perm !== "granted") {
        console.log("[Push] Permission denied")
        return false
      }

      // Get service worker registration
      const registration = await navigator.serviceWorker.ready

      // Get VAPID public key
      const vapidPublicKey = process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY
      if (!vapidPublicKey) {
        console.error("[Push] VAPID public key not configured")
        return false
      }

      // Subscribe to push
      const sub = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(vapidPublicKey),
      })

      setSubscription(sub)
      setIsSubscribed(true)

      // Save subscription to database
      const subJson = sub.toJSON()
      await supabase.from("push_subscriptions").upsert({
        profile_id: caregiverId,
        endpoint: subJson.endpoint,
        p256dh: subJson.keys?.p256dh,
        auth: subJson.keys?.auth,
        updated_at: new Date().toISOString(),
      }, {
        onConflict: "profile_id,endpoint"
      })

      console.log("[Push] Subscribed successfully")
      return true
    } catch (error) {
      console.error("[Push] Subscription failed:", error)
      return false
    }
  }, [isSupported, caregiverId, supabase])

  // Unsubscribe from push notifications
  const unsubscribe = useCallback(async () => {
    if (!subscription) return false

    try {
      await subscription.unsubscribe()
      
      // Remove from database
      const subJson = subscription.toJSON()
      await supabase
        .from("push_subscriptions")
        .delete()
        .eq("endpoint", subJson.endpoint)

      setSubscription(null)
      setIsSubscribed(false)

      console.log("[Push] Unsubscribed successfully")
      return true
    } catch (error) {
      console.error("[Push] Unsubscribe failed:", error)
      return false
    }
  }, [subscription, supabase])

  return {
    isSupported,
    isSubscribed,
    permission,
    loading,
    subscribe,
    unsubscribe,
  }
}

// Helper function to convert VAPID key
function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4)
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/")
  const rawData = window.atob(base64)
  const outputArray = new Uint8Array(rawData.length)
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i)
  }
  return outputArray
}
