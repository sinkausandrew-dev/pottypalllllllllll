'use client'

import { useConversation } from '@/lib/aac/conversation-context'
import { ChildChat } from './child-chat'
import { ContactSelection } from './contact-selection'
import { CosmicBackground } from './cosmic-background'
import { Home, Star, Sparkles, MessageCircle } from 'lucide-react'

export function MessagingModule() {
  const { childProfile, totalUnreadCount, childViewScreen, activeThread } =
    useConversation()

  // Hide header when inside a chat thread (child-chat has its own header)
  const showMainHeader = childViewScreen === 'contacts'

  return (
    <div className="relative flex h-screen flex-col overflow-hidden">
      <CosmicBackground />

      {/* Main header - only show on contact selection screen */}
      {showMainHeader && (
        <header className="relative z-10 flex items-center justify-between border-b border-border/30 bg-cosmic-surface/80 px-4 py-3 backdrop-blur-sm">
          <button
            type="button"
            className="flex h-11 w-11 items-center justify-center rounded-lg text-foreground/70 transition-colors hover:bg-cosmic-elevated hover:text-foreground"
            aria-label="Home"
          >
            <Home className="h-5 w-5" />
          </button>
          <div className="flex flex-col items-center">
            <h1 className="text-lg font-semibold text-foreground">Messages</h1>
            <p className="text-sm text-muted-foreground">{childProfile.name}</p>
          </div>
          <div className="flex items-center gap-1 rounded-full bg-neon-cyan/90 px-3 py-1.5">
            <Sparkles className="h-4 w-4 text-cosmic-deep" />
            <Star className="h-4 w-4 fill-current text-cosmic-deep" />
            <span className="font-semibold text-cosmic-deep">210</span>
          </div>
        </header>
      )}

      {/* Main content - child interface only */}
      <main className="relative z-10 flex-1 overflow-hidden">
        {childViewScreen === 'contacts' ? <ContactSelection /> : <ChildChat />}
      </main>

      {/* Bottom navigation - only show on contacts screen */}
      {showMainHeader && (
        <nav className="relative z-10 flex items-center justify-around border-t border-border/30 bg-cosmic-surface/80 py-3 backdrop-blur-sm">
          <button
            type="button"
            className="flex flex-col items-center gap-1 text-neon-cyan transition-colors"
            aria-label="Messages"
          >
            <div className="relative">
              <MessageCircle className="h-6 w-6" />
              {totalUnreadCount > 0 && (
                <span className="absolute -right-2 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-destructive text-[10px] font-bold text-white">
                  {totalUnreadCount > 9 ? '9+' : totalUnreadCount}
                </span>
              )}
            </div>
            <span className="text-xs">Messages</span>
          </button>
        </nav>
      )}
    </div>
  )
}
