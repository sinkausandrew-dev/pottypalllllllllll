'use client'

import { useConversation } from '@/lib/aac/conversation-context'
import { Users } from 'lucide-react'
import { cn } from '@/lib/utils'
import Image from 'next/image'

export function ContactSelection() {
  const { familyMembers, threads, setActiveThread, getGroupThread } = useConversation()

  const groupThread = getGroupThread()

  const handleSelectCaregiver = (caregiverId: string) => {
    const thread = threads.find(
      (t) => t.type === 'individual' && t.participants.includes(caregiverId)
    )
    if (thread) {
      setActiveThread(thread.id)
    }
  }

  const handleSelectGroup = () => {
    setActiveThread(groupThread.id)
  }

  const getUnreadCount = (caregiverId: string) => {
    const thread = threads.find(
      (t) => t.type === 'individual' && t.participants.includes(caregiverId)
    )
    return thread?.unreadCount || 0
  }

  return (
    <div className="flex h-full flex-col">
      {/* Header - fixed height */}
      <div className="shrink-0 border-b border-border/30 bg-cosmic-surface/60 px-4 py-3 backdrop-blur-sm">
        <h2 className="text-center text-xl font-bold text-white">
          Who do you want to message?
        </h2>
      </div>

      {/* Main content - fills remaining space with grid */}
      <div className="flex flex-1 flex-col gap-3 p-3">
        {/* Group Chat Button - prominent at top */}
        <button
          type="button"
          onClick={handleSelectGroup}
          className="flex h-[15%] min-h-[70px] items-center gap-4 rounded-2xl border-2 border-neon-cyan/60 bg-neon-cyan/15 px-4 transition-all active:scale-[0.98] hover:border-neon-cyan hover:bg-neon-cyan/25"
        >
          <div className="relative flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-neon-cyan/30">
            <Users className="h-8 w-8 text-neon-cyan" />
            {groupThread.unreadCount > 0 && (
              <span className="absolute -right-1 -top-1 flex h-6 w-6 items-center justify-center rounded-full bg-red-500 text-xs font-bold text-white">
                {groupThread.unreadCount}
              </span>
            )}
          </div>
          <div className="flex-1 text-left">
            <h3 className="text-xl font-bold text-white">Family Group</h3>
            <p className="text-sm text-cyan-200">Message everyone</p>
          </div>
          {/* Mini avatars */}
          <div className="flex -space-x-2">
            {familyMembers.slice(0, 4).map((member) => (
              <div
                key={member.id}
                className="relative h-9 w-9 overflow-hidden rounded-full border-2 border-cosmic-deep"
              >
                <Image
                  src={member.avatar || '/placeholder.svg'}
                  alt={member.name}
                  fill
                  className="object-cover"
                />
              </div>
            ))}
          </div>
        </button>

        {/* 2x2 Contact Grid - takes remaining space */}
        <div className="grid flex-1 grid-cols-2 grid-rows-2 gap-3">
          {familyMembers.slice(0, 4).map((member) => {
            const unreadCount = getUnreadCount(member.id)

            return (
              <button
                key={member.id}
                type="button"
                onClick={() => handleSelectCaregiver(member.id)}
                className="group relative flex flex-col items-center justify-center rounded-2xl border border-border/40 bg-cosmic-surface/70 p-2 transition-all active:scale-[0.97] hover:border-neon-cyan/50 hover:bg-cosmic-elevated/70"
              >
                {/* Avatar - large and prominent */}
                <div className="relative mb-2">
                  <div className="relative h-20 w-20 overflow-hidden rounded-full border-3 border-border/50 transition-colors group-hover:border-neon-cyan/50 sm:h-24 sm:w-24">
                    <Image
                      src={member.avatar || '/placeholder.svg'}
                      alt={member.name}
                      fill
                      className="object-cover"
                    />
                  </div>

                  {/* Online indicator */}
                  {member.isOnline && (
                    <div className="absolute bottom-0.5 right-0.5 h-5 w-5 rounded-full border-3 border-cosmic-surface bg-green-500" />
                  )}

                  {/* Unread badge */}
                  {unreadCount > 0 && (
                    <span className="absolute -right-1 -top-1 flex h-7 w-7 items-center justify-center rounded-full bg-red-500 text-sm font-bold text-white">
                      {unreadCount}
                    </span>
                  )}
                </div>

                {/* Name - clear and large */}
                <h4 className="text-lg font-bold text-white sm:text-xl">
                  {member.relationship || member.name}
                </h4>
              </button>
            )
          })}
        </div>
      </div>
    </div>
  )
}
