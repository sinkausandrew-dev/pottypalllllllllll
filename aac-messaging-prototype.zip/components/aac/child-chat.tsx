'use client'

import { useState, useEffect, useCallback, useRef } from 'react'
import { Volume2, VolumeX, RefreshCw, ChevronLeft, Users, MessageSquarePlus } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { ResponseButton } from './response-button'
import { useConversation } from '@/lib/aac/conversation-context'
import {
  predictResponses,
  getConversationStarters,
  recordResponseSelection,
} from '@/lib/aac/prediction-engine'
import type { ResponseOption } from '@/lib/aac/conversation-data'
import type { Message } from '@/lib/aac/types'
import { cn } from '@/lib/utils'

// Sample messages caregivers might send (for demo)
const sampleCaregiverMessages = [
  'How are you feeling?',
  'Are you hungry?',
  'Do you need to use the potty?',
  'What would you like to do?',
  'I love you!',
  'Time for a snack!',
  'Do you want to play?',
  'Are you okay?',
]

export function ChildChat() {
  const {
    activeThread,
    addMessage,
    childProfile,
    familyMembers,
    markThreadAsRead,
    setActiveThread,
    setChildViewScreen,
    simulateCaregiverMessage,
  } = useConversation()

  const [responseOptions, setResponseOptions] = useState<ResponseOption[]>([])
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [lastCaregiverMessageId, setLastCaregiverMessageId] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [ttsEnabled, setTtsEnabled] = useState(true)
  const [showDemoPanel, setShowDemoPanel] = useState(false)
  const speechRef = useRef<SpeechSynthesisUtterance | null>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  // Get caregiver info for this thread
  const isGroupChat = activeThread?.type === 'group'
  const threadCaregivers = familyMembers.filter((m) =>
    activeThread?.participants.includes(m.id)
  )
  const primaryCaregiver = threadCaregivers[0]

  // Get chat title
  const chatTitle = isGroupChat
    ? 'Family Group'
    : primaryCaregiver?.relationship || primaryCaregiver?.name || 'Chat'

  // Get the latest caregiver message
  const latestCaregiverMessage = activeThread?.messages
    ? [...activeThread.messages].reverse().find((m) => m.sender === 'caregiver')
    : null

  // Get caregiver by ID
  const getCaregiverById = (id: string) => familyMembers.find((m) => m.id === id)

  // Get initials for avatar fallback
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2)
  }

  // Speak text using Web Speech API - slower and clearer for better comprehension
  const speak = useCallback(
    (text: string) => {
      if (!ttsEnabled || typeof window === 'undefined' || !window.speechSynthesis)
        return

      window.speechSynthesis.cancel()

      const utterance = new SpeechSynthesisUtterance(text)
      // Slower rate for better comprehension - 0.7 is noticeably slower
      utterance.rate = 0.7
      // Slightly lower pitch for warmth and clarity
      utterance.pitch = 0.95
      // Full volume
      utterance.volume = 1.0

      const voices = window.speechSynthesis.getVoices()
      // Prefer high-quality voices that are warm and clear
      const preferredVoice = voices.find(
        (voice) =>
          voice.lang.startsWith('en') &&
          (childProfile.voicePreference === 'female'
            ? voice.name.toLowerCase().includes('female') ||
              voice.name.includes('Samantha') ||
              voice.name.includes('Victoria') ||
              voice.name.includes('Karen') ||
              voice.name.includes('Moira')
            : voice.name.toLowerCase().includes('male') ||
              voice.name.includes('Daniel') ||
              voice.name.includes('Alex') ||
              voice.name.includes('Tom'))
      )

      if (preferredVoice) {
        utterance.voice = preferredVoice
      }

      utterance.onstart = () => setIsSpeaking(true)
      utterance.onend = () => setIsSpeaking(false)
      utterance.onerror = () => setIsSpeaking(false)

      speechRef.current = utterance
      window.speechSynthesis.speak(utterance)
    },
    [ttsEnabled, childProfile.voicePreference]
  )

  const stopSpeaking = useCallback(() => {
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      window.speechSynthesis.cancel()
      setIsSpeaking(false)
    }
  }, [])

  // Handle new caregiver message
  useEffect(() => {
    if (
      latestCaregiverMessage &&
      latestCaregiverMessage.id !== lastCaregiverMessageId
    ) {
      setLastCaregiverMessageId(latestCaregiverMessage.id)
      setIsLoading(true)

      const result = predictResponses(latestCaregiverMessage.content, {
        conversationLength: activeThread?.messages.length || 0,
      })

      setResponseOptions(result.responses)
      setIsLoading(false)

      // Read the message aloud with sender name for group chat
      const senderName = isGroupChat
        ? getCaregiverById(latestCaregiverMessage.senderId)?.relationship || 'Someone'
        : ''
      const textToSpeak = isGroupChat
        ? `${senderName} says: ${latestCaregiverMessage.content}`
        : latestCaregiverMessage.content
      speak(textToSpeak)

      // Mark as read
      if (activeThread) {
        markThreadAsRead(activeThread.id)
      }
    }
  }, [
    latestCaregiverMessage,
    lastCaregiverMessageId,
    speak,
    activeThread,
    markThreadAsRead,
    isGroupChat,
  ])

  // Load conversation starters if no messages
  useEffect(() => {
    if (!activeThread?.messages.length) {
      const starters = getConversationStarters()
      setResponseOptions(starters)
    }
  }, [activeThread?.messages.length])

  // Load voices
  useEffect(() => {
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      window.speechSynthesis.onvoiceschanged = () => {
        window.speechSynthesis.getVoices()
      }
    }
    return () => stopSpeaking()
  }, [stopSpeaking])

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [activeThread?.messages])

  const handleResponseSelect = (response: ResponseOption) => {
    if (!activeThread) return

    recordResponseSelection(response.id)

    addMessage(activeThread.id, {
      content: response.text,
      sender: 'child',
      senderId: childProfile.id,
      responseOption: response,
    })

    setResponseOptions([])
    setLastCaregiverMessageId(null)
  }

  const handleRefresh = () => {
    if (latestCaregiverMessage) {
      setIsLoading(true)
      const result = predictResponses(latestCaregiverMessage.content, {
        conversationLength: activeThread?.messages.length || 0,
      })
      setResponseOptions(result.responses)
      setIsLoading(false)
    } else {
      const starters = getConversationStarters()
      setResponseOptions(starters)
    }
  }

  const replayMessage = () => {
    if (latestCaregiverMessage) {
      const senderName = isGroupChat
        ? getCaregiverById(latestCaregiverMessage.senderId)?.relationship || 'Someone'
        : ''
      const textToSpeak = isGroupChat
        ? `${senderName} says: ${latestCaregiverMessage.content}`
        : latestCaregiverMessage.content
      speak(textToSpeak)
    }
  }

  const handleBack = () => {
    setActiveThread(null)
    setChildViewScreen('contacts')
    stopSpeaking()
  }

  const isWaitingForResponse =
    activeThread?.messages.length &&
    activeThread.messages[activeThread.messages.length - 1].sender === 'child'

  // Demo: send a simulated caregiver message
  const handleDemoMessage = (message: string) => {
    if (!activeThread) return
    const caregiverId = isGroupChat
      ? threadCaregivers[Math.floor(Math.random() * threadCaregivers.length)]?.id
      : primaryCaregiver?.id
    if (caregiverId) {
      simulateCaregiverMessage(activeThread.id, caregiverId, message)
      setShowDemoPanel(false)
    }
  }

  if (!activeThread) return null

  return (
    <div className="flex h-full flex-col bg-cosmic-deep/50">
      {/* Header */}
      <div className="flex items-center gap-3 border-b border-border/30 bg-cosmic-surface/80 px-3 py-3 backdrop-blur-sm">
        <Button
          variant="ghost"
          size="icon"
          onClick={handleBack}
          className="h-12 w-12 shrink-0 text-foreground/70 hover:bg-cosmic-elevated hover:text-foreground"
        >
          <ChevronLeft className="h-7 w-7" />
        </Button>

        {/* Avatar */}
        <div className="relative shrink-0">
          {isGroupChat ? (
            <div className="flex h-14 w-14 items-center justify-center rounded-full border-2 border-neon-cyan/50 bg-neon-cyan/20">
              <Users className="h-7 w-7 text-neon-cyan" />
            </div>
          ) : (
            <div className="h-14 w-14 overflow-hidden rounded-full border-2 border-neon-cyan/50">
              {primaryCaregiver?.avatar ? (
                <img
                  src={primaryCaregiver.avatar || "/placeholder.svg"}
                  alt={primaryCaregiver.name}
                  className="h-full w-full object-cover"
                />
              ) : (
                <div className="flex h-full w-full items-center justify-center bg-cosmic-elevated text-xl font-semibold text-foreground">
                  {primaryCaregiver ? getInitials(primaryCaregiver.name) : '?'}
                </div>
              )}
            </div>
          )}
          {!isGroupChat && primaryCaregiver?.isOnline && (
            <div className="absolute -bottom-0.5 -right-0.5 h-4 w-4 rounded-full border-2 border-cosmic-surface bg-green-500" />
          )}
        </div>

        <div className="min-w-0 flex-1">
          <h2 className="truncate text-xl font-semibold text-foreground">
            {chatTitle}
          </h2>
          {isGroupChat && (
            <p className="truncate text-sm text-muted-foreground">
              {threadCaregivers.map((c) => c.relationship || c.name).join(', ')}
            </p>
          )}
        </div>

        <Button
          variant="ghost"
          size="icon"
          onClick={() => setTtsEnabled(!ttsEnabled)}
          className="h-12 w-12 shrink-0 text-foreground/70 hover:bg-cosmic-elevated hover:text-foreground"
        >
          {ttsEnabled ? (
            <Volume2 className="h-6 w-6" />
          ) : (
            <VolumeX className="h-6 w-6" />
          )}
        </Button>
      </div>

      {/* Messages area */}
      <div className="flex-1 overflow-y-auto p-4">
        {/* Message history */}
        <div className="space-y-4">
          {activeThread.messages.map((message) => {
            const isChild = message.sender === 'child'
            const senderCaregiver = !isChild
              ? getCaregiverById(message.senderId)
              : null

            return (
              <div
                key={message.id}
                className={cn('flex gap-3', isChild ? 'justify-end' : 'justify-start')}
              >
                {!isChild && (
                  <div className="h-10 w-10 shrink-0 overflow-hidden rounded-full">
                    {senderCaregiver?.avatar ? (
                      <img
                        src={senderCaregiver.avatar || "/placeholder.svg"}
                        alt={senderCaregiver.name}
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <div className="flex h-full w-full items-center justify-center bg-cosmic-elevated text-sm font-semibold text-foreground">
                        {senderCaregiver ? getInitials(senderCaregiver.name) : '?'}
                      </div>
                    )}
                  </div>
                )}

                <div
                  className={cn(
                    'max-w-[75%] rounded-2xl px-4 py-3',
                    isChild
                      ? 'bg-neon-cyan text-cosmic-deep'
                      : 'bg-cosmic-surface text-foreground'
                  )}
                >
                  {!isChild && isGroupChat && senderCaregiver && (
                    <p className="mb-1 text-xs font-medium text-neon-cyan">
                      {senderCaregiver.relationship || senderCaregiver.name}
                    </p>
                  )}
                  <p className="text-base leading-relaxed">{message.content}</p>
                  {isChild && message.responseOption?.emoji && (
                    <span className="ml-2 text-lg">{message.responseOption.emoji}</span>
                  )}
                </div>

                {isChild && (
                  <div className="h-10 w-10 shrink-0 overflow-hidden rounded-full">
                    {childProfile.avatar ? (
                      <img
                        src={childProfile.avatar || "/placeholder.svg"}
                        alt={childProfile.name}
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <div className="flex h-full w-full items-center justify-center bg-neon-cyan text-sm font-semibold text-cosmic-deep">
                        {getInitials(childProfile.name)}
                      </div>
                    )}
                  </div>
                )}
              </div>
            )
          })}
          <div ref={messagesEndRef} />
        </div>

        {/* Waiting state */}
        {isWaitingForResponse && (
          <div className="mt-8 flex flex-col items-center justify-center text-center">
            <div className="mb-4 flex items-center gap-2">
              <div
                className="h-3 w-3 animate-bounce rounded-full bg-neon-cyan"
                style={{ animationDelay: '0ms' }}
              />
              <div
                className="h-3 w-3 animate-bounce rounded-full bg-neon-cyan"
                style={{ animationDelay: '150ms' }}
              />
              <div
                className="h-3 w-3 animate-bounce rounded-full bg-neon-cyan"
                style={{ animationDelay: '300ms' }}
              />
            </div>
            <h3 className="text-lg font-semibold text-foreground">Message sent!</h3>
            <p className="text-muted-foreground">
              Waiting for {isGroupChat ? 'a response' : chatTitle}...
            </p>
          </div>
        )}

        {/* No messages - conversation starters prompt */}
        {!activeThread.messages.length && (
          <div className="mt-8 text-center">
            <h3 className="text-xl font-semibold text-foreground">
              Say something to {chatTitle}!
            </h3>
            <p className="mb-4 text-muted-foreground">
              Tap a button below to send a message
            </p>
          </div>
        )}
      </div>

      {/* Latest caregiver message card (if exists and not waiting) */}
      {latestCaregiverMessage && !isWaitingForResponse && (
        <div className="border-t border-border/30 bg-cosmic-surface/60 p-3 backdrop-blur-sm">
          <div className="mb-3 rounded-xl border border-border/30 bg-cosmic-deep/50 p-3">
            <div className="flex items-center gap-2">
              {isGroupChat && (
                <span className="text-sm font-medium text-neon-cyan">
                  {getCaregiverById(latestCaregiverMessage.senderId)?.relationship ||
                    'Someone'}
                  :
                </span>
              )}
              <p className="flex-1 text-base text-foreground">
                {latestCaregiverMessage.content}
              </p>
              <Button
                variant="ghost"
                size="icon"
                onClick={replayMessage}
                disabled={isSpeaking}
                className={cn(
                  'h-10 w-10 shrink-0 rounded-full',
                  isSpeaking
                    ? 'text-neon-cyan'
                    : 'text-muted-foreground hover:text-foreground'
                )}
              >
                <Volume2 className={cn('h-5 w-5', isSpeaking && 'animate-pulse')} />
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Response options */}
      {!isWaitingForResponse && responseOptions.length > 0 && (
        <div className="border-t border-border/30 bg-cosmic-surface/60 p-4 backdrop-blur-sm">
          <div className="mb-3 flex items-center justify-between">
            <h4 className="font-medium text-foreground">
              {activeThread.messages.length === 0
                ? 'Start a conversation'
                : 'Choose a reply'}
            </h4>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleRefresh}
              disabled={isLoading}
              className="text-muted-foreground hover:text-foreground"
            >
              <RefreshCw className={cn('mr-2 h-4 w-4', isLoading && 'animate-spin')} />
              More options
            </Button>
          </div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            {responseOptions.slice(0, 6).map((response) => (
              <ResponseButton
                key={response.id}
                response={response}
                onSelect={handleResponseSelect}
                size="large"
              />
            ))}
          </div>
        </div>
      )}

      {/* Demo: Simulate caregiver message button */}
      {isWaitingForResponse && (
        <div className="relative border-t border-border/30 bg-cosmic-surface/60 p-4 backdrop-blur-sm">
          <Button
            onClick={() => setShowDemoPanel(!showDemoPanel)}
            className="w-full gap-2 bg-cosmic-elevated hover:bg-cosmic-elevated/80"
          >
            <MessageSquarePlus className="h-5 w-5" />
            <span>Demo: Simulate {chatTitle} Reply</span>
          </Button>

          {/* Demo message options */}
          {showDemoPanel && (
            <div className="absolute bottom-full left-0 right-0 mb-2 rounded-xl border border-border/30 bg-cosmic-surface p-3 shadow-lg">
              <p className="mb-2 text-sm text-muted-foreground">
                Select a message to simulate receiving:
              </p>
              <div className="grid grid-cols-1 gap-2">
                {sampleCaregiverMessages.map((msg) => (
                  <button
                    key={msg}
                    type="button"
                    onClick={() => handleDemoMessage(msg)}
                    className="rounded-lg bg-cosmic-elevated px-3 py-2 text-left text-sm text-foreground transition-colors hover:bg-neon-cyan/20"
                  >
                    {msg}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
