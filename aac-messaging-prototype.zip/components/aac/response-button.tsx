'use client'

import { useState } from 'react'
import { cn } from '@/lib/utils'
import type { ResponseOption } from '@/lib/aac/conversation-data'

interface ResponseButtonProps {
  response: ResponseOption
  onSelect: (response: ResponseOption) => void
  size?: 'default' | 'large'
  disabled?: boolean
}

export function ResponseButton({
  response,
  onSelect,
  size = 'default',
  disabled = false,
}: ResponseButtonProps) {
  const [isPressed, setIsPressed] = useState(false)

  const handleClick = () => {
    if (disabled) return
    setIsPressed(true)
    onSelect(response)
    setTimeout(() => setIsPressed(false), 200)
  }

  return (
    <button
      type="button"
      onClick={handleClick}
      disabled={disabled}
      className={cn(
        'group relative flex flex-col items-center justify-center overflow-hidden rounded-2xl border-2 transition-all duration-200',
        'bg-cosmic-surface hover:bg-cosmic-elevated active:scale-95',
        'border-border/40 hover:border-neon-cyan/50',
        'focus:outline-none focus:ring-2 focus:ring-neon-cyan/50 focus:ring-offset-2 focus:ring-offset-cosmic-deep',
        isPressed && 'scale-95 border-neon-cyan bg-neon-cyan/20',
        disabled && 'cursor-not-allowed opacity-50',
        size === 'large' ? 'min-h-[120px] p-4' : 'min-h-[100px] p-3'
      )}
      style={{ minWidth: size === 'large' ? '140px' : '110px' }}
    >
      {/* Glow effect on hover */}
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-br from-neon-cyan/0 via-neon-cyan/0 to-neon-cyan/0 opacity-0 transition-opacity duration-300 group-hover:opacity-10" />

      {/* Emoji */}
      <span
        className={cn(
          'transition-transform duration-200 group-hover:scale-110',
          size === 'large' ? 'mb-3 text-5xl' : 'mb-2 text-4xl'
        )}
        role="img"
        aria-hidden="true"
      >
        {response.emoji}
      </span>

      {/* Text */}
      <span
        className={cn(
          'text-balance text-center font-medium leading-tight text-foreground',
          size === 'large' ? 'text-base' : 'text-sm'
        )}
      >
        {response.text}
      </span>

      {/* Selection indicator */}
      {isPressed && (
        <div className="absolute inset-0 flex items-center justify-center bg-neon-cyan/20">
          <div className="h-8 w-8 rounded-full bg-neon-cyan text-cosmic-deep">
            <svg className="h-full w-full p-1.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
            </svg>
          </div>
        </div>
      )}
    </button>
  )
}
