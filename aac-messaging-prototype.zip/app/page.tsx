import { ConversationProvider } from '@/lib/aac/conversation-context'
import { MessagingModule } from '@/components/aac/messaging-module'

export default function Home() {
  return (
    <ConversationProvider>
      <MessagingModule />
    </ConversationProvider>
  )
}
