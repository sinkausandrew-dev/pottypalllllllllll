import { NextResponse } from 'next/server'
import {
  predictResponses,
  getConversationStarters,
  recordResponseSelection,
  getFollowUpResponses,
} from '@/lib/aac/prediction-engine'
import type { ResponseOption } from '@/lib/aac/conversation-data'

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { action, caregiverMessage, lastResponse, context } = body

    switch (action) {
      case 'predict': {
        if (!caregiverMessage) {
          return NextResponse.json(
            { error: 'caregiverMessage is required for prediction' },
            { status: 400 }
          )
        }
        const result = predictResponses(caregiverMessage, context)
        return NextResponse.json(result)
      }

      case 'starters': {
        const starters = getConversationStarters(context)
        return NextResponse.json({ responses: starters })
      }

      case 'record': {
        if (!body.responseId) {
          return NextResponse.json(
            { error: 'responseId is required for recording' },
            { status: 400 }
          )
        }
        recordResponseSelection(body.responseId)
        return NextResponse.json({ success: true })
      }

      case 'followup': {
        if (!lastResponse) {
          return NextResponse.json(
            { error: 'lastResponse is required for follow-up' },
            { status: 400 }
          )
        }
        const followups = getFollowUpResponses(lastResponse as ResponseOption, context)
        return NextResponse.json({ responses: followups })
      }

      default:
        return NextResponse.json({ error: 'Invalid action' }, { status: 400 })
    }
  } catch (error) {
    console.error('AAC prediction error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
