'use client'

import {
  createContext,
  useContext,
  useState,
  useCallback,
  useEffect,
  type ReactNode,
} from 'react'
import type {
  Message,
  ChatThread,
  ChildProfile,
  FamilyMember,
  ChildViewScreen,
} from './types'

interface ConversationContextType {
  // Profiles
  childProfile: ChildProfile
  familyMembers: FamilyMember[]

  // Chat threads
  threads: ChatThread[]
  activeThread: ChatThread | null
  setActiveThread: (threadId: string | null) => void
  getThreadForCaregiver: (caregiverId: string) => ChatThread
  getGroupThread: () => ChatThread

  // Messaging
  addMessage: (threadId: string, message: Omit<Message, 'id' | 'timestamp'>) => void
  markThreadAsRead: (threadId: string) => void

  // View state (child interface only)
  childViewScreen: ChildViewScreen
  setChildViewScreen: (screen: ChildViewScreen) => void

  // Stats
  totalUnreadCount: number

  // Simulate incoming caregiver message (for demo purposes)
  simulateCaregiverMessage: (threadId: string, caregiverId: string, content: string) => void
}

const ConversationContext = createContext<ConversationContextType | null>(null)

// Storage key for persistence
const STORAGE_KEY_THREADS = 'aac_chat_threads'

// Default child profile matching Dominic from the screenshots
const defaultChildProfile: ChildProfile = {
  id: 'child-1',
  name: 'Dominic',
  age: 14,
  avatar: undefined,
  voicePreference: 'female',
}

// Default family members with profile pictures
const defaultFamilyMembers: FamilyMember[] = [
  {
    id: 'caregiver-1',
    name: 'Obama',
    relationship: 'Obama',
    role: 'family',
    avatar: '/avatars/obama.jpeg',
    isOnline: true,
    notificationsEnabled: true,
  },
  {
    id: 'caregiver-2',
    name: 'Benny',
    relationship: 'Benny',
    role: 'family',
    avatar: '/avatars/benny.jpeg',
    isOnline: true,
    notificationsEnabled: true,
  },
  {
    id: 'caregiver-3',
    name: 'Dad',
    relationship: 'Dad',
    role: 'parent',
    avatar: '/avatars/dad.jpeg',
    isOnline: true,
    notificationsEnabled: true,
  },
  {
    id: 'caregiver-4',
    name: 'Andrew',
    relationship: 'Andrew',
    role: 'family',
    avatar: '/avatars/andrew.jpeg',
    email: 'andrewsinkausosl@gmail.com',
    phone: '5708660590',
    isOnline: false,
    notificationsEnabled: true,
  },
]

// Helper to generate thread ID
function getThreadId(type: 'individual' | 'group', participantIds: string[]): string {
  if (type === 'group') return 'group-chat'
  return `thread-${participantIds.sort().join('-')}`
}

// Create initial threads for each family member + group
function createInitialThreads(familyMembers: FamilyMember[]): ChatThread[] {
  const now = new Date()

  // Individual threads
  const individualThreads: ChatThread[] = familyMembers.map((member) => ({
    id: getThreadId('individual', [member.id]),
    type: 'individual',
    participants: [member.id],
    messages: [],
    unreadCount: 0,
    createdAt: now,
    updatedAt: now,
  }))

  // Group thread with all family members
  const groupThread: ChatThread = {
    id: 'group-chat',
    type: 'group',
    participants: familyMembers.map((m) => m.id),
    messages: [],
    unreadCount: 0,
    createdAt: now,
    updatedAt: now,
  }

  return [groupThread, ...individualThreads]
}

export function ConversationProvider({ children }: { children: ReactNode }) {
  const [childProfile] = useState<ChildProfile>(defaultChildProfile)
  const [familyMembers] = useState<FamilyMember[]>(defaultFamilyMembers)
  const [threads, setThreads] = useState<ChatThread[]>([])
  const [activeThreadId, setActiveThreadId] = useState<string | null>(null)
  const [childViewScreen, setChildViewScreen] = useState<ChildViewScreen>('contacts')
  const [isHydrated, setIsHydrated] = useState(false)

  // Load persisted threads on mount
  useEffect(() => {
    if (typeof window !== 'undefined') {
      try {
        const savedThreads = localStorage.getItem(STORAGE_KEY_THREADS)
        if (savedThreads) {
          const parsed = JSON.parse(savedThreads)
          // Convert date strings back to Date objects
          const hydratedThreads = parsed.map((thread: ChatThread) => ({
            ...thread,
            createdAt: new Date(thread.createdAt),
            updatedAt: new Date(thread.updatedAt),
            messages: thread.messages.map((msg: Message) => ({
              ...msg,
              timestamp: new Date(msg.timestamp),
            })),
            lastMessage: thread.lastMessage
              ? { ...thread.lastMessage, timestamp: new Date(thread.lastMessage.timestamp) }
              : undefined,
          }))
          setThreads(hydratedThreads)
        } else {
          // Initialize with default threads
          setThreads(createInitialThreads(defaultFamilyMembers))
        }
      } catch (error) {
        console.error('Failed to load chat threads:', error)
        setThreads(createInitialThreads(defaultFamilyMembers))
      }
      setIsHydrated(true)
    }
  }, [])

  // Persist threads when they change (only after hydration)
  useEffect(() => {
    if (typeof window !== 'undefined' && isHydrated && threads.length > 0) {
      try {
        localStorage.setItem(STORAGE_KEY_THREADS, JSON.stringify(threads))
      } catch (error) {
        console.error('Failed to save chat threads:', error)
      }
    }
  }, [threads, isHydrated])

  const activeThread = activeThreadId
    ? threads.find((t) => t.id === activeThreadId) || null
    : null

  const setActiveThread = useCallback((threadId: string | null) => {
    setActiveThreadId(threadId)
    if (threadId) {
      setChildViewScreen('chat')
    } else {
      setChildViewScreen('contacts')
    }
  }, [])

  const getThreadForCaregiver = useCallback(
    (caregiverId: string): ChatThread => {
      const threadId = getThreadId('individual', [caregiverId])
      const existing = threads.find((t) => t.id === threadId)
      if (existing) return existing

      // Create new thread if doesn't exist
      const newThread: ChatThread = {
        id: threadId,
        type: 'individual',
        participants: [caregiverId],
        messages: [],
        unreadCount: 0,
        createdAt: new Date(),
        updatedAt: new Date(),
      }
      setThreads((prev) => [...prev, newThread])
      return newThread
    },
    [threads]
  )

  const getGroupThread = useCallback((): ChatThread => {
    const existing = threads.find((t) => t.type === 'group')
    if (existing) return existing

    const newThread: ChatThread = {
      id: 'group-chat',
      type: 'group',
      participants: familyMembers.map((m) => m.id),
      messages: [],
      unreadCount: 0,
      createdAt: new Date(),
      updatedAt: new Date(),
    }
    setThreads((prev) => [...prev, newThread])
    return newThread
  }, [threads, familyMembers])

  const addMessage = useCallback(
    (threadId: string, message: Omit<Message, 'id' | 'timestamp'>) => {
      const newMessage: Message = {
        ...message,
        id: `msg-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`,
        timestamp: new Date(),
        isRead: message.sender === 'child', // Messages from child are auto-read
      }

      setThreads((prev) =>
        prev.map((thread) => {
          if (thread.id !== threadId) return thread

          const updatedMessages = [...thread.messages, newMessage]
          return {
            ...thread,
            messages: updatedMessages,
            lastMessage: newMessage,
            unreadCount:
              message.sender === 'caregiver' ? thread.unreadCount + 1 : thread.unreadCount,
            updatedAt: new Date(),
          }
        })
      )
    },
    []
  )

  const markThreadAsRead = useCallback((threadId: string) => {
    setThreads((prev) =>
      prev.map((thread) => {
        if (thread.id !== threadId) return thread
        return {
          ...thread,
          unreadCount: 0,
          messages: thread.messages.map((msg) => ({ ...msg, isRead: true })),
        }
      })
    )
  }, [])

  // Simulate a caregiver sending a message (for demo/testing - in real app this comes via push)
  const simulateCaregiverMessage = useCallback(
    (threadId: string, caregiverId: string, content: string) => {
      addMessage(threadId, {
        content,
        sender: 'caregiver',
        senderId: caregiverId,
      })
    },
    [addMessage]
  )

  const totalUnreadCount = threads.reduce((sum, t) => sum + t.unreadCount, 0)

  // Don't render until hydrated to prevent mismatch
  if (!isHydrated) {
    return null
  }

  return (
    <ConversationContext.Provider
      value={{
        childProfile,
        familyMembers,
        threads,
        activeThread,
        setActiveThread,
        getThreadForCaregiver,
        getGroupThread,
        addMessage,
        markThreadAsRead,
        childViewScreen,
        setChildViewScreen,
        totalUnreadCount,
        simulateCaregiverMessage,
      }}
    >
      {children}
    </ConversationContext.Provider>
  )
}

export function useConversation() {
  const context = useContext(ConversationContext)
  if (!context) {
    throw new Error('useConversation must be used within a ConversationProvider')
  }
  return context
}
