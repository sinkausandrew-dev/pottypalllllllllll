import type { ResponseOption } from './conversation-data'

export interface Message {
  id: string
  content: string
  sender: 'caregiver' | 'child'
  senderId: string // ID of the specific caregiver or 'child'
  timestamp: Date
  responseOption?: ResponseOption
  isRead?: boolean
}

export interface ChatThread {
  id: string
  type: 'individual' | 'group'
  participants: string[] // caregiver IDs
  messages: Message[]
  lastMessage?: Message
  unreadCount: number
  createdAt: Date
  updatedAt: Date
}

export interface ChildProfile {
  id: string
  name: string
  age: number
  avatar?: string
  voicePreference: 'female' | 'male'
  approvedVocabulary?: string[]
}

export interface CaregiverProfile {
  id: string
  name: string
  avatar?: string
  role: 'parent' | 'caregiver' | 'teacher' | 'therapist' | 'family'
  relationship?: string // e.g., "Dad", "Mom", "Grandma", "Aunt Sarah"
  isOnline?: boolean
}

export interface FamilyMember extends CaregiverProfile {
  phone?: string
  email?: string
  notificationsEnabled?: boolean
}

export type ChildViewScreen = 'contacts' | 'chat'
