/**
 * AAC Conversation Dataset
 * 
 * Comprehensive dataset of parent-child dialogues covering:
 * - Moods and emotional states
 * - Daily routines
 * - Health concerns
 * - Food and drink requests
 * - Play and activities
 * - Pain/discomfort expressions
 * - Help requests
 * - General emotional check-ins
 * 
 * Each record includes:
 * - Child's initiating intent
 * - Caregiver's free-text patterns
 * - Plausible child follow-ups
 * - Corresponding emoji/pictogram
 */

export interface ResponseOption {
  id: string
  text: string
  emoji: string
  category: IntentCategory
  followUpIntents?: string[]
  priority?: number
}

export interface ConversationPattern {
  id: string
  caregiverIntent: string
  caregiverPatterns: string[]
  childResponses: ResponseOption[]
  context?: string[]
}

export type IntentCategory =
  | 'greeting'
  | 'mood'
  | 'food_drink'
  | 'health'
  | 'pain'
  | 'play'
  | 'help'
  | 'routine'
  | 'affection'
  | 'confirmation'
  | 'denial'
  | 'request'
  | 'question'
  | 'closing'

// Core vocabulary - caregiver-approved safe responses
export const APPROVED_VOCABULARY: ResponseOption[] = [
  // Greetings & Basic
  { id: 'hi', text: 'Hi!', emoji: '👋', category: 'greeting' },
  { id: 'hello', text: 'Hello!', emoji: '🙋', category: 'greeting' },
  { id: 'good_morning', text: 'Good morning!', emoji: '🌅', category: 'greeting' },
  { id: 'good_night', text: 'Good night!', emoji: '🌙', category: 'greeting' },
  { id: 'bye', text: 'Bye bye!', emoji: '👋', category: 'closing' },
  { id: 'see_you', text: 'See you later!', emoji: '✌️', category: 'closing' },

  // Confirmations & Denials
  { id: 'yes', text: 'Yes', emoji: '✅', category: 'confirmation', priority: 1 },
  { id: 'no', text: 'No', emoji: '❌', category: 'denial', priority: 1 },
  { id: 'okay', text: 'Okay', emoji: '👍', category: 'confirmation' },
  { id: 'sure', text: 'Sure!', emoji: '👌', category: 'confirmation' },
  { id: 'not_now', text: 'Not now', emoji: '⏰', category: 'denial' },
  { id: 'maybe', text: 'Maybe', emoji: '🤔', category: 'confirmation' },
  { id: 'dont_know', text: "I don't know", emoji: '🤷', category: 'denial' },

  // Mood - Positive
  { id: 'happy', text: "I'm happy!", emoji: '😊', category: 'mood' },
  { id: 'excited', text: "I'm excited!", emoji: '🎉', category: 'mood' },
  { id: 'good', text: "I'm good", emoji: '😌', category: 'mood' },
  { id: 'great', text: "I'm great!", emoji: '🌟', category: 'mood' },
  { id: 'love_you', text: 'I love you', emoji: '❤️', category: 'affection', priority: 1 },
  { id: 'thank_you', text: 'Thank you', emoji: '🙏', category: 'affection' },
  { id: 'youre_welcome', text: "You're welcome", emoji: '😊', category: 'affection' },

  // Mood - Negative
  { id: 'sad', text: "I'm sad", emoji: '😢', category: 'mood' },
  { id: 'tired', text: "I'm tired", emoji: '😴', category: 'mood' },
  { id: 'bored', text: "I'm bored", emoji: '😐', category: 'mood' },
  { id: 'scared', text: "I'm scared", emoji: '😨', category: 'mood' },
  { id: 'angry', text: "I'm angry", emoji: '😠', category: 'mood' },
  { id: 'frustrated', text: "I'm frustrated", emoji: '😤', category: 'mood' },
  { id: 'worried', text: "I'm worried", emoji: '😟', category: 'mood' },
  { id: 'miss_you', text: 'I miss you', emoji: '💔', category: 'affection' },

  // Food & Drink
  { id: 'hungry', text: "I'm hungry", emoji: '🍽️', category: 'food_drink', priority: 1 },
  { id: 'thirsty', text: "I'm thirsty", emoji: '🥤', category: 'food_drink', priority: 1 },
  { id: 'want_snack', text: 'I want a snack', emoji: '🍪', category: 'food_drink' },
  { id: 'want_water', text: 'I want water', emoji: '💧', category: 'food_drink' },
  { id: 'want_juice', text: 'I want juice', emoji: '🧃', category: 'food_drink' },
  { id: 'want_milk', text: 'I want milk', emoji: '🥛', category: 'food_drink' },
  { id: 'more_please', text: 'More please', emoji: '➕', category: 'food_drink' },
  { id: 'all_done', text: 'All done', emoji: '✋', category: 'food_drink' },
  { id: 'yummy', text: 'Yummy!', emoji: '😋', category: 'food_drink' },
  { id: 'not_hungry', text: "I'm not hungry", emoji: '🙅', category: 'food_drink' },

  // Health & Pain
  { id: 'feel_sick', text: 'I feel sick', emoji: '🤒', category: 'health', priority: 1 },
  { id: 'tummy_hurts', text: 'My tummy hurts', emoji: '🤢', category: 'pain', priority: 1 },
  { id: 'head_hurts', text: 'My head hurts', emoji: '🤕', category: 'pain', priority: 1 },
  { id: 'feel_better', text: 'I feel better', emoji: '💪', category: 'health' },
  { id: 'need_medicine', text: 'I need medicine', emoji: '💊', category: 'health' },
  { id: 'need_rest', text: 'I need to rest', emoji: '🛏️', category: 'health' },
  { id: 'hurts_here', text: 'It hurts here', emoji: '👆', category: 'pain' },
  { id: 'too_hot', text: "I'm too hot", emoji: '🥵', category: 'health' },
  { id: 'too_cold', text: "I'm too cold", emoji: '🥶', category: 'health' },

  // Help Requests
  { id: 'need_help', text: 'I need help', emoji: '🆘', category: 'help', priority: 1 },
  { id: 'help_please', text: 'Help please', emoji: '🙋', category: 'help' },
  { id: 'cant_do_it', text: "I can't do it", emoji: '😓', category: 'help' },
  { id: 'show_me', text: 'Show me how', emoji: '👀', category: 'help' },
  { id: 'do_it_together', text: 'Do it with me', emoji: '🤝', category: 'help' },
  { id: 'i_did_it', text: 'I did it!', emoji: '🎊', category: 'confirmation' },

  // Play & Activities
  { id: 'want_play', text: 'I want to play', emoji: '🎮', category: 'play' },
  { id: 'want_outside', text: 'I want to go outside', emoji: '🌳', category: 'play' },
  { id: 'want_watch', text: 'I want to watch TV', emoji: '📺', category: 'play' },
  { id: 'want_music', text: 'I want music', emoji: '🎵', category: 'play' },
  { id: 'want_read', text: 'I want to read', emoji: '📚', category: 'play' },
  { id: 'play_together', text: 'Play with me', emoji: '👫', category: 'play' },
  { id: 'fun', text: 'This is fun!', emoji: '🥳', category: 'play' },
  { id: 'boring', text: 'This is boring', emoji: '😴', category: 'play' },

  // Routine
  { id: 'need_bathroom', text: 'I need the bathroom', emoji: '🚽', category: 'routine', priority: 1 },
  { id: 'want_bath', text: 'I want a bath', emoji: '🛁', category: 'routine' },
  { id: 'want_sleep', text: 'I want to sleep', emoji: '😴', category: 'routine' },
  { id: 'wake_up', text: "I'm awake!", emoji: '☀️', category: 'routine' },
  { id: 'ready', text: "I'm ready", emoji: '✨', category: 'routine' },
  { id: 'not_ready', text: "I'm not ready", emoji: '⏳', category: 'routine' },
  { id: 'wait', text: 'Wait please', emoji: '✋', category: 'routine' },
  { id: 'done', text: "I'm done", emoji: '✅', category: 'routine' },

  // Questions & Requests
  { id: 'what', text: 'What?', emoji: '❓', category: 'question' },
  { id: 'where', text: 'Where?', emoji: '🔍', category: 'question' },
  { id: 'when', text: 'When?', emoji: '⏰', category: 'question' },
  { id: 'why', text: 'Why?', emoji: '🤔', category: 'question' },
  { id: 'who', text: 'Who?', emoji: '👤', category: 'question' },
  { id: 'come_here', text: 'Come here', emoji: '🫲', category: 'request' },
  { id: 'look', text: 'Look!', emoji: '👀', category: 'request' },
  { id: 'listen', text: 'Listen', emoji: '👂', category: 'request' },
]

// Conversation patterns mapping caregiver messages to child responses
export const CONVERSATION_PATTERNS: ConversationPattern[] = [
  // GREETINGS
  {
    id: 'greeting_morning',
    caregiverIntent: 'morning_greeting',
    caregiverPatterns: [
      'good morning',
      'morning',
      'wake up',
      'time to get up',
      'rise and shine',
      'hey sleepyhead',
      'wakey wakey',
    ],
    childResponses: [
      { id: 'good_morning', text: 'Good morning!', emoji: '🌅', category: 'greeting', priority: 1 },
      { id: 'tired', text: "I'm tired", emoji: '😴', category: 'mood' },
      { id: 'wake_up', text: "I'm awake!", emoji: '☀️', category: 'routine' },
      { id: 'love_you', text: 'I love you', emoji: '❤️', category: 'affection' },
      { id: 'not_ready', text: "I'm not ready", emoji: '⏳', category: 'routine' },
    ],
  },
  {
    id: 'greeting_general',
    caregiverIntent: 'general_greeting',
    caregiverPatterns: [
      'hi', 'hello', 'hey', 'hey there', 'hi there', "how's it going",
      'what\'s up', 'howdy', 'hi sweetie', 'hello buddy', 'hi honey',
    ],
    childResponses: [
      { id: 'hi', text: 'Hi!', emoji: '👋', category: 'greeting', priority: 1 },
      { id: 'hello', text: 'Hello!', emoji: '🙋', category: 'greeting' },
      { id: 'happy', text: "I'm happy!", emoji: '😊', category: 'mood' },
      { id: 'love_you', text: 'I love you', emoji: '❤️', category: 'affection' },
    ],
  },
  {
    id: 'greeting_night',
    caregiverIntent: 'night_greeting',
    caregiverPatterns: [
      'good night', 'night night', 'time for bed', 'sleep well', 'sweet dreams',
      'bedtime', 'time to sleep', 'lights out',
    ],
    childResponses: [
      { id: 'good_night', text: 'Good night!', emoji: '🌙', category: 'greeting', priority: 1 },
      { id: 'love_you', text: 'I love you', emoji: '❤️', category: 'affection' },
      { id: 'not_ready', text: "I'm not ready", emoji: '⏳', category: 'routine' },
      { id: 'scared', text: "I'm scared", emoji: '😨', category: 'mood' },
      { id: 'tired', text: "I'm tired", emoji: '😴', category: 'mood' },
    ],
  },

  // MOOD CHECK-INS
  {
    id: 'mood_check',
    caregiverIntent: 'how_are_you',
    caregiverPatterns: [
      'how are you', 'how do you feel', 'how are you feeling', 'are you okay',
      'you okay', 'everything okay', 'what\'s wrong', 'are you alright',
      'how\'s my boy', 'how\'s my girl', 'feeling okay',
    ],
    childResponses: [
      { id: 'good', text: "I'm good", emoji: '😌', category: 'mood', priority: 1 },
      { id: 'happy', text: "I'm happy!", emoji: '😊', category: 'mood' },
      { id: 'sad', text: "I'm sad", emoji: '😢', category: 'mood' },
      { id: 'tired', text: "I'm tired", emoji: '😴', category: 'mood' },
      { id: 'bored', text: "I'm bored", emoji: '😐', category: 'mood' },
    ],
  },
  {
    id: 'mood_concern',
    caregiverIntent: 'concerned_check',
    caregiverPatterns: [
      'what\'s the matter', 'why are you sad', 'what happened', 'tell me what\'s wrong',
      'why the long face', 'are you upset', 'what\'s bothering you',
    ],
    childResponses: [
      { id: 'sad', text: "I'm sad", emoji: '😢', category: 'mood' },
      { id: 'frustrated', text: "I'm frustrated", emoji: '😤', category: 'mood' },
      { id: 'scared', text: "I'm scared", emoji: '😨', category: 'mood' },
      { id: 'miss_you', text: 'I miss you', emoji: '💔', category: 'affection' },
      { id: 'dont_know', text: "I don't know", emoji: '🤷', category: 'denial' },
    ],
  },

  // FOOD & DRINK
  {
    id: 'food_offer',
    caregiverIntent: 'food_offer',
    caregiverPatterns: [
      'are you hungry', 'want something to eat', 'time for lunch', 'time for dinner',
      'breakfast time', 'want a snack', 'would you like to eat', 'ready to eat',
      'dinner is ready', 'lunch is ready', 'food is ready',
    ],
    childResponses: [
      { id: 'yes', text: 'Yes', emoji: '✅', category: 'confirmation', priority: 1 },
      { id: 'hungry', text: "I'm hungry", emoji: '🍽️', category: 'food_drink' },
      { id: 'not_hungry', text: "I'm not hungry", emoji: '🙅', category: 'food_drink' },
      { id: 'want_snack', text: 'I want a snack', emoji: '🍪', category: 'food_drink' },
      { id: 'not_now', text: 'Not now', emoji: '⏰', category: 'denial' },
    ],
  },
  {
    id: 'drink_offer',
    caregiverIntent: 'drink_offer',
    caregiverPatterns: [
      'are you thirsty', 'want something to drink', 'want water', 'want juice',
      'need a drink', 'would you like some water', 'want some milk',
    ],
    childResponses: [
      { id: 'yes', text: 'Yes', emoji: '✅', category: 'confirmation', priority: 1 },
      { id: 'want_water', text: 'I want water', emoji: '💧', category: 'food_drink' },
      { id: 'want_juice', text: 'I want juice', emoji: '🧃', category: 'food_drink' },
      { id: 'want_milk', text: 'I want milk', emoji: '🥛', category: 'food_drink' },
      { id: 'no', text: 'No', emoji: '❌', category: 'denial' },
    ],
  },
  {
    id: 'food_more',
    caregiverIntent: 'more_food',
    caregiverPatterns: [
      'want more', 'do you want more', 'would you like more', 'still hungry',
      'another one', 'more food', 'seconds',
    ],
    childResponses: [
      { id: 'more_please', text: 'More please', emoji: '➕', category: 'food_drink', priority: 1 },
      { id: 'all_done', text: 'All done', emoji: '✋', category: 'food_drink' },
      { id: 'yes', text: 'Yes', emoji: '✅', category: 'confirmation' },
      { id: 'no', text: 'No', emoji: '❌', category: 'denial' },
      { id: 'yummy', text: 'Yummy!', emoji: '😋', category: 'food_drink' },
    ],
  },
  {
    id: 'food_taste',
    caregiverIntent: 'taste_check',
    caregiverPatterns: [
      'is it good', 'do you like it', 'how does it taste', 'yummy',
      'is it yummy', 'tasty', 'delicious',
    ],
    childResponses: [
      { id: 'yummy', text: 'Yummy!', emoji: '😋', category: 'food_drink', priority: 1 },
      { id: 'yes', text: 'Yes', emoji: '✅', category: 'confirmation' },
      { id: 'no', text: 'No', emoji: '❌', category: 'denial' },
      { id: 'more_please', text: 'More please', emoji: '➕', category: 'food_drink' },
      { id: 'all_done', text: 'All done', emoji: '✋', category: 'food_drink' },
    ],
  },

  // HEALTH & PAIN
  {
    id: 'health_check',
    caregiverIntent: 'health_check',
    caregiverPatterns: [
      'do you feel sick', 'are you sick', 'does something hurt', 'what hurts',
      'where does it hurt', 'show me where it hurts', 'are you in pain',
      'feeling better', 'do you feel better',
    ],
    childResponses: [
      { id: 'feel_better', text: 'I feel better', emoji: '💪', category: 'health', priority: 1 },
      { id: 'feel_sick', text: 'I feel sick', emoji: '🤒', category: 'health' },
      { id: 'tummy_hurts', text: 'My tummy hurts', emoji: '🤢', category: 'pain' },
      { id: 'head_hurts', text: 'My head hurts', emoji: '🤕', category: 'pain' },
      { id: 'hurts_here', text: 'It hurts here', emoji: '👆', category: 'pain' },
    ],
  },
  {
    id: 'comfort_check',
    caregiverIntent: 'comfort_check',
    caregiverPatterns: [
      'are you hot', 'are you cold', 'too warm', 'too cold', 'need a blanket',
      'comfortable', 'are you comfortable',
    ],
    childResponses: [
      { id: 'good', text: "I'm good", emoji: '😌', category: 'mood', priority: 1 },
      { id: 'too_hot', text: "I'm too hot", emoji: '🥵', category: 'health' },
      { id: 'too_cold', text: "I'm too cold", emoji: '🥶', category: 'health' },
      { id: 'yes', text: 'Yes', emoji: '✅', category: 'confirmation' },
      { id: 'no', text: 'No', emoji: '❌', category: 'denial' },
    ],
  },

  // PLAY & ACTIVITIES
  {
    id: 'play_offer',
    caregiverIntent: 'play_offer',
    caregiverPatterns: [
      'want to play', 'do you want to play', 'let\'s play', 'play time',
      'want to have fun', 'should we play', 'game time',
    ],
    childResponses: [
      { id: 'yes', text: 'Yes', emoji: '✅', category: 'confirmation', priority: 1 },
      { id: 'want_play', text: 'I want to play', emoji: '🎮', category: 'play' },
      { id: 'play_together', text: 'Play with me', emoji: '👫', category: 'play' },
      { id: 'not_now', text: 'Not now', emoji: '⏰', category: 'denial' },
      { id: 'tired', text: "I'm tired", emoji: '😴', category: 'mood' },
    ],
  },
  {
    id: 'activity_choice',
    caregiverIntent: 'activity_choice',
    caregiverPatterns: [
      'what do you want to do', 'what should we do', 'any ideas',
      'pick something', 'choose what to do', 'what sounds fun',
    ],
    childResponses: [
      { id: 'want_play', text: 'I want to play', emoji: '🎮', category: 'play', priority: 1 },
      { id: 'want_watch', text: 'I want to watch TV', emoji: '📺', category: 'play' },
      { id: 'want_outside', text: 'I want to go outside', emoji: '🌳', category: 'play' },
      { id: 'want_music', text: 'I want music', emoji: '🎵', category: 'play' },
      { id: 'want_read', text: 'I want to read', emoji: '📚', category: 'play' },
    ],
  },
  {
    id: 'activity_fun',
    caregiverIntent: 'fun_check',
    caregiverPatterns: [
      'is it fun', 'are you having fun', 'do you like this', 'enjoying yourself',
      'having a good time', 'is this fun',
    ],
    childResponses: [
      { id: 'fun', text: 'This is fun!', emoji: '🥳', category: 'play', priority: 1 },
      { id: 'yes', text: 'Yes', emoji: '✅', category: 'confirmation' },
      { id: 'boring', text: 'This is boring', emoji: '😴', category: 'play' },
      { id: 'more_please', text: 'More please', emoji: '➕', category: 'food_drink' },
      { id: 'play_together', text: 'Play with me', emoji: '👫', category: 'play' },
    ],
  },

  // ROUTINE
  {
    id: 'bathroom_check',
    caregiverIntent: 'bathroom_check',
    caregiverPatterns: [
      'need to go potty', 'bathroom', 'need the bathroom', 'potty time',
      'do you need to use the bathroom', 'toilet', 'restroom',
    ],
    childResponses: [
      { id: 'need_bathroom', text: 'I need the bathroom', emoji: '🚽', category: 'routine', priority: 1 },
      { id: 'yes', text: 'Yes', emoji: '✅', category: 'confirmation' },
      { id: 'no', text: 'No', emoji: '❌', category: 'denial' },
      { id: 'done', text: "I'm done", emoji: '✅', category: 'routine' },
      { id: 'help_please', text: 'Help please', emoji: '🙋', category: 'help' },
    ],
  },
  {
    id: 'bath_time',
    caregiverIntent: 'bath_time',
    caregiverPatterns: [
      'bath time', 'time for a bath', 'let\'s take a bath', 'shower time',
      'time to get clean', 'want a bath',
    ],
    childResponses: [
      { id: 'okay', text: 'Okay', emoji: '👍', category: 'confirmation', priority: 1 },
      { id: 'want_bath', text: 'I want a bath', emoji: '🛁', category: 'routine' },
      { id: 'not_now', text: 'Not now', emoji: '⏰', category: 'denial' },
      { id: 'fun', text: 'This is fun!', emoji: '🥳', category: 'play' },
      { id: 'done', text: "I'm done", emoji: '✅', category: 'routine' },
    ],
  },
  {
    id: 'ready_check',
    caregiverIntent: 'ready_check',
    caregiverPatterns: [
      'are you ready', 'ready to go', 'all set', 'are we ready',
      'time to go', 'let\'s go', 'shall we go',
    ],
    childResponses: [
      { id: 'ready', text: "I'm ready", emoji: '✨', category: 'routine', priority: 1 },
      { id: 'not_ready', text: "I'm not ready", emoji: '⏳', category: 'routine' },
      { id: 'wait', text: 'Wait please', emoji: '✋', category: 'routine' },
      { id: 'yes', text: 'Yes', emoji: '✅', category: 'confirmation' },
      { id: 'need_help', text: 'I need help', emoji: '🆘', category: 'help' },
    ],
  },

  // HELP & SUPPORT
  {
    id: 'help_offer',
    caregiverIntent: 'help_offer',
    caregiverPatterns: [
      'do you need help', 'need help', 'can I help', 'let me help',
      'want me to help', 'need a hand', 'assistance',
    ],
    childResponses: [
      { id: 'yes', text: 'Yes', emoji: '✅', category: 'confirmation', priority: 1 },
      { id: 'help_please', text: 'Help please', emoji: '🙋', category: 'help' },
      { id: 'show_me', text: 'Show me how', emoji: '👀', category: 'help' },
      { id: 'do_it_together', text: 'Do it with me', emoji: '🤝', category: 'help' },
      { id: 'no', text: 'No', emoji: '❌', category: 'denial' },
    ],
  },
  {
    id: 'task_complete',
    caregiverIntent: 'task_complete',
    caregiverPatterns: [
      'did you do it', 'are you done', 'finished', 'all done',
      'completed', 'how did it go', 'is it done',
    ],
    childResponses: [
      { id: 'i_did_it', text: 'I did it!', emoji: '🎊', category: 'confirmation', priority: 1 },
      { id: 'done', text: "I'm done", emoji: '✅', category: 'routine' },
      { id: 'need_help', text: 'I need help', emoji: '🆘', category: 'help' },
      { id: 'cant_do_it', text: "I can't do it", emoji: '😓', category: 'help' },
      { id: 'not_ready', text: "I'm not ready", emoji: '⏳', category: 'routine' },
    ],
  },

  // AFFECTION
  {
    id: 'affection_give',
    caregiverIntent: 'love_expression',
    caregiverPatterns: [
      'I love you', 'love you', 'love you so much', 'you\'re the best',
      'you\'re amazing', 'proud of you', 'I\'m so proud', 'miss you',
      'thinking of you', 'you mean so much',
    ],
    childResponses: [
      { id: 'love_you', text: 'I love you', emoji: '❤️', category: 'affection', priority: 1 },
      { id: 'happy', text: "I'm happy!", emoji: '😊', category: 'mood' },
      { id: 'thank_you', text: 'Thank you', emoji: '🙏', category: 'affection' },
      { id: 'miss_you', text: 'I miss you', emoji: '💔', category: 'affection' },
    ],
  },
  {
    id: 'thanks_give',
    caregiverIntent: 'thanks_expression',
    caregiverPatterns: [
      'thank you', 'thanks', 'appreciate it', 'that was nice',
      'good job', 'well done', 'great job', 'awesome',
    ],
    childResponses: [
      { id: 'youre_welcome', text: "You're welcome", emoji: '😊', category: 'affection', priority: 1 },
      { id: 'happy', text: "I'm happy!", emoji: '😊', category: 'mood' },
      { id: 'thank_you', text: 'Thank you', emoji: '🙏', category: 'affection' },
      { id: 'i_did_it', text: 'I did it!', emoji: '🎊', category: 'confirmation' },
    ],
  },

  // GENERAL QUESTIONS
  {
    id: 'yes_no_question',
    caregiverIntent: 'yes_no_question',
    caregiverPatterns: [
      'do you', 'did you', 'are you', 'can you', 'will you', 'would you',
      'have you', 'is it', 'was it', 'should we',
    ],
    childResponses: [
      { id: 'yes', text: 'Yes', emoji: '✅', category: 'confirmation', priority: 1 },
      { id: 'no', text: 'No', emoji: '❌', category: 'denial' },
      { id: 'maybe', text: 'Maybe', emoji: '🤔', category: 'confirmation' },
      { id: 'dont_know', text: "I don't know", emoji: '🤷', category: 'denial' },
      { id: 'okay', text: 'Okay', emoji: '👍', category: 'confirmation' },
    ],
  },
  {
    id: 'attention_getter',
    caregiverIntent: 'attention',
    caregiverPatterns: [
      'look at this', 'check this out', 'see this', 'watch',
      'listen to this', 'come see', 'look here',
    ],
    childResponses: [
      { id: 'look', text: 'Look!', emoji: '👀', category: 'request', priority: 1 },
      { id: 'fun', text: 'This is fun!', emoji: '🥳', category: 'play' },
      { id: 'what', text: 'What?', emoji: '❓', category: 'question' },
      { id: 'excited', text: "I'm excited!", emoji: '🎉', category: 'mood' },
      { id: 'okay', text: 'Okay', emoji: '👍', category: 'confirmation' },
    ],
  },

  // CLOSING
  {
    id: 'goodbye',
    caregiverIntent: 'goodbye',
    caregiverPatterns: [
      'goodbye', 'bye', 'see you later', 'see you soon', 'gotta go',
      'talk to you later', 'bye bye', 'take care',
    ],
    childResponses: [
      { id: 'bye', text: 'Bye bye!', emoji: '👋', category: 'closing', priority: 1 },
      { id: 'see_you', text: 'See you later!', emoji: '✌️', category: 'closing' },
      { id: 'love_you', text: 'I love you', emoji: '❤️', category: 'affection' },
      { id: 'miss_you', text: 'I miss you', emoji: '💔', category: 'affection' },
    ],
  },
]

// Default fallback responses for unrecognized intents
export const FALLBACK_RESPONSES: ResponseOption[] = [
  { id: 'yes', text: 'Yes', emoji: '✅', category: 'confirmation', priority: 1 },
  { id: 'no', text: 'No', emoji: '❌', category: 'denial', priority: 1 },
  { id: 'okay', text: 'Okay', emoji: '👍', category: 'confirmation' },
  { id: 'dont_know', text: "I don't know", emoji: '🤷', category: 'denial' },
  { id: 'need_help', text: 'I need help', emoji: '🆘', category: 'help' },
]

// Child-initiated conversation starters
export const CHILD_INITIATORS: ResponseOption[] = [
  { id: 'hi', text: 'Hi!', emoji: '👋', category: 'greeting', priority: 1 },
  { id: 'hungry', text: "I'm hungry", emoji: '🍽️', category: 'food_drink', priority: 1 },
  { id: 'thirsty', text: "I'm thirsty", emoji: '🥤', category: 'food_drink', priority: 1 },
  { id: 'need_help', text: 'I need help', emoji: '🆘', category: 'help', priority: 1 },
  { id: 'want_play', text: 'I want to play', emoji: '🎮', category: 'play', priority: 1 },
  { id: 'need_bathroom', text: 'I need the bathroom', emoji: '🚽', category: 'routine', priority: 1 },
  { id: 'feel_sick', text: 'I feel sick', emoji: '🤒', category: 'health', priority: 1 },
  { id: 'love_you', text: 'I love you', emoji: '❤️', category: 'affection', priority: 1 },
  { id: 'sad', text: "I'm sad", emoji: '😢', category: 'mood' },
  { id: 'happy', text: "I'm happy!", emoji: '😊', category: 'mood' },
  { id: 'tired', text: "I'm tired", emoji: '😴', category: 'mood' },
  { id: 'scared', text: "I'm scared", emoji: '😨', category: 'mood' },
]
