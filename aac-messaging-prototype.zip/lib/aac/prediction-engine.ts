/**
 * AAC Prediction Engine
 *
 * Maps caregiver messages to predicted child responses using:
 * - Pattern matching against conversation dataset
 * - Intent classification
 * - Context-aware response ranking
 * - Personalization through usage tracking
 */

import {
  CONVERSATION_PATTERNS,
  FALLBACK_RESPONSES,
  CHILD_INITIATORS,
  type ConversationPattern,
  type ResponseOption,
  type IntentCategory,
} from './conversation-data'

export interface PredictionResult {
  responses: ResponseOption[]
  matchedPattern: ConversationPattern | null
  confidence: number
  intent: string
}

export interface ConversationContext {
  recentIntents: IntentCategory[]
  timeOfDay: 'morning' | 'afternoon' | 'evening' | 'night'
  lastChildResponse?: ResponseOption
  conversationLength: number
}

// Usage tracking for personalization
const usageFrequency: Map<string, number> = new Map()

/**
 * Normalize text for pattern matching
 */
function normalizeText(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^\w\s]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
}

/**
 * Calculate similarity score between two strings
 * Uses a combination of exact matching, substring matching, and word overlap
 */
function calculateSimilarity(input: string, pattern: string): number {
  const normalizedInput = normalizeText(input)
  const normalizedPattern = normalizeText(pattern)

  // Exact match
  if (normalizedInput === normalizedPattern) return 1.0

  // Check if pattern is contained in input
  if (normalizedInput.includes(normalizedPattern)) return 0.9

  // Check if input is contained in pattern
  if (normalizedPattern.includes(normalizedInput)) return 0.85

  // Word overlap scoring
  const inputWords = new Set(normalizedInput.split(' '))
  const patternWords = new Set(normalizedPattern.split(' '))

  let matchCount = 0
  for (const word of inputWords) {
    if (patternWords.has(word)) matchCount++
  }

  const overlapScore = matchCount / Math.max(inputWords.size, patternWords.size)

  return overlapScore
}

/**
 * Find the best matching conversation pattern for caregiver input
 */
function findBestPattern(
  caregiverMessage: string
): { pattern: ConversationPattern; score: number } | null {
  let bestMatch: { pattern: ConversationPattern; score: number } | null = null

  for (const pattern of CONVERSATION_PATTERNS) {
    for (const caregiverPattern of pattern.caregiverPatterns) {
      const score = calculateSimilarity(caregiverMessage, caregiverPattern)

      if (score > 0.5 && (!bestMatch || score > bestMatch.score)) {
        bestMatch = { pattern, score }
      }
    }
  }

  return bestMatch
}

/**
 * Rank responses based on context and usage patterns
 */
function rankResponses(
  responses: ResponseOption[],
  context?: ConversationContext
): ResponseOption[] {
  return responses
    .map((response) => {
      let score = response.priority || 0

      // Boost based on usage frequency
      const usageCount = usageFrequency.get(response.id) || 0
      score += Math.min(usageCount * 0.1, 0.5)

      // Context-based boosting
      if (context) {
        // Time of day relevance
        if (context.timeOfDay === 'morning' && response.id === 'good_morning') {
          score += 0.3
        }
        if (
          context.timeOfDay === 'night' &&
          (response.id === 'good_night' || response.id === 'tired')
        ) {
          score += 0.3
        }

        // Avoid immediate repetition
        if (context.lastChildResponse?.id === response.id) {
          score -= 0.5
        }
      }

      return { ...response, _score: score }
    })
    .sort((a, b) => (b as { _score: number })._score - (a as { _score: number })._score)
    .map(({ _score, ...response }) => response as ResponseOption)
}

/**
 * Get current time of day
 */
function getTimeOfDay(): 'morning' | 'afternoon' | 'evening' | 'night' {
  const hour = new Date().getHours()
  if (hour >= 5 && hour < 12) return 'morning'
  if (hour >= 12 && hour < 17) return 'afternoon'
  if (hour >= 17 && hour < 21) return 'evening'
  return 'night'
}

/**
 * Main prediction function
 * Maps caregiver message to ranked child response options
 */
export function predictResponses(
  caregiverMessage: string,
  context?: Partial<ConversationContext>
): PredictionResult {
  const fullContext: ConversationContext = {
    recentIntents: context?.recentIntents || [],
    timeOfDay: context?.timeOfDay || getTimeOfDay(),
    lastChildResponse: context?.lastChildResponse,
    conversationLength: context?.conversationLength || 0,
  }

  // Find matching pattern
  const match = findBestPattern(caregiverMessage)

  if (match) {
    const rankedResponses = rankResponses(match.pattern.childResponses, fullContext)

    return {
      responses: rankedResponses.slice(0, 5),
      matchedPattern: match.pattern,
      confidence: match.score,
      intent: match.pattern.caregiverIntent,
    }
  }

  // Fallback to default responses
  const rankedFallback = rankResponses(FALLBACK_RESPONSES, fullContext)

  return {
    responses: rankedFallback,
    matchedPattern: null,
    confidence: 0,
    intent: 'unknown',
  }
}

/**
 * Get conversation starter options for child
 */
export function getConversationStarters(context?: Partial<ConversationContext>): ResponseOption[] {
  const fullContext: ConversationContext = {
    recentIntents: context?.recentIntents || [],
    timeOfDay: context?.timeOfDay || getTimeOfDay(),
    lastChildResponse: context?.lastChildResponse,
    conversationLength: context?.conversationLength || 0,
  }

  return rankResponses(CHILD_INITIATORS, fullContext).slice(0, 6)
}

/**
 * Record response selection for personalization
 */
export function recordResponseSelection(responseId: string): void {
  const current = usageFrequency.get(responseId) || 0
  usageFrequency.set(responseId, current + 1)
}

/**
 * Get follow-up responses based on context
 */
export function getFollowUpResponses(
  lastResponse: ResponseOption,
  context?: Partial<ConversationContext>
): ResponseOption[] {
  // Find patterns that might follow the last response category
  const relevantPatterns = CONVERSATION_PATTERNS.filter(
    (pattern) =>
      pattern.context?.includes(lastResponse.category) ||
      pattern.childResponses.some((r) => r.category === lastResponse.category)
  )

  if (relevantPatterns.length > 0) {
    const responses = relevantPatterns.flatMap((p) => p.childResponses)
    const uniqueResponses = Array.from(new Map(responses.map((r) => [r.id, r])).values())
    return rankResponses(uniqueResponses, context as ConversationContext).slice(0, 5)
  }

  return rankResponses(FALLBACK_RESPONSES, context as ConversationContext)
}

/**
 * Intent categories for quick filtering
 */
export const INTENT_CATEGORIES: { category: IntentCategory; label: string; emoji: string }[] = [
  { category: 'greeting', label: 'Greetings', emoji: '👋' },
  { category: 'mood', label: 'Feelings', emoji: '😊' },
  { category: 'food_drink', label: 'Food & Drink', emoji: '🍽️' },
  { category: 'health', label: 'Health', emoji: '💪' },
  { category: 'pain', label: 'Pain', emoji: '🤕' },
  { category: 'play', label: 'Play', emoji: '🎮' },
  { category: 'help', label: 'Help', emoji: '🆘' },
  { category: 'routine', label: 'Routine', emoji: '📋' },
  { category: 'affection', label: 'Love', emoji: '❤️' },
]
